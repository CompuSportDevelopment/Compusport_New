﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{
    public class carriers
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        #region Constants
        private const string SP_DELETE_CARRIERS = "CARRIERS_DELETE";
        private const string SP_INSERT_CARRIERS = "CARRIERS_INSERT";
        private const string SP_SELECT_CARRIERS = "CARRIERS_SELECT";
        private const string SP_SELECTALL_CARRIERS = "CARRIERS_SELECTALL";
        private const string SP_UPDATE_CARRIERS = "CARRIERS_UPDATE";
        

        #endregion Constants

        #region Variable
        private int _id;
        private int _UserId;
        private int _AccountId;
        private int _OrgId;
        private string _CarrierName;
        private string _IMEI;
        private string _CreatedOn;
        private string _ExpireOn;
        private int _CreatedBy;
        private bool _HasGeofence;
        private DateTime _ExpiryDate;
        private int _AllocatedPortNo;
        private bool _IsActive;
        private string _EmailId1;
        private string _EmailId2;
        private string _SMSQUOTA;
        private DateTime _ActivationDateTime;
        private DateTime _LastEmailAlertDateTime;
        private int _EmailAlertDurationMinute;

        private string _Apn;

        private string _GSMNo;
        private int _ExpiryAlertBeforeDays;
        private int _ExpiryAlertAfterDays;
        private int _AlertSpeed;
        private int _MaxAllowedSpeed;
        private string _IconUrl;
        #endregion Variable

        #region Properties

        public int UserId
        {
            get { return _UserId; }
            set { _UserId = value; }
        }

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public int AccountId
        {
            get { return _AccountId; }
            set { _AccountId = value; }
        }
        public int OrgId
        {
            get { return _OrgId; }
            set { _OrgId = value; }
        }
        public string CarrierName
        {
            get { return _CarrierName; }
            set { _CarrierName = value; }
        }
        public string IMEI
        {
            get { return _IMEI; }
            set { _IMEI = value; }
        }
        public string CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }
        public string ExpireOn
        {
            get { return _ExpireOn; }
            set { _ExpireOn = value; }
        }
        public int CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }
        public bool HasGeofence
        {
            get { return _HasGeofence; }
            set { _HasGeofence = value; }
        }
        public DateTime ExpiryDate
        {
            get { return _ExpiryDate; }
            set { _ExpiryDate = value; }
        }
        public int AllocatedPortNo
        {
            get { return _AllocatedPortNo; }
            set { _AllocatedPortNo = value; }
        }
        public bool IsActive
        {
            get { return _IsActive; }
            set { _IsActive = value; }
        }
        public string EmailId1
        {
            get { return _EmailId1; }
            set { _EmailId1 = value; }
        }
        public string EmailId2
        {
            get { return _EmailId2; }
            set { _EmailId2 = value; }
        }
        public string SMSQUOTA
        {
            get { return _SMSQUOTA; }
            set { _SMSQUOTA = value; }
        }
        public DateTime ActivationDateTime
        {
            get { return _ActivationDateTime; }
            set { _ActivationDateTime = value; }
        }
        public DateTime LastEmailAlertDateTime
        {
            get { return _LastEmailAlertDateTime; }
            set { _LastEmailAlertDateTime = value; }
        }
        public int EmailAlertDurationMinute
        {
            get { return _EmailAlertDurationMinute; }
            set { _EmailAlertDurationMinute = value; }
        }

        public string Apn
        {
            get { return _Apn; }
            set { _Apn = value; }
        }

        public string GSMNo
        {
            get { return _GSMNo; }
            set { _GSMNo = value; }
        }
        public int ExpiryAlertBeforeDays
        {
            get { return _ExpiryAlertBeforeDays; }
            set { _ExpiryAlertBeforeDays = value; }
        }
        public int ExpiryAlertAfterDays
        {
            get { return _ExpiryAlertAfterDays; }
            set { _ExpiryAlertAfterDays = value; }
        }
        public int AlertSpeed
        {
            get { return _AlertSpeed; }
            set { _AlertSpeed = value; }
        }
        public int MaxAllowedSpeed
        {
            get { return _MaxAllowedSpeed; }
            set { _MaxAllowedSpeed = value; }
        }
        public string IconUrl
        {
            get { return _IconUrl; }
            set { _IconUrl = value; }
        }

        #endregion Properties

        #region DataAccess

        public void Data_Insert()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCarriar = connection.CreateCommand())
                    {
                        cmdCarriar.CommandType = CommandType.StoredProcedure;
                        cmdCarriar.CommandText = SP_INSERT_CARRIERS;
                        SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                        sp.Direction = ParameterDirection.Output;
                        cmdCarriar.Parameters.Add(sp);
                        DoInsertUpdate(cmdCarriar);
                        Id = Convert.ToInt32(cmdCarriar.Parameters["@ID"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void DoInsertUpdate(SqlCommand cmdCarriar)
        {
            cmdCarriar.Parameters.AddWithValue("@AccountId", _AccountId);
            cmdCarriar.Parameters.AddWithValue("@UserId", _UserId);
            cmdCarriar.Parameters.AddWithValue("@OrgId", _OrgId);
            cmdCarriar.Parameters.AddWithValue("@CarrierName", _CarrierName);
            cmdCarriar.Parameters.AddWithValue("@IMEI", _IMEI);
            cmdCarriar.Parameters.AddWithValue("@CreatedOn", _CreatedOn);
            cmdCarriar.Parameters.AddWithValue("@ExpireOn", _ExpireOn);
            cmdCarriar.Parameters.AddWithValue("@CreatedBy", _CreatedBy);
            cmdCarriar.Parameters.AddWithValue("@HasGeofence", _HasGeofence);
            if (_ExpiryDate == System.DateTime.MinValue)
            {
                cmdCarriar.Parameters.AddWithValue("@ExpiryDate", System.DBNull.Value);
            }
            else
            {
                cmdCarriar.Parameters.AddWithValue("@ExpiryDate", _ExpiryDate);
            }
            cmdCarriar.Parameters.AddWithValue("@AllocatedPortNo", _AllocatedPortNo);
            cmdCarriar.Parameters.AddWithValue("@IsActive", _IsActive);
            cmdCarriar.Parameters.AddWithValue("@EmailId1", _EmailId1);
            cmdCarriar.Parameters.AddWithValue("@EmailId2", _EmailId2);
            cmdCarriar.Parameters.AddWithValue("@SMSQUOTA", _SMSQUOTA);
            if (_ActivationDateTime == System.DateTime.MinValue)
            {
                cmdCarriar.Parameters.AddWithValue("@ActivationDateTime", System.DBNull.Value);
            }
            else
            {
                cmdCarriar.Parameters.AddWithValue("@ActivationDateTime", _ActivationDateTime);
            }
            if (_LastEmailAlertDateTime == System.DateTime.MinValue)
            {
                cmdCarriar.Parameters.AddWithValue("@LastEmailAlertDateTime", System.DBNull.Value);
            }
            else
            {
                cmdCarriar.Parameters.AddWithValue("@LastEmailAlertDateTime", _LastEmailAlertDateTime);
            }
            cmdCarriar.Parameters.AddWithValue("@EmailAlertDurationMinute", _EmailAlertDurationMinute);

            cmdCarriar.Parameters.AddWithValue("@Apn", _Apn);

            cmdCarriar.Parameters.AddWithValue("@GSMNo", _GSMNo);
            cmdCarriar.Parameters.AddWithValue("@ExpiryAlertBeforeDays", _ExpiryAlertBeforeDays);
            cmdCarriar.Parameters.AddWithValue("@ExpiryAlertAfterDays", _ExpiryAlertAfterDays);
            cmdCarriar.Parameters.AddWithValue("@AlertSpeed", _AlertSpeed);
            cmdCarriar.Parameters.AddWithValue("@MaxAllowedSpeed", _MaxAllowedSpeed);
            cmdCarriar.Parameters.AddWithValue("@IconUrl", _IconUrl);

            cmdCarriar.ExecuteNonQuery();
        }

        public void Data_Update(int _id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCarriar = connection.CreateCommand())
                    {
                        cmdCarriar.CommandType = CommandType.StoredProcedure;
                        cmdCarriar.CommandText = SP_UPDATE_CARRIERS;
                        cmdCarriar.Parameters.Add("@Id", SqlDbType.Int).Value = _id;
                        DoInsertUpdate(cmdCarriar);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public DataTable Data_SelectAll()
        {
            DataTable dtcarriers = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdcarriers = connection.CreateCommand())
                    {
                        cmdcarriers.CommandType = CommandType.StoredProcedure;
                        cmdcarriers.CommandText = SP_SELECTALL_CARRIERS;
                        SqlDataAdapter dabilling = new SqlDataAdapter(cmdcarriers);
                        dabilling.Fill(dtcarriers);
                    }
                    return dtcarriers;
                }

            }
            catch (Exception ex)
            {
            }
            return null;
        }

        public DataTable Data_SelectById(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "CARRIERS_SELECTBY_ID";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public DataTable Data_SelByUserRole(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "CARRIERS_SELECTBY_USERROLE";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public DataTable Data_SelByOrg(int accountId)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "CARRIERS_SELECTBY_ORG";
                        cmdCatalogProduct.Connection = connection;
                       // cmdCatalogProduct.Parameters.AddWithValue("@OrgId", orgId);
                        cmdCatalogProduct.Parameters.AddWithValue("@AccountId", accountId);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public void Data_Delete(int _id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdProductCost = connection.CreateCommand())
                    {
                        cmdProductCost.CommandType = CommandType.StoredProcedure;
                        cmdProductCost.CommandText = SP_DELETE_CARRIERS;
                        cmdProductCost.Connection = connection;
                        cmdProductCost.Parameters.AddWithValue("@Id", _id);
                        cmdProductCost.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion DataAccess
    }
}
