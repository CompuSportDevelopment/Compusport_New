﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{
    public class Country
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();


        #region Constants
        private const string SP_SELECT_COUNTRY = "COUNTRY_SELECT";
        private const string SP_SELECTALL_COUNTRY = "COUNTRY_SELECTALL";
        #endregion Constans

        #region DataAccess

        public DataTable Data_SelectAll()
        {
            DataTable dtCountry = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCountry = connection.CreateCommand())
                    {
                        cmdCountry.CommandType = CommandType.StoredProcedure;
                        cmdCountry.CommandText = SP_SELECTALL_COUNTRY;
                        //cmdCountry.Parameters.AddWithValue("@Id", CountryID);
                        SqlDataAdapter dabilling = new SqlDataAdapter(cmdCountry);
                        dabilling.Fill(dtCountry);
                    }
                    return dtCountry;
                }

            }
            catch (Exception ex)
            {
            }
            return null;
        }

        #endregion DataAccess
    }
}
