﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GPS_TrackingDLL
{
    public class TimeZoneClass
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        public DataTable Data_SelectAll()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdUser = connection.CreateCommand())
                    {
                        cmdUser.CommandType = CommandType.StoredProcedure;
                        cmdUser.CommandText = "TIMEZONE_SELECTALL";
                        cmdUser.Connection = connection;
                        SqlDataAdapter da = new SqlDataAdapter(cmdUser);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
