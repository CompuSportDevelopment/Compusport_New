﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{

    public class Account
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        #region Constants

        private const string SP_DELETE_ACCOUNT = "ACCOUNT_DELETE";
        private const string SP_INSERT_ACCOUNT = "ACCOUNT_INSERT";
        private const string SP_SELECT_ACCOUNT = "ACCOUNT_SELECT";
        private const string SP_SELECTALL_ACCOUNT = "ACCOUNT_SELECTALL";
        private const string SP_UPDATE_ACCOUNT = "ACCOUNT_UPDATE";
        private const string SP_SELECTBYID_ACCOUNT = "ACCOUNT_SELECTBY_ID";

        #endregion Constants

        #region Variable

        private int _id;
        private string _AccountID;
        private string _AccountName;
        private int _AccountAdminID;
        private string _Address;
        private string _City;
        private string _State;
        private string _Country;
        private string _ZipPin;
        private string _Email;
        private DateTime _ActivatedOn;
        private int _numDaysToIndicateExpiry;
        private DateTime _CreatedOn;
        private DateTime _ExpirOn;
        private int _CreatedBy;
        private decimal _Creditfunds;
        private string _Billing_Address;
        private string _Phone1;
        private string _Phone2;
        private string _Fax;
        private string _Email2;
        private string _URL;
        private string _AccountType;
        private DateTime _BillingDateTime;
        private string _SubDomain;
        private string _GoogleMapKey;
        private string _CustomizeType;
        private string _NoOfOrg;
        private string _NoOfUser;
        private string _NoOfCarrier;
        private string _DNNGoogleMapKey;
        private string _DNNSubDomain;

        #endregion Variable

        #region Properties

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string AccountID
        {
            get { return _AccountID; }
            set { _AccountID = value; }
        }
        public string AccountName
        {
            get { return _AccountName; }
            set { _AccountName = value; }
        }

        public int AccountAdminID
        {
            get { return _AccountAdminID; }
            set { _AccountAdminID = value; }
        }
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }
        public string State
        {
            get { return _State; }
            set { _State = value; }
        }
        public string Country
        {
            get { return _Country; }
            set { _Country = value; }
        }
        public string ZipPin
        {
            get { return _ZipPin; }
            set { _ZipPin = value; }
        }
        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        public DateTime ActivatedOn
        {
            get { return _ActivatedOn; }
            set { _ActivatedOn = value; }
        }
        public int numDaysToIndicateExpiry
        {
            get { return _numDaysToIndicateExpiry; }
            set { _numDaysToIndicateExpiry = value; }
        }
        public DateTime CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }
        public DateTime ExpirOn
        {
            get { return _ExpirOn; }
            set { _ExpirOn = value; }
        }
        public int CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }
        public decimal  Creditfunds
        {
            get { return _Creditfunds; }
            set { _Creditfunds = value; }
        }
        public string Billing_Address
        {
            get { return _Billing_Address; }
            set { _Billing_Address = value; }
        }
        public string Phone1
        {
            get { return _Phone1; }
            set { _Phone1 = value; }
        }
        public string Phone2
        {
            get { return _Phone2; }
            set { _Phone2 = value; }
        }
        public string Fax
        {
            get { return _Fax; }
            set { _Fax = value; }
        }
        public string Email2
        {
            get { return _Email2; }
            set { _Email2 = value; }
        }
        public string URL
        {
            get { return _URL; }
            set { _URL = value; }
        }
        public string AccountType
        {
            get { return _AccountType; }
            set { _AccountType = value; }
        }
        public DateTime BillingDateTime
        {
            get { return _BillingDateTime; }
            set { _BillingDateTime = value; }
        }
        public string SubDomain
        {
            get { return _SubDomain; }
            set { _SubDomain = value; }
        }
        public string NoOfOrg
        {
            get { return _NoOfOrg; }
            set { _NoOfOrg = value; }
        }
        public string GoogleMapKey
        {
            get { return _GoogleMapKey; }
            set { _GoogleMapKey = value; }
        }
        public string CustomizeType
        {
            get { return _CustomizeType; }
            set { _CustomizeType = value; }
        }
        public string NoOfUser
        {
            get { return _NoOfUser; }
            set { _NoOfUser = value; }
        }
        public string NoOfCarrier
        {
            get { return _NoOfCarrier; }
            set { _NoOfCarrier = value; }
        }
        public string DNNGoogleMapKey
        {
            get { return _DNNGoogleMapKey; }
            set { _DNNGoogleMapKey = value; }
        }
        public string DNNSubDomain
        {
            get { return _DNNSubDomain; }
            set { _DNNSubDomain = value; }
        }

        #endregion Properties

        #region DataAccess


        public void Data_Insert()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdAccount = connection.CreateCommand())
                    {
                        cmdAccount.CommandType = CommandType.StoredProcedure;
                        cmdAccount.CommandText = SP_INSERT_ACCOUNT;
                        SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                        sp.Direction = ParameterDirection.Output;
                        cmdAccount.Parameters.Add(sp);
                        DoInsertUpdate(cmdAccount);
                        Id = Convert.ToInt32(cmdAccount.Parameters["@ID"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void DoInsertUpdate(SqlCommand cmdAccount)
        {
            //cmdAccount.Parameters.AddWithValue("@AccountID", _AccountID);
            cmdAccount.Parameters.AddWithValue("@AccountName", _AccountName);
            cmdAccount.Parameters.AddWithValue("@AccountAdminID", _AccountAdminID);
            cmdAccount.Parameters.AddWithValue("@Address", _Address);
            cmdAccount.Parameters.AddWithValue("@City", _City);
            cmdAccount.Parameters.AddWithValue("@State", _State);
            cmdAccount.Parameters.AddWithValue("@Country", _Country);
            cmdAccount.Parameters.AddWithValue("@ZipPin", _ZipPin);

            cmdAccount.Parameters.AddWithValue("@Email", _Email);
            if (_ActivatedOn == System.DateTime.MinValue)
            {
                cmdAccount.Parameters.AddWithValue("@ActivatedOn",System.DBNull.Value);
            }
            else
            {
                cmdAccount.Parameters.AddWithValue("@ActivatedOn", _ActivatedOn);
            }
            
            cmdAccount.Parameters.AddWithValue("@numDaysToIndicateExpiry", _numDaysToIndicateExpiry);
            if (_CreatedOn == System.DateTime.MinValue)
            {
                cmdAccount.Parameters.AddWithValue("@CreatedOn", System.DBNull.Value);
            }
            else
            {
                cmdAccount.Parameters.AddWithValue("@CreatedOn", _CreatedOn);
            }
            if (_ExpirOn == System.DateTime.MinValue)
            {
                cmdAccount.Parameters.AddWithValue("@ExpirOn", System.DBNull.Value);
            }
            else
            {
                cmdAccount.Parameters.AddWithValue("@ExpirOn", _ExpirOn);
            }
            cmdAccount.Parameters.AddWithValue("@CreatedBy", _CreatedBy);
            cmdAccount.Parameters.AddWithValue("@Creditfunds", _Creditfunds);
            cmdAccount.Parameters.AddWithValue("@Billing_Address", _Billing_Address);
            cmdAccount.Parameters.AddWithValue("@Phone1", _Phone1);
            cmdAccount.Parameters.AddWithValue("@Phone2", _Phone2);

            cmdAccount.Parameters.AddWithValue("@Fax", _Fax);
            cmdAccount.Parameters.AddWithValue("@Email2", _Email2);
            cmdAccount.Parameters.AddWithValue("@URL", _URL);
            cmdAccount.Parameters.AddWithValue("@AccountType", _AccountType);
            if (_BillingDateTime == System.DateTime.MinValue)
            {
                cmdAccount.Parameters.AddWithValue("@BillingDateTime", System.DBNull.Value);
            }
            else
            {
                cmdAccount.Parameters.AddWithValue("@BillingDateTime", _BillingDateTime);
            }
            cmdAccount.Parameters.AddWithValue("@SubDomain", _SubDomain);
            cmdAccount.Parameters.AddWithValue("@GoogleMapKey", _GoogleMapKey);
            cmdAccount.Parameters.AddWithValue("@CustomizeType", _CustomizeType);
            cmdAccount.Parameters.AddWithValue("@NoOfUser", _NoOfUser);

            cmdAccount.Parameters.AddWithValue("@NoOfOrg", _NoOfOrg);
            cmdAccount.Parameters.AddWithValue("@NoOfCarrier", _NoOfCarrier);
            cmdAccount.Parameters.AddWithValue("@DNNGoogleMapKey", _DNNGoogleMapKey);
            cmdAccount.Parameters.AddWithValue("@DNNSubDomain", _DNNSubDomain);

            cmdAccount.ExecuteNonQuery();
        }

        public void Data_Update(int _id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdAccount = connection.CreateCommand())
                    {
                        cmdAccount.CommandType = CommandType.StoredProcedure;
                        cmdAccount.CommandText = SP_UPDATE_ACCOUNT;
                        cmdAccount.Parameters.Add("@Id", SqlDbType.Int).Value = _id;
                        DoInsertUpdate(cmdAccount);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public DataTable Data_AccountSelect()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdAccount = connection.CreateCommand())
                    {
                        cmdAccount.CommandType = CommandType.StoredProcedure;
                        cmdAccount.CommandText = SP_SELECT_ACCOUNT;
                        cmdAccount.Connection = connection;
                        //cmdProduct.Parameters.AddWithValue("@Id", ID);
                        SqlDataAdapter da = new SqlDataAdapter(cmdAccount);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable Data_SelectById(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = SP_SELECTBYID_ACCOUNT;
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public DataTable Data_SelByUserRole(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "ACCOUNT_SELECTBY_USERROLE";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public void Data_Delete(int _id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdAccount = connection.CreateCommand())
                    {
                        cmdAccount.CommandType = CommandType.StoredProcedure;
                        cmdAccount.CommandText = SP_DELETE_ACCOUNT;
                        cmdAccount.Connection = connection;
                        cmdAccount.Parameters.AddWithValue("@Id", _id);
                        cmdAccount.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion DataAccess
    }
}
