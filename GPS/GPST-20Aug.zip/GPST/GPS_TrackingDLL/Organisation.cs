﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{
    public class Organisation
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        #region Constants

        private const string SP_DELETE_ORGANISATION = "ORGANISATION_DELETE";
        private const string SP_INSERT_ORGANISATION = "ORGANIZATION_INSERT";
        private const string SP_SELECT_ORGANISATION = "ORGANIZATION_SELECT";
        private const string SP_SELECTALL_ORGANISATION = "ORGANIZATION_SELECTALL";
        private const string SP_UPDATE_ORGANISATION = "ORGANISATION_UPDATE";
       // private const string SP_UPDATE_ORGANISATION = "ORGANISATION_UPDATE";
        #endregion Constants

        #region Variable

        private int _id;
        private string _OrgName;
        private int _AccountID;
        private string _OrgAddress;
        private string _OrgCity;
        private string _OrgState;
        private string _OrgCountry;
        private string _OrgZipPin;
        private string _Email;
        private string _OrgLogoPath;
        private DateTime _CreatedOn;
        private DateTime _ExpirDate;
        private int _CreatedBy;
        private int _TimeZoneID;
        private Boolean _EnableSMSAlerts;
        private Boolean _EnableEmailAlerts;
        private DateTime _EmailNotifiedOn;
        private int _Email_IM;
        private int _SMS_IM;
        private int _Panic_EAI;
        private int _Panic_SMSAI;
        private int _Temperature_Email;
        private int _Temperature_SMS;
        private int _Geofence_Email;
        private int _Geofence_SMS;
        private int _Overspeed_Email;
        private int _Overspeed_SMS;
        private int _LowBattery_Email;
        private int _LowBattery_SMS;
        private int _DI_Email;
        private int _DI_SMS;
        private string _AlertGSMNO;
        private int _SMSQuota;

        #endregion Variable
        
        #region Properties

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string OrgName
        {
            get { return _OrgName; }
            set { _OrgName = value; }
        }
        public int AccountID
        {
            get { return _AccountID; }
            set { _AccountID = value; }
        }

        public string  OrgAddress
        {
            get { return _OrgAddress; }
            set { _OrgAddress = value; }
        }
        public string OrgCity
        {
            get { return _OrgCity; }
            set { _OrgCity = value; }
        }
        public string OrgState
        {
            get { return _OrgState; }
            set { _OrgState = value; }
        }
        public string OrgCountry
        {
            get { return _OrgCountry; }
            set { _OrgCountry = value; }
        }
        public string OrgZipPin
        {
            get { return _OrgZipPin; }
            set { _OrgZipPin = value; }
        }
        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        public string OrgLogoPath
        {
            get { return _OrgLogoPath; }
            set { _OrgLogoPath = value; }
        }
        public DateTime CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }
        public DateTime ExpirDate
        {
            get { return _ExpirDate; }
            set { _ExpirDate = value; }
        }
        public int CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }
        
        public int TimeZoneID
        {
            get { return _TimeZoneID; }
            set { _TimeZoneID = value; }
        }
        public Boolean EnableSMSAlerts
        {
            get { return _EnableSMSAlerts; }
            set { _EnableSMSAlerts = value; }
        }
        public Boolean EnableEmailAlerts
        {
            get { return _EnableEmailAlerts; }
            set { _EnableEmailAlerts = value; }
        }
        public DateTime EmailNotifiedOn
        {
            get { return _EmailNotifiedOn; }
            set { _EmailNotifiedOn = value; }
        }
        public int Email_IM
        {
            get { return _Email_IM; }
            set { _Email_IM = value; }
        }
        public int SMS_IM
        {
            get { return _SMS_IM; }
            set { _SMS_IM = value; }
        }
        public int Panic_EAI
        {
            get { return _Panic_EAI; }
            set { _Panic_EAI = value; }
        }
        public int Temperature_Email
        {
            get { return _Temperature_Email; }
            set { _Temperature_Email = value; }
        }
        public int Temperature_SMS
        {
            get { return _Temperature_SMS; }
            set { _Temperature_SMS = value; }
        }
        public int Geofence_Email
        {
            get { return _Geofence_Email; }
            set { _Geofence_Email = value; }
        }
        public int Geofence_SMS
        {
            get { return _Geofence_SMS; }
            set { _Geofence_SMS = value; }
        }
        public int Overspeed_Email
        {
            get { return _Overspeed_Email; }
            set { _Overspeed_Email = value; }
        }
        public int Overspeed_SMS
        {
            get { return _Overspeed_SMS; }
            set { _Overspeed_SMS = value; }
        }
        public int LowBattery_Email
        {
            get { return _LowBattery_Email; }
            set { _LowBattery_Email = value; }
        }
        public int LowBattery_SMS
        {
            get { return _LowBattery_SMS; }
            set { _LowBattery_SMS = value; }
        }
        public int DI_Email
        {
            get { return _DI_Email; }
            set { _DI_Email = value; }
        }
        public int DI_SMS
        {
            get { return _DI_SMS; }
            set { _DI_SMS = value; }
        }
        public string AlertGSMNO
        {
            get { return _AlertGSMNO; }
            set { _AlertGSMNO = value; }
        }
        public int SMSQuota
        {
            get { return _SMSQuota; }
            set { _SMSQuota = value; }
        }

        #endregion Properties

        #region DataAccess

        public void Data_Insert()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdOrgnistaion = connection.CreateCommand())
                    {
                        cmdOrgnistaion.CommandType = CommandType.StoredProcedure;
                        cmdOrgnistaion.CommandText = SP_INSERT_ORGANISATION;
                        SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                        sp.Direction = ParameterDirection.Output;
                        cmdOrgnistaion.Parameters.Add(sp);
                        DoInsertUpdate(cmdOrgnistaion);
                        Id = Convert.ToInt32(cmdOrgnistaion.Parameters["@ID"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void DoInsertUpdate(SqlCommand cmdOrgnistaion)
        {
            cmdOrgnistaion.Parameters.AddWithValue("@OrgName", _OrgName);
            cmdOrgnistaion.Parameters.AddWithValue("@AccountID", _AccountID);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgAddress", _OrgAddress);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgCity", _OrgCity);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgState", _OrgState);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgCountry", _OrgCountry);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgZipPin", _OrgZipPin);

            cmdOrgnistaion.Parameters.AddWithValue("@Email", _Email);
            cmdOrgnistaion.Parameters.AddWithValue("@OrgLogoPath", _OrgLogoPath);
            if (_CreatedOn == System.DateTime.MinValue)
            {
                cmdOrgnistaion.Parameters.AddWithValue("@CreatedOn", System.DBNull.Value);
            }
            else
            {
                cmdOrgnistaion.Parameters.AddWithValue("@CreatedOn", _CreatedOn);
            }
            if (_ExpirDate == System.DateTime.MinValue)
            {
                cmdOrgnistaion.Parameters.AddWithValue("@ExpiryDate", System.DBNull.Value);
            }
            else
            {
                cmdOrgnistaion.Parameters.AddWithValue("@ExpiryDate", _ExpirDate);
            }
            cmdOrgnistaion.Parameters.AddWithValue("@CreatedBy", _CreatedBy);//
            cmdOrgnistaion.Parameters.AddWithValue("@TimeZoneID", _TimeZoneID);
            cmdOrgnistaion.Parameters.AddWithValue("@EnableSMSAlerts", _EnableSMSAlerts);
            cmdOrgnistaion.Parameters.AddWithValue("@EnableEmailAlerts", _EnableEmailAlerts);
            if (_EmailNotifiedOn == System.DateTime.MinValue)
            {
                cmdOrgnistaion.Parameters.AddWithValue("@EmailNotifiedOn",System.DBNull.Value );
            }
            else
            {
                cmdOrgnistaion.Parameters.AddWithValue("@EmailNotifiedOn", _EmailNotifiedOn);
            }
            cmdOrgnistaion.Parameters.AddWithValue("@Default_Email_Interval_Min", _Email_IM);
            cmdOrgnistaion.Parameters.AddWithValue("@Default_SMS_Interval_Min", _SMS_IM);
            cmdOrgnistaion.Parameters.AddWithValue("@Panic_Email_Alart_interval", _Panic_EAI);
            cmdOrgnistaion.Parameters.AddWithValue("@Panic_SMS_Alart_interval", _Panic_SMSAI);

            cmdOrgnistaion.Parameters.AddWithValue("@Temperature_Email_Alart_interval", _Temperature_Email);
            cmdOrgnistaion.Parameters.AddWithValue("@Temperature_SMS_Alart_interval", _Temperature_SMS);
            cmdOrgnistaion.Parameters.AddWithValue("@Geofence_Email_Alart_interval", _Geofence_Email);
            cmdOrgnistaion.Parameters.AddWithValue("@Geofence_SMS_Alart_interval", _Geofence_SMS);
            cmdOrgnistaion.Parameters.AddWithValue("@Overspeed_Email_Alart_interval", _Overspeed_Email);

            cmdOrgnistaion.Parameters.AddWithValue("@Overspeed_SMS_Alart_interval", _Overspeed_SMS);
            cmdOrgnistaion.Parameters.AddWithValue("@LowBattery_Email_Alart_interval", _LowBattery_Email);
            cmdOrgnistaion.Parameters.AddWithValue("@LowBattery_SMS_Alart_interval", _LowBattery_SMS);
            cmdOrgnistaion.Parameters.AddWithValue("@DI_Email_Alart_interval", _DI_Email);
            cmdOrgnistaion.Parameters.AddWithValue("@DI_SMS_Alart_interval", _DI_SMS);
            cmdOrgnistaion.Parameters.AddWithValue("@AlertGSMNO", _AlertGSMNO);
            cmdOrgnistaion.Parameters.AddWithValue("@SMSQuota", _SMSQuota);
            cmdOrgnistaion.ExecuteNonQuery();
        }

        public void Data_Update(int _id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdOrgnistaion = connection.CreateCommand())
                    {
                        cmdOrgnistaion.CommandType = CommandType.StoredProcedure;
                        cmdOrgnistaion.CommandText = SP_UPDATE_ORGANISATION;
                        cmdOrgnistaion.Parameters.Add("@Id", SqlDbType.Int).Value = _id;
                        DoInsertUpdate(cmdOrgnistaion);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public DataTable Data_Select_CreatedBy(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdOrganisation = connection.CreateCommand())
                    {
                        cmdOrganisation.CommandType = CommandType.StoredProcedure;
                        cmdOrganisation.CommandText = "ORGANIZATION_SELECT_CREATEDBY";
                        cmdOrganisation.Connection = connection;
                        cmdOrganisation.Parameters.AddWithValue("@CreatedBy", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdOrganisation);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        

        public DataTable Data_OrgData()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdOrganisation = connection.CreateCommand())
                    {
                        cmdOrganisation.CommandType = CommandType.StoredProcedure;
                        cmdOrganisation.CommandText = SP_SELECT_ORGANISATION;
                        cmdOrganisation.Connection = connection;
                       // cmdOrganisation.Parameters.AddWithValue("@CreatedBy", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdOrganisation);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public DataTable Data_SelectAll()
        {
            DataTable dtCountry = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCountry = connection.CreateCommand())
                    {
                        cmdCountry.CommandType = CommandType.StoredProcedure;
                        cmdCountry.CommandText = SP_SELECTALL_ORGANISATION;
                        SqlDataAdapter dabilling = new SqlDataAdapter(cmdCountry);
                        dabilling.Fill(dtCountry);
                    }
                    return dtCountry;
                }

            }
            catch (Exception ex)
            {
            }
            return null;
        }

        public DataTable Data_SelectById(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "ORGANIZATION_SELECTBY_ID";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public DataTable Data_SelByUserRole(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "ORGANIZATION_SELECTBY_USERROLE";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        public void Data_Delete(int _id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdOrg = connection.CreateCommand())
                    {
                        cmdOrg.CommandType = CommandType.StoredProcedure;
                        cmdOrg.CommandText = SP_DELETE_ORGANISATION;
                        cmdOrg.Connection = connection;
                        cmdOrg.Parameters.AddWithValue("@Id", _id);
                        cmdOrg.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion DataAccess
    }
}
