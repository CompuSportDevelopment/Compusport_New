﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GPS_TrackingDLL
{
    public class City
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        #region Constants
        private const string SP_SELECT_CITY = "CITY_SELECT";
        private const string SP_SELECTALL_CITY = "CITY_SELECTALL";
        private const string SP_SELECTBYID_CITY = "CITY_SELECTBYID";
        #endregion Constans

        #region DataAccess

        public DataTable Data_SelectByID(int CountryID)
        {
            DataTable dtCountry = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCountry = connection.CreateCommand())
                    {
                        cmdCountry.CommandType = CommandType.StoredProcedure;
                        cmdCountry.CommandText = SP_SELECTBYID_CITY;
                        cmdCountry.Parameters.AddWithValue("@CountryId", CountryID);
                        SqlDataAdapter dabilling = new SqlDataAdapter(cmdCountry);
                        dabilling.Fill(dtCountry);
                    }
                    return dtCountry;
                }

            }
            catch (Exception ex)
            {
            }
            return null;
        }

        

        #endregion DataAccess
    }
}
