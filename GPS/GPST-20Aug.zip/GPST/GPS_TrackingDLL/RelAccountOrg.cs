﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{

    public class RelAccountOrg
    {

        private int Id;

        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        public void Data_Insert(int AcntID, int OrgID)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdRelAccountOrg = connection.CreateCommand())
                    {
                        cmdRelAccountOrg.CommandType = CommandType.StoredProcedure;
                        cmdRelAccountOrg.CommandText = "RELACCOUNTORG_INSERT";
                        SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                        sp.Direction = ParameterDirection.Output;
                        cmdRelAccountOrg.Parameters.Add(sp);

                        cmdRelAccountOrg.Parameters.AddWithValue("@AccountID", AcntID);
                        cmdRelAccountOrg.Parameters.AddWithValue("@OrgID", OrgID);
                       // cmdRelAccountOrg.Parameters.AddWithValue("@UserId", UserId);

                        cmdRelAccountOrg.ExecuteNonQuery();

                        Id = Convert.ToInt32(cmdRelAccountOrg.Parameters["@ID"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        //public void DoInsertUpdate(SqlCommand cmdOrgnistaion)
        //{
        //    cmdOrgnistaion.Parameters.AddWithValue("@OrgName", _OrgName);
        //    cmdOrgnistaion.Parameters.AddWithValue("@AccountID", _AccountID);
        //    cmdOrgnistaion.Parameters.AddWithValue("@OrgAddress", _OrgAddress);
        //    cmdOrgnistaion.Parameters.AddWithValue("@OrgCity", _OrgCity);

        //    cmdOrgnistaion.ExecuteNonQuery();
        //}

        public DataTable Data_SelectById(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "RELACCOUNTORG_SELECTBY_ID";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }
    }
}
