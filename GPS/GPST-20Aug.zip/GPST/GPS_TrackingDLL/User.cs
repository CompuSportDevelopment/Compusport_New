﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{
   public class User
    {
       string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

       #region Constants

       private const string SP_DELETE_USER = "USER_DELETE";
       private const string SP_INSERT_USER = "USER_INSERT";
       private const string SP_SELECT_USER = "USER_SELECT";
       private const string SP_SELECTALL_USER = "USER_SELECTALL";
       private const string SP_UPDATE_USER = "USER_UPDATE";

       #endregion Constants

       #region Variable
       private int _id;
       private string _loginId;
       private string _UserName;
       private string _EmailId;
       private string _loginPwd;
       private string _Details;
       private string _CreatedBy;
       private DateTime _CreatedOn;
       private int _RoleId;
       #endregion Variable

       #region Properties

       public int Id
       {
           get { return _id; }
           set { _id = value; }
       }
       public string LoginId
       {
           get { return _loginId; }
           set { _loginId = value; }
       }
       public string UserName
       {
           get { return _UserName; }
           set { _UserName = value; }
       }

       public string LoginPwd
       {
           get { return _loginPwd; }
           set { _loginPwd = value; }
       }
       public string EmailAddress
       {
           get { return _EmailId; }
           set { _EmailId = value; }
       }
       public string Details
       {
           get { return _Details; }
           set { _Details = value; }
       }
       public string CreatedBy
       {
           get { return _CreatedBy; }
           set { _CreatedBy = value; }
       }
       public int RoleId
       {
           get { return _RoleId; }
           set { _RoleId = value; }
       }
       public DateTime CreatedOn
       {
           get { return _CreatedOn; }
           set { _CreatedOn = value; }
       }

       #endregion Properties

       #region DataAccess

       public void Data_Insert()
       {
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdLogin = connection.CreateCommand())
                   {
                       cmdLogin.CommandType = CommandType.StoredProcedure;
                       cmdLogin.CommandText = SP_INSERT_USER;
                       SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                       sp.Direction = ParameterDirection.Output;
                       cmdLogin.Parameters.Add(sp);
                       DoInsertUpdate(cmdLogin);
                       Id = Convert.ToInt32(cmdLogin.Parameters["@ID"].Value);
                   }
               }
           }
           catch (Exception ex)
           {
           }
       }

       public void DoInsertUpdate(SqlCommand cmdLogin)
       {
           cmdLogin.Parameters.AddWithValue("@loginId", _loginId);
           cmdLogin.Parameters.AddWithValue("@UserName", _UserName);
           cmdLogin.Parameters.AddWithValue("@Email", _EmailId);
           cmdLogin.Parameters.AddWithValue("@loginPwd", _loginPwd);
           cmdLogin.Parameters.AddWithValue("@Details", _Details);
           cmdLogin.Parameters.AddWithValue("@CreatedBy", _CreatedBy);
           if (_CreatedOn == System.DateTime.MinValue)
           {
               cmdLogin.Parameters.AddWithValue("@CreatedOn", System.DBNull.Value);
           }
           else
           {
               cmdLogin.Parameters.AddWithValue("@CreatedOn", _CreatedOn);
           }
           cmdLogin.Parameters.AddWithValue("@Role", _RoleId);
           cmdLogin.ExecuteNonQuery();
       }

       public DataTable CheckUser(string UserName, string Pass)
       {
           DataTable dtUser = new DataTable();
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {

                   connection.Open();
                   using (SqlCommand cmdUser = connection.CreateCommand())
                   {
                       cmdUser.CommandType = CommandType.StoredProcedure;
                       cmdUser.CommandText = "USER_CheckPassword";
                       cmdUser.Connection = connection;
                       cmdUser.Parameters.AddWithValue("@UserName", UserName);
                       cmdUser.Parameters.AddWithValue("@Password", Pass);
                       SqlDataAdapter daCommon = new SqlDataAdapter(cmdUser);
                       daCommon.Fill(dtUser);
                   }
                   return dtUser;
               }
           }
           catch (Exception ex)
           {
               return dtUser;
           }
       }

       public DataTable Data_SelectAllRoles()
       {
           DataTable dtRoles = new DataTable();
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdCountry = connection.CreateCommand())
                   {
                       cmdCountry.CommandType = CommandType.StoredProcedure;
                       cmdCountry.CommandText = "USER_ROLE_SELECTALL";
                       SqlDataAdapter da = new SqlDataAdapter(cmdCountry);
                       da.Fill(dtRoles);
                   }
                   return dtRoles;
               }

           }
           catch (Exception ex)
           {

           }
           return null;
       }

       public DataTable Data_SelectAll()
       {
           DataTable dt = new DataTable();
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdUser = connection.CreateCommand())
                   {
                       cmdUser.CommandType = CommandType.StoredProcedure;
                       cmdUser.CommandText = SP_SELECTALL_USER;
                       cmdUser.Connection = connection;
                       SqlDataAdapter da = new SqlDataAdapter(cmdUser);
                       da.Fill(dt);
                   }
                   return dt;
               }
           }
           catch (Exception ex)
           {
               return null;
           }
       }

       public DataTable Data_SelectById(int Id)
       {
           DataTable dt = new DataTable();
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                   {
                       cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                       cmdCatalogProduct.CommandText = "USER_SELECTBY_ID";
                       cmdCatalogProduct.Connection = connection;
                       cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                       SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                       da.Fill(dt);
                   }
                   return dt;
               }
           }
           catch (Exception ex)
           {
               return dt = null;
           }
       }

       public void Data_Update(int _id)
       {
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdOrgnistaion = connection.CreateCommand())
                   {
                       cmdOrgnistaion.CommandType = CommandType.StoredProcedure;
                       cmdOrgnistaion.CommandText = SP_UPDATE_USER;
                       cmdOrgnistaion.Parameters.Add("@Id", SqlDbType.Int).Value = _id;
                       DoInsertUpdate(cmdOrgnistaion);
                   }
               }
           }
           catch (Exception ex)
           {

           }
       }

       public void Data_Delete(int _id)
       {
           DataTable dt = new DataTable();
           try
           {
               using (SqlConnection connection = new SqlConnection(Connstr))
               {
                   connection.Open();
                   using (SqlCommand cmdAccount = connection.CreateCommand())
                   {
                       cmdAccount.CommandType = CommandType.StoredProcedure;
                       cmdAccount.CommandText = SP_DELETE_USER;
                       cmdAccount.Connection = connection;
                       cmdAccount.Parameters.AddWithValue("@Id", _id);
                       cmdAccount.ExecuteNonQuery();
                       connection.Close();
                   }
               }
           }
           catch (Exception ex)
           {
           }
       }

       #endregion DataAccess
    }
}
