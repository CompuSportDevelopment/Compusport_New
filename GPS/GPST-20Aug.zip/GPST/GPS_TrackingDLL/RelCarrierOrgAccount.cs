﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPS_TrackingDLL
{
    public class RelCarrierOrgAccount
    {
        string Connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();

        #region Variable

        private int _id;
        private int _CarrierID;
        private int _AccountID;
        private int _OrgID;
        private DateTime _CreatedOn;
        private Boolean _IsActive;

        #endregion Variable

        #region Properties

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public int AccountID
        {
            get { return _AccountID; }
            set { _AccountID = value; }
        }
        public int OrgID
        {
            get { return _OrgID; }
            set { _OrgID = value; }
        }
        public int CarrierID
        {
            get { return _CarrierID; }
            set { _CarrierID = value; }
        }
        public Boolean IsActive
        {
            get { return _IsActive; }
            set { _IsActive = value; }
        }
        public DateTime CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }

        #endregion Properties

        #region DataAccess

        public void Data_Insert()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdAccount = connection.CreateCommand())
                    {
                        cmdAccount.CommandType = CommandType.StoredProcedure;
                        cmdAccount.CommandText = "RELCARRIERORGACCOUNT_INSERT";
                        SqlParameter sp = new SqlParameter("@ID", SqlDbType.Int);
                        sp.Direction = ParameterDirection.Output;
                        cmdAccount.Parameters.Add(sp);
                        DoInsertUpdate(cmdAccount);
                        Id = Convert.ToInt32(cmdAccount.Parameters["@ID"].Value);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void DoInsertUpdate(SqlCommand cmdAccount)
        {
            cmdAccount.Parameters.AddWithValue("@AccountID", _AccountID);
            cmdAccount.Parameters.AddWithValue("@OrgID", _OrgID);
            cmdAccount.Parameters.AddWithValue("@CarrierID", _CarrierID);
            if (_CreatedOn == System.DateTime.MinValue)
            {
                cmdAccount.Parameters.AddWithValue("@CreatedOn", System.DBNull.Value);
            }
            else
            {
                cmdAccount.Parameters.AddWithValue("@CreatedOn", _CreatedOn);
            }
            //cmdAccount.Parameters.AddWithValue("@State", _State);

            cmdAccount.ExecuteNonQuery();
        }

        public DataTable Data_SelectById(int Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(Connstr))
                {
                    connection.Open();
                    using (SqlCommand cmdCatalogProduct = connection.CreateCommand())
                    {
                        cmdCatalogProduct.CommandType = CommandType.StoredProcedure;
                        cmdCatalogProduct.CommandText = "RELCARRIERORGACCOUNT_SELECTBY_ID";
                        cmdCatalogProduct.Connection = connection;
                        cmdCatalogProduct.Parameters.AddWithValue("@Id", Id);
                        SqlDataAdapter da = new SqlDataAdapter(cmdCatalogProduct);
                        da.Fill(dt);
                    }
                    return dt;
                }
            }
            catch (Exception ex)
            {
                return dt = null;
            }
        }

        #endregion DataAccess
    }
}
