﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class Account : System.Web.UI.Page
{
    GPS_TrackingDLL.Account objAccount = new GPS_TrackingDLL.Account();
    Country objCountry = new Country();
    City objCity = new City();
    int _AccountId=0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["AccountID"] != null)
        {
            _AccountId = Convert.ToInt32(Request.QueryString["AccountID"]);
        }
        if (Session["UserId"] != null)
        {
            if (!IsPostBack)
            {
                Bind_DDl();
                if (_AccountId == 0)
                {

                }
                else
                {
                    Edit();
                }
            }
        }
        else
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
    }

    private void Edit()
    {
        DataTable dtAccount = objAccount.Data_SelectById(_AccountId);

        txtAccountName.Text = Convert.ToString(dtAccount.Rows[0]["AccountName"]);
        txtAccountAdminID.Text = Convert.ToString(dtAccount.Rows[0]["AccountAdminID"]);
        txtAddress.Text = Convert.ToString(dtAccount.Rows[0]["Address"]);
        ddlCountry.SelectedValue = Convert.ToString(dtAccount.Rows[0]["Country"]);
        Bind_City();
        ddlCity.SelectedValue = Convert.ToString(dtAccount.Rows[0]["City"]);//City
        txtState.Text = Convert.ToString(dtAccount.Rows[0]["State"]);
        txtZipPin.Text = Convert.ToString(dtAccount.Rows[0]["ZipPin"]);
        txtEmail.Text = Convert.ToString(dtAccount.Rows[0]["Email"]);
        txtActivatedOn.Text = Convert.ToString(dtAccount.Rows[0]["ActivatedOn"]);
        txtnumDaysToIndicateExpiry.Text = Convert.ToString(dtAccount.Rows[0]["numDaysToIndicateExpiry"]);
        txtCreatedOn.Text = Convert.ToString(dtAccount.Rows[0]["CreatedOn"]);
        txtExpirOn.Text = Convert.ToString(dtAccount.Rows[0]["ExpirOn"]);
        txtCreditfunds.Text = Convert.ToString(dtAccount.Rows[0]["Creditfunds"]);
        txtBilling_Address.Text = Convert.ToString(dtAccount.Rows[0]["Billing_Address"]);
        txtPhone1.Text = Convert.ToString(dtAccount.Rows[0]["Phone1"]);
        txtPhone2.Text = Convert.ToString(dtAccount.Rows[0]["Phone2"]);
        txtFax.Text = Convert.ToString(dtAccount.Rows[0]["Fax"]);
        txtEmail2.Text = Convert.ToString(dtAccount.Rows[0]["Email2"]);
        txtURL.Text = Convert.ToString(dtAccount.Rows[0]["URL"]);
        txtAccountType.Text = Convert.ToString(dtAccount.Rows[0]["AccountType"]);
        txtBillingDateTime.Text = Convert.ToString(dtAccount.Rows[0]["BillingDateTime"]);
        txtSubDomain.Text = Convert.ToString(dtAccount.Rows[0]["SubDomain"]);
        txtGoogleMapKey.Text = Convert.ToString(dtAccount.Rows[0]["GoogleMapKey"]);
        txtCustomizeType.Text = Convert.ToString(dtAccount.Rows[0]["CustomizeType"]);
        txtNoOfOrg.Text = Convert.ToString(dtAccount.Rows[0]["NoOfOrg"]);
        txtNoOfUser.Text = Convert.ToString(dtAccount.Rows[0]["NoOfUser"]);
        txtNoOfCarrier.Text = Convert.ToString(dtAccount.Rows[0]["NoOfCarrier"]);
        txtDNNGoogleMapKey.Text = Convert.ToString(dtAccount.Rows[0]["DNNGoogleMapKey"]);
        txtDNNSubDomain.Text = Convert.ToString(dtAccount.Rows[0]["DNNSubDomain"]);
    }

    private void Bind_DDl()
    {
        Bind_Country();
        Bind_City();
    }

    private void Bind_City()
    {
        DataTable dtCity =  objCity.Data_SelectByID(Convert.ToInt32(ddlCountry.SelectedValue));
        ddlCity.DataSource = dtCity;
        ddlCity.DataTextField = "City";
        ddlCity.DataValueField = "CityId";
        ddlCity.DataBind();
        ddlCity.Items.Insert(0, new ListItem("Select", "0"));
        
    }

    private void Bind_Country()
    {
        DataTable dtCountry = objCountry.Data_SelectAll();
        ddlCountry.DataSource = dtCountry;
        ddlCountry.DataTextField = "Country";
        ddlCountry.DataValueField = "CountryId";
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("Select", "0"));
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (CheckValidation())
            {
                objAccount.AccountName = txtAccountName.Text;
                objAccount.AccountAdminID = Convert.ToInt32(txtAccountAdminID.Text);
                objAccount.Address = txtAddress.Text;
                objAccount.City = Convert.ToString(ddlCity.SelectedValue);
                objAccount.State = Convert.ToString(txtState.Text);
                objAccount.Country = Convert.ToString(ddlCountry.SelectedValue);
                objAccount.ZipPin = Convert.ToString(txtZipPin.Text);
                objAccount.Email = Convert.ToString(txtEmail.Text);
                if (txtActivatedOn.Text == "")
                {
                    objAccount.ActivatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objAccount.ActivatedOn = Convert.ToDateTime(txtActivatedOn.Text);
                }
                if (txtnumDaysToIndicateExpiry.Text == "")
                {
                    txtnumDaysToIndicateExpiry.Text = "0";
                }
                objAccount.numDaysToIndicateExpiry = Convert.ToInt32(txtnumDaysToIndicateExpiry.Text);
                if (txtCreatedOn.Text == "")
                {
                    objAccount.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objAccount.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text); ;
                }
                if (txtExpirOn.Text == "")
                {
                    objAccount.ExpirOn = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objAccount.ExpirOn = Convert.ToDateTime(txtExpirOn.Text);
                }
                objAccount.CreatedBy = Convert.ToInt32(Session["UserId"]);//Take Session At user Login
                if (txtCreditfunds.Text == "")
                {
                    txtCreditfunds.Text = "0";
                }
                objAccount.Creditfunds = Convert.ToDecimal(txtCreditfunds.Text);
                objAccount.Billing_Address = Convert.ToString(txtBilling_Address.Text);
                objAccount.Phone1 = txtPhone1.Text;
                objAccount.Phone2 = txtPhone2.Text;
                objAccount.Fax = txtFax.Text;
                objAccount.Email2 = txtEmail2.Text;
                objAccount.URL = txtURL.Text;
                objAccount.AccountType = txtAccountType.Text;
                if (txtBillingDateTime.Text == "")
                {
                    objAccount.BillingDateTime = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objAccount.BillingDateTime = Convert.ToDateTime(txtBillingDateTime.Text);
                }
                objAccount.SubDomain = txtSubDomain.Text;
                objAccount.GoogleMapKey = txtGoogleMapKey.Text;
                objAccount.CustomizeType = txtCustomizeType.Text;
                objAccount.NoOfOrg = txtNoOfOrg.Text;
                objAccount.NoOfUser = txtNoOfUser.Text;
                objAccount.NoOfCarrier = txtNoOfCarrier.Text;
                objAccount.DNNGoogleMapKey = txtDNNGoogleMapKey.Text;
                objAccount.DNNSubDomain = txtDNNSubDomain.Text;

                if (_AccountId == 0)
                {
                    objAccount.Data_Insert();
                    Session["AccountId"] = objAccount.Id;
                }
                else
                {
                    objAccount.Data_Update(_AccountId);
                    _AccountId = 0;
                }
                ClearAll();
                AccountModalPopupExtender.Show();
                //string strSave = "Record Successfuly Inserted.";
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('" + strSave + "');", true);//.Replace("'", "\'") 
                objAccount = null;
            }
            
        }
        catch (Exception ex)
        { 

        }
    }

    private bool CheckValidation()
    {
        return true;
        //throw new NotImplementedException();
    }

    private void ClearAll()
    {
        txtAccountName.Text = "";
        txtAccountAdminID.Text="";
        txtAddress.Text="";
        ddlCity.SelectedItem.Text="";
        txtState.Text="";
        ddlCountry.SelectedItem.Text="";
        txtZipPin.Text="";
        txtEmail.Text="";
        txtActivatedOn.Text="";
        txtnumDaysToIndicateExpiry.Text = "";
        txtCreatedOn.Text="";
        txtExpirOn.Text="";
        txtCreditfunds.Text="";
        txtBilling_Address.Text="";
        txtPhone1.Text="";
        txtPhone2.Text="";
        txtFax.Text="";
        txtEmail2.Text="";
        txtURL.Text="";
        txtAccountType.Text="";
        txtBillingDateTime.Text="";
        txtSubDomain.Text="";
        txtGoogleMapKey.Text="";
        txtCustomizeType.Text="";
        txtNoOfOrg.Text="";
        txtNoOfUser.Text="";
        txtNoOfCarrier.Text="";
        txtDNNGoogleMapKey.Text="";
        txtDNNSubDomain.Text="";
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind_City();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AccountMaster.aspx");
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        Response.Redirect("AccountMaster.aspx");
    }
    protected void lblClose_Click1(object sender, EventArgs e)
    {
        Response.Redirect("AccountMaster.aspx");
    }
}
