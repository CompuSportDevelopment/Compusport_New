﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GPS_TrackingDLL;

public partial class ViewOrganisationInfo : System.Web.UI.Page
{
    int _OrgID = 0;
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();
    GPS_TrackingDLL.RelCarrierOrgAccount objRelCarrierOrgAccount = new GPS_TrackingDLL.RelCarrierOrgAccount();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["OrganisationID"] != null)
        {
            DisplayMenu();
            _OrgID = Convert.ToInt32(Request.QueryString["OrganisationID"]);
        }
        if (!IsPostBack)
        {
            BindGrid(_OrgID);
        }
    }


    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            Control tblmenu = this.Master.FindControl("tblmenu");
            tblmenu.Visible = false;
        }
    }

    private void BindGrid(int _OrgID)
    {
        DataTable dt = objRelCarrierOrgAccount.Data_SelectById(_OrgID);
        gvOrganisation.DataSource = dt;
        gvOrganisation.DataBind();
    }
}
