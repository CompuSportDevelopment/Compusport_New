﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    GPS_TrackingDLL.User objUser = new GPS_TrackingDLL.User();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtLogin.Text = "";
            txtPassword.Text = "";
            lblErrorMsg.Text = "";
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        lblErrorMsg.Text = "";
        DataTable dtUser = objUser.CheckUser(txtLogin.Text, txtPassword.Text);
        if (dtUser.Rows.Count > 0)
        {
            Session["UserId"] = dtUser.Rows[0]["Id"].ToString();
            Session["UserRole"] = dtUser.Rows[0]["userRole"].ToString();
            Response.Redirect("CarrierMaster.aspx");
        }
        else
        {
            lblErrorMsg.Text = "Please Enter Correct LoginId and Password.";
        }
    }
}
