﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GPS_TrackingDLL;

public partial class UserMaster : System.Web.UI.Page
{
    GPS_TrackingDLL.User objUser = new GPS_TrackingDLL.User();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] != null)
        {
            DisplayMenu();
            if (Convert.ToString(Session["UserRole"]) == "SuperUser")
            {
                BindGrid();
            }
            else
            {
                BindGridAdmin(Convert.ToInt32(Session["UserId"]));
            }
        }
        else
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
    }



    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            {
                Control hrefAccount = this.Master.FindControl("hrefAccount");
                hrefAccount.Visible = false;
                Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
                hrefOrganisation.Visible = false;
                //Control hrefCarrier = this.Master.FindControl("hrefCarrier");
                //hrefCarrier.Visible = false;
                Control hrefUser = this.Master.FindControl("hrefUser");
                hrefUser.Visible = false;
            }
            if (Convert.ToString(Session["UserRole"]) == "Admin")
            {
                Control hrefUser = this.Master.FindControl("hrefAccount");
                hrefUser.Visible = false;
            }
        }
    }

    private void BindGridAdmin(int _userId)
    {
        DataTable dt = objUser.Data_SelectById(_userId);
        gvUser.DataSource = dt;
        gvUser.DataBind();
    }

    private void BindGrid()
    {
        DataTable dtUser = objUser.Data_SelectAll();
        gvUser.DataSource = dtUser;
        gvUser.DataBind();
    }

    protected void gvUser_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int UserID = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Edit")
        {
            Response.Redirect("User.aspx?UserID=" + UserID);
        }
        else if (e.CommandName == "Delete")
        {
            objUser.Data_Delete(UserID);
            BindGrid();
        }
        else if (e.CommandName == "View")
        {
            Response.Redirect("ViewUserInfo.aspx?UserID=" + UserID);
        }
    }

    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("User.aspx");
    }

    protected void gvUser_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }

    protected void gvUser_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
}
