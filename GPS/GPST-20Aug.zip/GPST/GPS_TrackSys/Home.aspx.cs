﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            {
                Control hrefAccount = this.Master.FindControl("hrefAccount");
                hrefAccount.Visible = false;
                Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
                hrefOrganisation.Visible = false;
                //Control hrefCarrier = this.Master.FindControl("hrefCarrier");
                //hrefCarrier.Visible = false;
                Control hrefUser = this.Master.FindControl("hrefUser");
                hrefUser.Visible = false;
            }
            if (Convert.ToString(Session["UserRole"]) == "Admin")
            {
                Control hrefUser = this.Master.FindControl("hrefAccount");
                hrefUser.Visible = false;
            }
        }
        else
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
           
    }
}
