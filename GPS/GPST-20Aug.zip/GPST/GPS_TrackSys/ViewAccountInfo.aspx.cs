﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GPS_TrackingDLL;

public partial class ViewAccountInfo : System.Web.UI.Page
{
    GPS_TrackingDLL.RelAccountOrg objRelAccountOrg = new GPS_TrackingDLL.RelAccountOrg();
    int _AccountId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["AccountID"] != null)
        {
            DisplayMenu();
            _AccountId = Convert.ToInt32(Request.QueryString["AccountID"]);
        }
        if (!IsPostBack)
        {
            BindGrid(_AccountId);
        }
    }


    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            Control tblmenu = this.Master.FindControl("tblmenu");
            tblmenu.Visible = false;
        }
    }

    private void BindGrid(int _AccountId)
    {
        DataTable dt = objRelAccountOrg.Data_SelectById(_AccountId);
        gvAccount.DataSource = dt;
        gvAccount.DataBind();
    }
}
