﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class User : System.Web.UI.Page
{
    int UserID = 0;
    GPS_TrackingDLL.User objUser = new GPS_TrackingDLL.User();
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();
    GPS_TrackingDLL.Organisation objOrganisation = new GPS_TrackingDLL.Organisation();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["UserID"] != null)
        {
            UserID = Convert.ToInt32(Request.QueryString["UserID"]);
        }
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                BindRole();
                BindOrg();
                if (UserID != 0)
                {
                    Edit();
                }
            }
            else
            {
                Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
            }
        }
    }

    private void BindOrg()
    {
        DataTable dtOrg = objOrganisation.Data_OrgData();
        ddlOrganisation.DataSource = dtOrg;
        ddlOrganisation.DataTextField = "OrgName";
        ddlOrganisation.DataValueField = "OrgID";
        ddlOrganisation.DataBind();
    }

    private void Edit()
    {
        DataTable dt = objUser.Data_SelectById(UserID);
        txtLoginID.Text = dt.Rows[0]["LoginID"].ToString();
        txtUserName.Text = dt.Rows[0]["UserName"].ToString();
        txtEmail.Text = dt.Rows[0]["Email"].ToString();
        txtPassword.Text = dt.Rows[0]["LoginPwd"].ToString();
        txtDetails.Text = dt.Rows[0]["Details"].ToString();
        txtCreatedBy.Text = dt.Rows[0]["CreatedBy"].ToString();
        ddlRole.SelectedValue = dt.Rows[0]["Role"].ToString();
    }

    private void BindRole()
    {
        DataTable dtUser = objUser.Data_SelectAllRoles();
        ddlRole.DataSource = dtUser;
        ddlRole.DataValueField = "Id";
        ddlRole.DataTextField = "Role";
        ddlRole.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
                objUser.LoginId = txtLoginID.Text;
                objUser.UserName = txtUserName.Text;
                objUser.EmailAddress = txtEmail.Text;
                objUser.LoginPwd = txtPassword.Text;
                objUser.Details = txtDetails.Text;
                objUser.CreatedBy = txtCreatedBy.Text;
                if (txtCreatedOn.Text == "")
                {
                    objUser.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objUser.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text);
                }
                
                objUser.RoleId = Convert.ToInt32(ddlRole.SelectedValue);

                if (UserID == 0)
                {
                    objUser.Data_Insert();
                    
                }
                else
                {
                    objUser.Data_Update(UserID);
                }

                objRelUserOrg.UserID = Convert.ToInt32(objUser.Id);
                objRelUserOrg.AccountID = Convert.ToInt32(Session["AccountId"]);
                objRelUserOrg.OrgID = Convert.ToInt32(ddlOrganisation.SelectedValue);
                if (txtCreatedOn.Text == "")
                {
                    objRelUserOrg.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objRelUserOrg.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text);
                }
                objRelUserOrg.Data_Insert();

                ClearAll();
                UserModalPopupExtender.Show();
               // Response.Redirect("UserMaster.aspx");
         }
        catch(Exception ex)
        {

        }
    }


    private void ClearAll()
    {
        txtLoginID.Text = "";
        txtUserName.Text = "";
        txtEmail.Text = "";
        txtPassword.Text = "";
        txtConfirmPassword.Text = "";
        txtDetails.Text = "";
        txtCreatedBy.Text = "";
        BindRole();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserMaster.aspx");
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserMaster.aspx");
    }
    protected void lblClose_Click1(object sender, EventArgs e)
    {
        Response.Redirect("UserMaster.aspx");
    }
}
