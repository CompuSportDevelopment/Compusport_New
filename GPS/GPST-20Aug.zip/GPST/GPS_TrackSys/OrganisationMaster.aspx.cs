﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class OrganisationMaster : System.Web.UI.Page
{
    GPS_TrackingDLL.Organisation objOrganisation = new GPS_TrackingDLL.Organisation();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DisplayMenu();

            if (Session["UserId"] != null)
            {
                if (Convert.ToString(Session["UserRole"]) == "SuperUser")
                {
                    BindGrid();
                }
                else
                {
                    BindGridAdmin(Convert.ToInt32(Session["UserId"]));
                }
                
            }
            else
            { 
            }
        }
    }

    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            {
                Control hrefAccount = this.Master.FindControl("hrefAccount");
                hrefAccount.Visible = false;
                Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
                hrefOrganisation.Visible = false;
                //Control hrefCarrier = this.Master.FindControl("hrefCarrier");
                //hrefCarrier.Visible = false;
                Control hrefUser = this.Master.FindControl("hrefUser");
                hrefUser.Visible = false;
            }
            if (Convert.ToString(Session["UserRole"]) == "Admin")
            {
                Control hrefUser = this.Master.FindControl("hrefAccount");
                hrefUser.Visible = false;
            }
        }
    }


    private void BindGridAdmin(int _userId)
    {
        DataTable dt = objOrganisation.Data_SelByUserRole(_userId);
        gvOrganisation.DataSource = dt;
        gvOrganisation.DataBind();
    }

    private void BindGrid()
    {
        DataTable dt = objOrganisation.Data_SelectAll();
        gvOrganisation.DataSource = dt;
        gvOrganisation.DataBind();
    }
    protected void gvOrganisation_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int OrgID = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Edit")
        {
            Response.Redirect("Organisation.aspx?OrganisationID=" + OrgID);
        }
        else if (e.CommandName == "Delete")
        {
            objOrganisation.Data_Delete(OrgID);
            BindGrid();
        }
        else if (e.CommandName == "View")
        {
            Response.Redirect("ViewOrganisationInfo.aspx?OrganisationID=" + OrgID);
        }
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("Organisation.aspx");
    }
    protected void gvOrganisation_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvOrganisation_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
}
