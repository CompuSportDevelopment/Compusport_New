﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class DisplayUserInfo : System.Web.UI.Page
{
    int _UserId = 0;
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            //if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            //{
            //    Control hrefAccount = this.Master.FindControl("hrefAccount");
            //    hrefAccount.Visible = false;
            //    Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
            //    hrefOrganisation.Visible = false;
            //    Control hrefCarrier = this.Master.FindControl("hrefCarrier");
            //    hrefCarrier.Visible = false;
            //    Control hrefUser = this.Master.FindControl("hrefUser");
            //    hrefUser.Visible = false;

            //}
            //if (Convert.ToString(Session["UserRole"]) == "Admin")
            //{
            //    Control hrefUser = this.Master.FindControl("hrefUser");
            //    hrefUser.Visible = false;
            //}
            if (!IsPostBack)
            {
                _UserId = Convert.ToInt32(Session["UserId"]);
                BindGrid(_UserId);
            }
        }
        else
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
    }

    private void BindGrid(int _UserId)
    {
        DataTable dt = objRelUserOrg.Data_SelectById(_UserId);
        gvUser.DataSource = dt;
        gvUser.DataBind();
    }
}
