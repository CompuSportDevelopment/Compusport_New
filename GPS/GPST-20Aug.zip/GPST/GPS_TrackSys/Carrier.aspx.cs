﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class Carrier : System.Web.UI.Page
{
    GPS_TrackingDLL.carriers objcarriers = new GPS_TrackingDLL.carriers();
    GPS_TrackingDLL.Account objAccount = new GPS_TrackingDLL.Account();
    GPS_TrackingDLL.Organisation objOrganisation = new GPS_TrackingDLL.Organisation();
    GPS_TrackingDLL.RelCarrierOrgAccount objRelCarrierOrgAccount = new GPS_TrackingDLL.RelCarrierOrgAccount();
    int _CarrierID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["CarrierID"] != null)
        {
            _CarrierID = Convert.ToInt32(Request.QueryString["CarrierID"]);
        }
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                BindData();
                if (_CarrierID != 0)
                {
                    Edit();
                }
            }
            else
            {
                Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
            }
        }
    }

    private void Edit()
    {
        DataTable dtcarriers = objcarriers.Data_SelectById(_CarrierID);
        ddlAccountId.SelectedValue=dtcarriers.Rows[0]["AccountId"].ToString();
        ddlOrganisation.SelectedValue=dtcarriers.Rows[0]["OrgId"].ToString();
        txtCarrierName.Text=dtcarriers.Rows[0]["CarrierName"].ToString();
        txtIMEI.Text=dtcarriers.Rows[0]["IMEI"].ToString();
        txtCreatedOn.Text=dtcarriers.Rows[0]["CreatedOn"].ToString();
        
        if(Convert.ToBoolean(dtcarriers.Rows[0]["HasGeofence"].ToString())==true)
        {
            chkHasGeofence.Checked=true;
        }
        else
        {
            chkHasGeofence.Checked=false;
        }
        txtExpiryDate.Text=dtcarriers.Rows[0]["ExpiryDate"].ToString();
        txtAllocatedPortNo.Text=dtcarriers.Rows[0]["AllocatedPortNo"].ToString();
        if(dtcarriers.Rows[0]["IsActive"].ToString()=="1")
        {
         chkIsActive.Checked=true;
        }
        else
        {
            chkIsActive.Checked=false;
        }
        txtEmailId1.Text = dtcarriers.Rows[0]["EmailId1"].ToString();
        txtEmailId2.Text = dtcarriers.Rows[0]["EmailId2"].ToString();
        txtSMSQUOTA.Text = dtcarriers.Rows[0]["SMSQUOTA"].ToString();
        txtActivationDateTime.Text = dtcarriers.Rows[0]["ActivationDateTime"].ToString();
        txtLastEmailAlertDateTime.Text = dtcarriers.Rows[0]["LastEmailAlertDateTime"].ToString();
        txtEmailAlertDurationMinute.Text = dtcarriers.Rows[0]["EmailAlertDurationMinute"].ToString();
        txtapn.Text = dtcarriers.Rows[0]["apn"].ToString();
        txtGSMNo.Text = dtcarriers.Rows[0]["GSMNo"].ToString();
        txtExpiryAlertBeforeDays.Text = dtcarriers.Rows[0]["ExpiryAlertBeforeDays"].ToString();
        txtExpiryAlertAfterDays.Text = dtcarriers.Rows[0]["ExpiryAlertAfterDays"].ToString();
        txtAlertSpeed.Text = dtcarriers.Rows[0]["AlertSpeed"].ToString();
        txtMaxAllowedSpeed.Text = dtcarriers.Rows[0]["MaxAllowedSpeed"].ToString();
        txtIconUrl.Text = dtcarriers.Rows[0]["IconUrl"].ToString();
    }

    private void BindData()
    {
        DataTable dtAccount = objAccount.Data_AccountSelect();
        ddlAccountId.DataSource = dtAccount;
        ddlAccountId.DataTextField = "AccountName";
        ddlAccountId.DataValueField = "AccountID";
        ddlAccountId.DataBind();

        DataTable dtOrg = objOrganisation.Data_OrgData();
        ddlOrganisation.DataSource = dtOrg;
        ddlOrganisation.DataTextField = "OrgName";
        ddlOrganisation.DataValueField = "OrgID";
        ddlOrganisation.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (CheckValidation())
            {
                objcarriers.UserId = Convert.ToInt32(Session["UserId"]);
                objcarriers.AccountId = Convert.ToInt32(ddlAccountId.SelectedValue);
                objcarriers.OrgId = Convert.ToInt32(ddlOrganisation.SelectedValue);
                objcarriers.CarrierName = Convert.ToString(txtCarrierName.Text);
                objcarriers.IMEI = Convert.ToString(txtIMEI.Text);
                objcarriers.CreatedOn = Convert.ToString(txtCreatedOn.Text);
                objcarriers.ExpireOn = Convert.ToString(txtCreatedOn.Text);

                objcarriers.CreatedBy = Convert.ToInt32(Session["UserId"]);//Convert.ToInt32(txt);
                if (chkHasGeofence.Checked == true)
                {
                    objcarriers.HasGeofence = true;
                }
                else
                {
                    objcarriers.HasGeofence = false;
                }

                //objcarriers.HasGeofence = (chkHasGeofence.Checked) ? true : false;
                if (txtExpiryDate.Text == "")
                {
                    objcarriers.ExpiryDate = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objcarriers.ExpiryDate = Convert.ToDateTime(txtExpiryDate.Text);
                }
                if (txtAllocatedPortNo.Text == "")
                {
                    txtAllocatedPortNo.Text = "0";
                }
                objcarriers.AllocatedPortNo = Convert.ToInt32(txtAllocatedPortNo.Text);
                objcarriers.IsActive = (chkIsActive.Checked) ? true : false;
                objcarriers.EmailId1 = Convert.ToString(txtEmailId1.Text);
                objcarriers.EmailId2 = Convert.ToString(txtEmailId2.Text);
                objcarriers.SMSQUOTA = Convert.ToString(txtSMSQUOTA.Text);
                if (txtActivationDateTime.Text == "")
                {
                    objcarriers.ActivationDateTime = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objcarriers.ActivationDateTime = Convert.ToDateTime(txtActivationDateTime.Text);
                }
                if (txtLastEmailAlertDateTime.Text == "")
                {
                    objcarriers.LastEmailAlertDateTime = Convert.ToDateTime(System.DateTime.MinValue);
                }
                else
                {
                    objcarriers.LastEmailAlertDateTime = Convert.ToDateTime(txtLastEmailAlertDateTime.Text);
                }
                if (txtEmailAlertDurationMinute.Text == "")
                {
                    txtEmailAlertDurationMinute.Text = "0";
                }
                objcarriers.EmailAlertDurationMinute = Convert.ToInt32(txtEmailAlertDurationMinute.Text);
                objcarriers.Apn = Convert.ToString(txtapn.Text);
                objcarriers.GSMNo = Convert.ToString(txtGSMNo.Text);
                if (txtExpiryAlertBeforeDays.Text == "")
                {
                    txtExpiryAlertBeforeDays.Text="0";
                }
                objcarriers.ExpiryAlertBeforeDays = Convert.ToInt32(txtExpiryAlertBeforeDays.Text);
                if (txtExpiryAlertAfterDays.Text == "")
                {
                    txtExpiryAlertAfterDays.Text = "0";
                }
                objcarriers.ExpiryAlertAfterDays = Convert.ToInt32(txtExpiryAlertAfterDays.Text);
                if (txtAlertSpeed.Text == "")
                {
                    txtAlertSpeed.Text="0";
                }
                objcarriers.AlertSpeed = Convert.ToInt32(txtAlertSpeed.Text);
                if (txtMaxAllowedSpeed.Text == "")
                {
                    txtMaxAllowedSpeed.Text = "0";
                }
                objcarriers.MaxAllowedSpeed = Convert.ToInt32(txtMaxAllowedSpeed.Text);
                objcarriers.IconUrl = Convert.ToString(txtIconUrl.Text);
                if (_CarrierID == 0)
                {
                    objcarriers.Data_Insert();
                    objRelCarrierOrgAccount.AccountID = Convert.ToInt32(ddlAccountId.SelectedValue);
                    objRelCarrierOrgAccount.OrgID = Convert.ToInt32(ddlOrganisation.SelectedValue);
                    objRelCarrierOrgAccount.CarrierID = Convert.ToInt32(objcarriers.Id);
                    if (txtCreatedOn.Text == "")
                    {
                        objRelCarrierOrgAccount.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                    }
                    else
                    {
                        objRelCarrierOrgAccount.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text);
                    }
                    objRelCarrierOrgAccount.Data_Insert();
                }
                else
                {
                    objcarriers.Data_Update(_CarrierID);
                    _CarrierID = 0;
                }
                ClearAll();
                CarrierModalPopupExtender.Show();
            }
        }
        catch (Exception ex)
        {

        }
    }

    private bool CheckValidation()
    {
        if(txtIMEI.Text=="")
        {
            lblErrorMsg.Text = "Please Enter IMEI.";
            return false;
        }
        else
        {
            return true;
        }
    }


    private void ClearAll()
    {
        txtCarrierName.Text = "";
        txtIMEI.Text = "";
        txtCreatedOn.Text = "";
        txtExpireOn.Text = "";
        chkHasGeofence.Checked = false;
        txtExpiryDate.Text = "";
        txtAllocatedPortNo.Text = "";
        chkIsActive.Checked = false;
        txtEmailId1.Text = "";
        txtEmailId2.Text = "";
        txtSMSQUOTA.Text = "";
        txtActivationDateTime.Text = "";
        txtLastEmailAlertDateTime.Text = "";
        txtEmailAlertDurationMinute.Text = "";
        txtapn.Text = "";
        txtGSMNo.Text = "";
        txtExpiryAlertBeforeDays.Text = "";
        txtExpiryAlertAfterDays.Text = "";
        txtAlertSpeed.Text = "";
        txtMaxAllowedSpeed.Text = "";
        txtIconUrl.Text = "";

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CarrierMaster.aspx");
    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        Response.Redirect("CarrierMaster.aspx");
    }

    protected void lblClose_Click1(object sender, EventArgs e)
    {
        Response.Redirect("CarrierMaster.aspx");
    }
}
