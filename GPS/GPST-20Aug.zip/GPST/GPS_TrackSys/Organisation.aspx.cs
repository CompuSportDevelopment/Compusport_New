﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class Organisation : System.Web.UI.Page
{
    int OrganisationID = 0;
    GPS_TrackingDLL.Organisation objOrganisation = new GPS_TrackingDLL.Organisation();
    GPS_TrackingDLL.Account objAccount = new GPS_TrackingDLL.Account();
    GPS_TrackingDLL.City objCity = new GPS_TrackingDLL.City();
    GPS_TrackingDLL.Country objCountry = new GPS_TrackingDLL.Country();
    GPS_TrackingDLL.TimeZoneClass objTimeZoneClass = new GPS_TrackingDLL.TimeZoneClass();
    GPS_TrackingDLL.RelAccountOrg objRelAccountOrg = new GPS_TrackingDLL.RelAccountOrg();
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["OrganisationID"] != null)
        {
            OrganisationID = Convert.ToInt32(Request.QueryString["OrganisationID"]);
        }
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                BindDDl();
                BindData();
                if (OrganisationID != 0)
                {
                    Edit();
                }
            }
            else
            {
                Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
            }
        }
    }

    private void Edit()
    {
        DataTable dtOrg=objOrganisation.Data_SelectById(OrganisationID);
        txtOrgName.Text=dtOrg.Rows[0]["OrgName"].ToString();
        ddlOrgAccountId.SelectedValue=dtOrg.Rows[0]["AccountId"].ToString();
        txtOrgAddress.Text=dtOrg.Rows[0]["OrgAddress"].ToString();
        ddlOrgCountry.SelectedValue = dtOrg.Rows[0]["OrgCountry"].ToString();
        Bind_City();
        ddlOrgCity.SelectedValue=dtOrg.Rows[0]["OrgCity"].ToString();
        txtOrgState.Text=dtOrg.Rows[0]["OrgState"].ToString();
        
        txtOrgZipPin.Text=dtOrg.Rows[0]["OrgZipPin"].ToString();
        txtEmail.Text=dtOrg.Rows[0]["Email"].ToString();
        txtOrgLogoPath.Text=dtOrg.Rows[0]["OrgLogoPath"].ToString();
        txtExpiryDate.Text=dtOrg.Rows[0]["ExpiryDate"].ToString();
        txtCreatedOn.Text=dtOrg.Rows[0]["CreatedOn"].ToString();
        txtCreatedBy.Text=dtOrg.Rows[0]["CreatedBy"].ToString();
        ddlTimeZone.SelectedValue=dtOrg.Rows[0]["TimeZoneID"].ToString();
        if (Convert.ToBoolean(dtOrg.Rows[0]["EnableEmailAlerts"].ToString())==true)
        {
           chkEnableEmailAlerts.Checked=true;
        }
        else
        {
           chkEnableEmailAlerts.Checked=false;
        }
        if (Convert.ToBoolean(dtOrg.Rows[0]["EnableSMSAlerts"].ToString())==true)
        {
            chkEnableSMSAlerts.Checked = true;
        }
        else
        {
            chkEnableSMSAlerts.Checked = true;
        }
        txtEmailNotifiedOn.Text = dtOrg.Rows[0]["EmailNotifiedOn"].ToString();
        txtDefault_Email_Interval_Min.Text = dtOrg.Rows[0]["Default_Email_Interval_Min"].ToString();
        txtDefault_SMS_Interval_Min.Text = dtOrg.Rows[0]["Default_SMS_Interval_Min"].ToString();
        txtTemperature_Email_Alart_interval.Text = dtOrg.Rows[0]["Temperature_Email_Alart_interval"].ToString();
        txtTemperature_SMS_Alart_interval.Text = dtOrg.Rows[0]["Temperature_SMS_Alart_interval"].ToString();
        txtGeofence_Email_Alart_interval.Text = dtOrg.Rows[0]["Geofence_Email_Alart_interval"].ToString();
        txtGeofence_SMS_Alart_interval.Text = dtOrg.Rows[0]["Geofence_SMS_Alart_interval"].ToString();
        txtOverspeed_Email_Alart_interval.Text = dtOrg.Rows[0]["Overspeed_Email_Alart_interval"].ToString();
        txtOverspeed_SMS_Alart_interval.Text = dtOrg.Rows[0]["Overspeed_SMS_Alart_interval"].ToString();
        txtLowBattery_Email_Alart_interval.Text = dtOrg.Rows[0]["LowBattery_Email_Alart_interval"].ToString();
        txtLowBattery_SMS_Alart_interval.Text = dtOrg.Rows[0]["LowBattery_SMS_Alart_interval"].ToString();
        txtDI_Email_Alart_interval.Text = dtOrg.Rows[0]["DI_Email_Alart_interval"].ToString();
        txtDI_SMS_Alart_interval.Text = dtOrg.Rows[0]["DI_SMS_Alart_interval"].ToString();
        txtAlertGSMNO.Text = dtOrg.Rows[0]["AlertGSMNO"].ToString();
        txtSMSQuota.Text = dtOrg.Rows[0]["SMSQuota"].ToString();
    }

    private void BindData()
    {
        Bind_Country();
        Bind_City();
        Bind_TimeZone();
    }

    private void Bind_TimeZone()
    {
        DataTable dt = objTimeZoneClass.Data_SelectAll();
        ddlTimeZone.DataSource = dt;
        ddlTimeZone.DataTextField = "LocationwithOffset";
        ddlTimeZone.DataValueField = "ID";
        ddlTimeZone.DataBind();
        ddlTimeZone.SelectedIndex = 0;
    }
    private void Bind_City()
    {
        DataTable dtCity = objCity.Data_SelectByID(Convert.ToInt32(ddlOrgCountry.SelectedValue));
        ddlOrgCity.DataSource = dtCity;
        ddlOrgCity.DataTextField = "City";
        ddlOrgCity.DataValueField = "CityId";
        ddlOrgCity.DataBind();
        ddlOrgCity.Items.Insert(0, new ListItem("Select", "0"));
    }

    private void Bind_Country()
    {
        DataTable dtCountry = objCountry.Data_SelectAll();
        ddlOrgCountry.DataSource = dtCountry;
        ddlOrgCountry.DataTextField = "Country";
        ddlOrgCountry.DataValueField = "CountryId";
        ddlOrgCountry.DataBind();
        ddlOrgCountry.Items.Insert(0, new ListItem("Select", "0"));
    }
    private void BindDDl()
    {
        DataTable dtAccount = objAccount.Data_AccountSelect();
        ddlOrgAccountId.DataSource = dtAccount;
        ddlOrgAccountId.DataTextField = "AccountName";
        ddlOrgAccountId.DataValueField = "AccountID";
        ddlOrgAccountId.DataBind();
    }

    private void GetAccountId()
    {
        //DataTable dt = objOrganisation.Data_Select_CreatedBy(_AccountId);
        //OrgAccountId = Convert.ToInt32(dt.Rows[0]["AccountID"]);
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (CheckValidation())
        {
            CheckValues();
            objOrganisation.OrgName = txtOrgName.Text;
            objOrganisation.AccountID = Convert.ToInt32(ddlOrgAccountId.SelectedValue);
            objOrganisation.OrgAddress = txtOrgAddress.Text;
            objOrganisation.OrgCity = Convert.ToString(ddlOrgCity.SelectedValue);
            objOrganisation.OrgState = txtOrgState.Text;
            objOrganisation.OrgCountry = Convert.ToString(ddlOrgCountry.SelectedValue);
            objOrganisation.OrgZipPin = txtOrgZipPin.Text;
            objOrganisation.Email = txtEmail.Text;
            objOrganisation.OrgLogoPath = txtOrgLogoPath.Text;
            if (txtExpiryDate.Text == "")
            {
                objOrganisation.ExpirDate = Convert.ToDateTime(System.DateTime.MinValue);
            }
            else
            {
                objOrganisation.ExpirDate = Convert.ToDateTime(txtExpiryDate.Text);
            }
            if (txtCreatedOn.Text == "")
            {
                objOrganisation.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
            }
            else
            {
                objOrganisation.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text);
            }
            objOrganisation.CreatedBy = Convert.ToInt32(txtCreatedBy.Text);
            objOrganisation.TimeZoneID = Convert.ToInt32(ddlTimeZone.SelectedValue);
            if (chkEnableEmailAlerts.Checked == true)
            {
                objOrganisation.EnableEmailAlerts = Convert.ToBoolean(true);
            }
            else
            {
                objOrganisation.EnableEmailAlerts = Convert.ToBoolean(false);
            }
            if (chkEnableSMSAlerts.Checked == true)
            {
                objOrganisation.EnableSMSAlerts = Convert.ToBoolean(true);
            }
            else
            {
                objOrganisation.EnableSMSAlerts = Convert.ToBoolean(false);
            }
            if (txtEmailNotifiedOn.Text == "")
            {
                objOrganisation.EmailNotifiedOn = Convert.ToDateTime(System.DateTime.MinValue);
            }
            else
            {
                objOrganisation.EmailNotifiedOn = Convert.ToDateTime(txtEmailNotifiedOn.Text);
            }
            objOrganisation.Email_IM = Convert.ToInt32(txtDefault_Email_Interval_Min.Text);
            objOrganisation.SMS_IM = Convert.ToInt32(txtDefault_SMS_Interval_Min.Text);
            objOrganisation.Temperature_Email = Convert.ToInt32(txtTemperature_Email_Alart_interval.Text);
            objOrganisation.Temperature_SMS = Convert.ToInt32(txtTemperature_SMS_Alart_interval.Text);
            objOrganisation.Geofence_Email = Convert.ToInt32(txtGeofence_Email_Alart_interval.Text);
            objOrganisation.Geofence_SMS = Convert.ToInt32(txtGeofence_SMS_Alart_interval.Text);
            objOrganisation.Overspeed_Email = Convert.ToInt32(txtOverspeed_Email_Alart_interval.Text);
            objOrganisation.Overspeed_SMS = Convert.ToInt32(txtOverspeed_SMS_Alart_interval.Text);
            objOrganisation.LowBattery_Email = Convert.ToInt32(txtLowBattery_Email_Alart_interval.Text);
            objOrganisation.LowBattery_SMS = Convert.ToInt32(txtLowBattery_SMS_Alart_interval.Text);
            objOrganisation.DI_Email = Convert.ToInt32(txtDI_Email_Alart_interval.Text);
            objOrganisation.DI_SMS = Convert.ToInt32(txtDI_SMS_Alart_interval.Text);
            objOrganisation.AlertGSMNO = txtAlertGSMNO.Text;
            objOrganisation.SMSQuota = Convert.ToInt32(txtSMSQuota.Text);

            if (OrganisationID == 0)
            {
                int _UserId=Convert.ToInt32(Session["UserId"]);
                objOrganisation.Data_Insert();
                objRelAccountOrg.Data_Insert(Convert.ToInt32(ddlOrgAccountId.SelectedValue), objOrganisation.Id);

                //insert values into RelUserOrg table 
                //objRelUserOrg.UserID = Convert.ToInt32(Session["UserId"]);
                //objRelUserOrg.AccountID = Convert.ToInt32(ddlOrgAccountId.SelectedValue);
                //objRelUserOrg.OrgID = Convert.ToInt32(objOrganisation.Id);
                //if (txtCreatedOn.Text == "")
                //{
                //    objRelUserOrg.CreatedOn = Convert.ToDateTime(System.DateTime.MinValue);
                //}
                //else
                //{
                //    objRelUserOrg.CreatedOn = Convert.ToDateTime(txtCreatedOn.Text);
                //}
                //objRelUserOrg.Data_Insert();
            }
            else
            {
                objOrganisation.Data_Update(OrganisationID);
                OrganisationID = 0;
            }
            ClearAll();
            objOrganisation = null;
            OrgModalPopupExtender.Show();
            //Response.Redirect("OrganisationMaster.aspx");
        }
    }
    private void CheckValues()
    { 
         if(txtCreatedBy.Text=="")
        {
            txtCreatedBy.Text = "0";
        }
         if(txtDefault_Email_Interval_Min.Text=="")
        {
            txtDefault_Email_Interval_Min.Text = "0";
        }
        if(txtDefault_SMS_Interval_Min.Text == "")
        {
            txtDefault_SMS_Interval_Min.Text = "0";
        }
        if(txtTemperature_Email_Alart_interval.Text == "")
        {
            txtTemperature_Email_Alart_interval.Text = "0";
        }
        if (txtTemperature_SMS_Alart_interval.Text == "")
        {
            txtTemperature_SMS_Alart_interval.Text = "0";
        }
        if (txtGeofence_Email_Alart_interval.Text == "")
        {
            txtGeofence_Email_Alart_interval.Text = "0";
        }
        if (txtGeofence_SMS_Alart_interval.Text == "")
        {
            txtGeofence_SMS_Alart_interval.Text = "0";
        }
        if (txtOverspeed_Email_Alart_interval.Text == "")
        {
            txtOverspeed_Email_Alart_interval.Text = "0";
        }
        if (txtOverspeed_SMS_Alart_interval.Text == "")
        {
            txtOverspeed_SMS_Alart_interval.Text = "0";
        }
        if (txtLowBattery_Email_Alart_interval.Text == "")
        {
            txtLowBattery_Email_Alart_interval.Text = "0";
        }
        if (txtLowBattery_SMS_Alart_interval.Text == "")
        {
            txtLowBattery_SMS_Alart_interval.Text = "0";
        }
        if (txtDI_Email_Alart_interval.Text == "")
        {
            txtDI_Email_Alart_interval.Text = "0";
        }
        if (txtDI_SMS_Alart_interval.Text == "")
        {
            txtDI_SMS_Alart_interval.Text = "0";
        }
        if (txtSMSQuota.Text == "")
        {
            txtSMSQuota.Text = "0";
        }
    }

    private bool CheckValidation()
    {
        if (txtOrgName.Text == "")
        {
            lblErrorMsg.Text = "Please Enter Organisation Name.";
            return false;
        }
       
        else
        {
            return true;
        }
    }

    private void ClearAll()
    {

    }

    protected void ddlOrgCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind_City();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("OrganisationMaster.aspx");
    }
    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        Response.Redirect("OrganisationMaster.aspx");
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Response.Redirect("OrganisationMaster.aspx");
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        Response.Redirect("OrganisationMaster.aspx");
    }
    protected void lblClose_Click1(object sender, EventArgs e)
    {
        Response.Redirect("OrganisationMaster.aspx");
    }
}
