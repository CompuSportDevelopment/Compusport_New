﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class CarrierMaster : System.Web.UI.Page
{
    GPS_TrackingDLL.carriers objcarriers = new GPS_TrackingDLL.carriers();
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                DisplayMenu();

                if (Convert.ToString(Session["UserRole"]) == "SuperUser")
                {
                    BindGrid();
                }
                else
                {
                    BindGridAdmin(Convert.ToInt32(Session["UserId"]));
                }
                
            }
            else
            {
                Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
            }
        }
    }

    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            {
                Control hrefAccount = this.Master.FindControl("hrefAccount");
                hrefAccount.Visible = false;
                Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
                hrefOrganisation.Visible = false;
                //Control hrefCarrier = this.Master.FindControl("hrefCarrier");
                //hrefCarrier.Visible = false;
                Control hrefUser = this.Master.FindControl("hrefUser");
                hrefUser.Visible = false;
            }
            if (Convert.ToString(Session["UserRole"]) == "Admin")
            {
                Control hrefUser = this.Master.FindControl("hrefAccount");
                hrefUser.Visible = false;
            }
        }
    }


    private void BindGridAdmin(int _userId)
    {
        DataTable dtOrg = objRelUserOrg.Data_SelectOrg(_userId);

        DataTable dt = objcarriers.Data_SelByOrg(Convert.ToInt32(Convert.ToInt32(dtOrg.Rows[0]["AccountID"])));
        gvCarrier.DataSource = dt;
        gvCarrier.DataBind();
    }

    private void BindGrid()
    {
        DataTable dt = objcarriers.Data_SelectAll();
        gvCarrier.DataSource = dt;
        gvCarrier.DataBind();
    }
    protected void gvCarrier_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int CarrierID = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Edit")
        {
            Response.Redirect("Carrier.aspx?CarrierID=" + CarrierID);
        }
        else if(e.CommandName=="Delete")
        {
            try
            {
                objcarriers.Data_Delete(CarrierID);
                BindGrid();
            }
            catch (Exception ex)
            { 

            }
        }
        else if (e.CommandName == "View")
        {
          //  Response.Redirect("ViewOrganisationInfo.aspx?CarrierID=" + CarrierID);
        }
    }
    protected void btnNew_Click(object sender, EventArgs e)
    { 
        Response.Redirect("Carrier.aspx");
    }
    protected void gvCarrier_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvCarrier_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
}
