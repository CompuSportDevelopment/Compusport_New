﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GPS_TrackingDLL;

public partial class ViewUserInfo : System.Web.UI.Page
{
    int _UserId = 0;
    GPS_TrackingDLL.RelUserOrg objRelUserOrg = new GPS_TrackingDLL.RelUserOrg();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["UserID"] != null)
        {
            DisplayMenu();
            _UserId = Convert.ToInt32(Request.QueryString["UserID"]);
        }
        if (!IsPostBack)
        {
            BindGrid(_UserId);
        }
    }


    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            Control tblmenu = this.Master.FindControl("tblmenu");
            tblmenu.Visible = false;
        }
    }

    private void BindGrid(int _UserId)
    {
        DataTable dt = objRelUserOrg.Data_SelectById(_UserId);
        gvUser.DataSource = dt;
        gvUser.DataBind();
    }
}
