﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GPS_TrackingDLL;
using System.Data;
using System.Data.SqlClient;

public partial class AccountMaster : System.Web.UI.Page
{
    GPS_TrackingDLL.Account objAccount = new GPS_TrackingDLL.Account();
    protected void Page_Load(object sender, EventArgs e)
    {
         
        if (Session["UserId"] != null)
        {
            DisplayMenu();
            if (Convert.ToString(Session["UserRole"]) == "SuperUser")
            {
                BindGrid();
            }
            else
            {
                BindGridAdmin(Convert.ToInt32(Session["UserId"]));
            }
        }
        else
        {
            Response.Redirect(Request.ApplicationPath.TrimEnd('/') + "/Login.aspx");
        }
    }

    private void DisplayMenu()
    {
        if (Convert.ToString(Session["UserRole"]) != null)
        {
            if (Convert.ToString(Session["UserRole"]) == "TrackUser")
            {
                Control hrefAccount = this.Master.FindControl("hrefAccount");
                hrefAccount.Visible = false;
                Control hrefOrganisation = this.Master.FindControl("hrefOrganisation");
                hrefOrganisation.Visible = false;
                //Control hrefCarrier = this.Master.FindControl("hrefCarrier");
                //hrefCarrier.Visible = false;
                Control hrefUser = this.Master.FindControl("hrefUser");
                hrefUser.Visible = false;
            }
            if (Convert.ToString(Session["UserRole"]) == "Admin")
            {
                Control hrefUser = this.Master.FindControl("hrefAccount");
                hrefUser.Visible = false;
            }
        }
    }

    private void BindGridAdmin(int _userId)
    {
        DataTable dtAccount = objAccount.Data_SelByUserRole(_userId);
        gvAccount.DataSource = dtAccount;
        gvAccount.DataBind();
    }

    private void BindGrid()
    {
        DataTable dtAccount= objAccount.Data_AccountSelect();
        gvAccount.DataSource = dtAccount;
        gvAccount.DataBind();
    }

    protected void gvAccount_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int AccountID =Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Edit")
        {
            Response.Redirect("Account.aspx?AccountID=" + AccountID);
        }
        else if (e.CommandName == "Delete")
        {
            try
            {
                objAccount.Data_Delete(AccountID);
                BindGrid();
            }
            catch (Exception ex)
            { 

            }
        }
        else if (e.CommandName == "View")
        {
            Response.Redirect("ViewAccountInfo.aspx?AccountID=" + AccountID);
        }
    }

    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("Account.aspx");
    }

    protected void gvAccount_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gvAccount_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
}
