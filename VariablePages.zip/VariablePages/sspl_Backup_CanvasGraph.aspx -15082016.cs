﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class VariablePages_CanvasGraph : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int index = Convert.ToInt32(Request.QueryString["index"]);
            if (index == 1)
            {
                GroundTimeLeft();
            }
            else if (index == 2)
            {
                GroundTimeRight();

            }
            else if (index == 3)
            {
                GroundTimeTotal();
            }
            else if (index == 4)
            {
                KneeTouchdownLeft();
            }
            else if (index == 5)
            {
                KneeTouchdownRight();
            }
            else if (index == 6)
            {
                KneeTouchdownTotal();
            }
            else if (index == 7)
            {
                LowerLegAngleLeft();
            }
            else if (index == 8)
            {
                LowerLegAngleRight();
            }
            else if (index == 9)
            {
                LowerLegAngleTotal();
            }
            else if (index == 10)
            {
                TouchDownLeft();
            }
            else if (index == 11)
            {
                TouchDownRight();
            }
            else if (index == 12)
            {
                TouchDownTotal();
            }
            else if (index == 13)
            {
                FullFlexionLeft();
            }
            else if (index == 14)
            {
                FullFlexionRight();
            }
            else if (index == 15)
            {
                FullFlexionTotal();
            }
            else if (index == 16)
            {
                TrunkAngleTouchdownLeft();
            }
            else if (index == 17)
            {
                TrunkAngleTouchdownRight();
            }
            else if (index == 18)
            {
                TrunkAngleTouchdownTotal();
            }
            else if (index == 19)
            {
                UpperLegFullExtensionLeft();
            }
            else if (index == 20)
            {
                UpperLegFullExtensionRight();
            }
            else if (index == 21)
            {
                UpperLegFullExtensionTotal();
            }
            else if (index == 22)
            {
                UpperLegFullFlexionLeft();
            }
            else if (index == 23)
            {
                UpperLegFullFlexionRight();
            }
            else if (index == 24)
            {
                UpperLegFullFlexionTotal();
            }
            else if (index == 25)
            {
                LowerLegFullFlexionLeft();
            }
            else if (index == 26)
            {
                LowerLegFullFlexionRight();
            }
            else if (index == 27)
            {
                LowerLegFullFlexionTotal();
            }
            else if (index == 28)
            {
                VelocityLeft();
            }
            else if (index == 29)
            {
                VelocityRight();
            }
            else if (index == 30)
            {
                AirTimeLeftToRight();
            }
            else if (index == 31)
            {
                AirTimeRightToLeft();
            }
            else if (index == 32)
            {
                AirTimeTotal();
            }
            else if (index == 33)
            {
                Stride_Rate();
            }
            else if (index == 34)
            {
                Stride_Rate();
            }
            else if (index == 35)
            {
                StrideLengthLeftToRight();
            }
            else if (index == 36)
            {
                StrideLengthRightToLeft();
            }
            else if (index == 37)
            {
                StrideLengthTotal();
            }
            else if (index == 38)
            {
                FrontBlock();
            }
            else if (index == 39)
            {
                RearBlock();
            }
            else if (index == 40)
            {
                FrontULAngle();
            }
            else if (index == 41)
            {
                RearULAngle();
            }
            else if (index == 42)
            {
                FrontLLAngle();
            }
            else if (index == 43)
            {
                RearLLAngle();
            }
            else if (index == 44)
            {
                TrunkAngle1();
            }
            else if (index == 45)
            {
                COGDistance();
            }
            else if (index == 46)
            {
                SetTrunkBC();
            }
            else if (index == 47)
            {
                SetBCSt_Ride();
            }
            else if (index == 48)
            {
                StrideLength();
            }
            else if (index == 49)
            {
                Step1Trunk_Angle();
            }
            else if (index == 50)
            {
                Step1Stride_Ride();
            }
            else if (index == 51)
            {
                Step1Stride_Length();
            }
            else if (index == 52)
            {
                Step2_TrunkTakeoff();
            }
            else if (index == 53)
            {
                Step2Stride_Rate_Graph();
            }
            else if (index == 54)
            {
                Step2Stride_Length();
            }
            else if (index == 55)
            {
                LowerLAngleAnkleCross();
            }
            else if (index == 56)
            {
                Step1_LowerL_AngleAnkleCross();
            }
            else if (index == 57)
            {
                Step2_LowerL_AngleAnkleCross();
            }
            else if (index == 58)
            {
                BCVelocity();
            }

            else if (index == 59)
            {
                Step1_Velocity();
            }

            else if (index == 60)
            {
                Step2_Velocity();
            }
            else if (index == 61)
            {
                RearFootClearance();
            }
            else if (index == 62)
            {
                FrontFootClearance();
            }
            else if (index == 63)
            {
                BC_RearLowerLegAngle();
            }
            else if (index == 64)
            {
                BC_FrontLowerLegAngle();
            }
            else if (index == 65)
            {
                BCAirTime1();
            }
            else if (index == 66)
            {
                Step_1COG();
            }
            else if (index == 67)
            {
                Step_1_Rear_Leg();
            }
            else if (index == 68)
            {
                Step_1_GroundTime();
            }
            else if (index == 69)
            {
                Step_1_AirTime();
            }
            else if (index == 70)
            {
                Step_2COG();
            }
            else if (index == 71)
            {
                Step_2_Rear_Leg();
            }
            else if (index == 72)
            {
                Step_2_GroundTime();
            }
            else if (index == 73)
            {
                Step_2_AirTime();
            }
            else if (index == 74)
            {
                Step_3COG();
            }
            else if (index == 75)
            {
                Timeto3m();
            }
            else if (index == 76)
            {
                Timeto5m();
            }
            else if (index == 77)
            {
                HurdleGroundTime();
            }
            else if (index == 78)
            {
                HurdleGroundTimeoff();
            }
            else if (index == 79)
            {
                HurdleAirTimeoff();
            }
            else if (index == 80)
            {
                HurdleTouchDownInto();
            }
            else if (index == 81)
            {
                HurdleTouchDownoff();
            }
            else if (index == 82)
            {
                HurdleKneeSeparationTouchdownInto();
            }
            else if (index == 83)
            {
                HurdleKneeSeparationTouchdownoff();
            }
            else if (index == 84)
            {
                HurdleTrunkMinimumAngle();
            }
            else if (index == 85)
            {
                HurdleTrailUpperLegAngleatTouchdownInto();
            }
            else if (index == 86)
            {
                HurdleLeadUpperLegAngleatTouchdownOff();
            }
            else if (index == 87)
            {
                HurdleLeadLowerLegMaximumAngleOver();
            }
            else if (index == 88)
            {
                HurdleLeadLowerLegMaximumAngleOver();
            }
            else if (index == 89)
            {
                HurdleStrideLengthTotal();
            }
            else if (index == 90)
            {
                HurdleStrideLengthInto();
            }
            else if (index == 91)
            {
                HurdleStrideLengthoff();
            }
            else if (index == 92)
            {
                HurdleVelocity();
            }
            else if (index == 93)
            {
                HurdleTrunkAngleTouchdownInto();
            }
            else if (index == 94)
            {
                HurdleTrunkAngleTouchdownoff();
            }
            else if (index == 95)
            {
                HurdleTrunkAngleTakeoffInto();
            }
            else if (index == 96)
            {
                HurdleTrunkAngleTakeoffOff();
            }
            else if (index == 97)
            {
                HurdleTrailUpperLegAngleTakeoffInto();
            }
            else if (index == 98)
            {
                HurdleLeadUpperLegMaximumAngleOver();
            }
            else if (index == 99)
            {
                HurdleLeadUpperLegAngleTakeoffOff();
            }
            else if (index == 100)
            {
                HurdleLeadLowerLegMinimumAngleInto();
            }
            else if (index == 101)
            {
                HurdleLeadLowerLegAngleAnkleCrossInto();
            }
            else if (index == 102)
            {
                HurdleKneeAnkleMinimumSeparationOver();
            }
            else if (index == 103)
            {
                HurdleLeadLowerLegAngleTakeoffOff();
            }
            else if (index == 105)
            {
                HurdleStepGroundTime();
            }
            else if (index == 106)
            {
                HurdleStepAirTime();
            }
            else if (index == 107)
            {
                HurdleStepTouchdownDistance();
            }
            else if (index == 108)
            {
                HurdleStepKneeSeperationTouchdown();
            }
            else if (index == 109)
            {
                HurdleStepUpperLegAngleFullExtension();
            }
            else if (index == 110)
            {
                HurdleStepLowerLegTakeoff();
            }
            else if (index == 111)
            {
                HurdleStepStrideRate();
            }
            else if (index == 112)
            {
                HurdleStepTrunkAngleTouchdown();
            }
            else if (index == 113)
            {
                HurdleStepTrunkTakeoffAngle();
            }
            else if (index == 114)
            {
                HurdleStepUpperLegAngleFullFlexion();
            }
            else if (index == 115)
            {
                HurdleStepStrideLength();
            }


        }
    }
    //Start Graph type one:- Variables that have Model values that are in one direction, and get smaller 
    public void GroundTimeLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.GroundTimeLeft , b.GroundTimeLeft , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Left');", true);
    }
    public void GroundTimeRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.GroundTimeRight , b.GroundTimeRight , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Right');", true);
    }
    public void GroundTimeTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.GroundTimeRight+a.GroundTimeLeft)/2 as decimal(18,3)) AS [Ground Time Average2],CAST((b.GroundTimeLeft+b.GroundTimeRight)/2 as decimal(18,3)) AS [Ground Time Average],c.GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Average');", true);
    }
    // Graph type one end


    // Graph type two

    public void KneeTouchdownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.KSATouchDownLeft , b.KSATouchDownLeft, c.KSATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Left');", true);
    }
    public void KneeTouchdownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.KSATouchDownRight , b.KSATouchDownRight, c.KSATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Right');", true);
    }
    public void KneeTouchdownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.KSATouchDownRight + a.KSATouchDownLeft)/2 as decimal(18,3)) AS [KneeTouchdownTotal],CAST((b.KSATouchDownLeft+b.KSATouchDownRight)/2 as decimal(18,3)) AS [KneeTouchdownTotal1],c.KSATouchDown,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Average');", true);
    }

    public void LowerLegAngleLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.LLAngleTakeoffLeft , b.LLAngleTakeoffLeft , c.LLAngleTakeoff ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Left');", true);
    }
    public void LowerLegAngleRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.LLAAngleTakeoffRight , b.LLAAngleTakeoffRight , c.LLAngleTakeoff ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Right');", true);
    }
    public void LowerLegAngleTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.LLAAngleTakeoffRight + a.LLAngleTakeoffLeft)/2 as decimal(18,3)) AS [LowerLegAngleTotal],CAST((b.LLAngleTakeoffLeft+b.LLAAngleTakeoffRight)/2 as decimal(18,3)) AS [LowerLegAngleTotal1],c.LLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Average');", true);
    }

    public void TouchDownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.COGDistanceLeft , b.COGDistanceLeft , c.COGDistance ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Left');", true);
    }
    public void TouchDownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.COGDistanceRight , b.COGDistanceRight , c.COGDistance ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Right');", true);
    }
    public void TouchDownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.COGDistanceRight + a.COGDistanceLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.COGDistanceLeft+b.COGDistanceRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.COGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Average');", true);
    }

    public void FullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.FullFlexionTimeLeft , b.FullFlexionTimeLeft, c.FullFlexionTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Left');", true);
    }
    public void FullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.FullFlexionTimeRight , b.FullFlexionTimeRight, c.FullFlexionTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Right');", true);
    }
    public void FullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.FullFlexionTimeRight + a.FullFlexionTimeLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.FullFlexionTimeLeft+b.FullFlexionTimeRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.FullFlexionTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Average');", true);
    }

    public void TrunkAngleTouchdownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.TAATouchDownLeft , b.TAATouchDownLeft, c.TAATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Left');", true);
    }
    public void TrunkAngleTouchdownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.TAATouchDownRight , b.TAATouchDownRight, c.TAATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Right');", true);
    }
    public void TrunkAngleTouchdownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.TAATouchDownRight + a.TAATouchDownLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.TAATouchDownLeft+b.TAATouchDownRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.TAATouchDown,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Average');", true);
    }


    public void UpperLegFullExtensionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullExtensionAngleLeft , b.ULFullExtensionAngleLeft, c.ULFullExtensionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Left');", true);
    }
    public void UpperLegFullExtensionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullExtensionAngleRight , b.ULFullExtensionAngleRight, c.ULFullExtensionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Right');", true);
    }
    public void UpperLegFullExtensionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.ULFullExtensionAngleRight + a.ULFullExtensionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.ULFullExtensionAngleLeft+b.ULFullExtensionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.ULFullExtensionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Average');", true);
    }

    public void UpperLegFullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullFlexionAngleLeft , b.ULFullFlexionAngleLeft, c.ULFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Left');", true);
    }
    public void UpperLegFullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullFlexionAngleRight , b.ULFullFlexionAngleRight, c.ULFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Right');", true);
    }
    public void UpperLegFullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.ULFullFlexionAngleRight + a.ULFullFlexionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.ULFullFlexionAngleLeft+b.ULFullFlexionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.ULFullFlexionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Average');", true);
    }

    public void LowerLegFullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Left');", true);
    }
    public void LowerLegFullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleRight , b.LLFullFlexionAngleRight, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Right');", true);
    }
    public void LowerLegFullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.LLFullFlexionAngleRight + a.LLFullFlexionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.LLFullFlexionAngleLeft+b.LLFullFlexionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.LLFullFlexionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Average');", true);
    }

    public void VelocityLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            //string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((((a.[GroundTimeLeft]+a.[GroundTimeRight])/2)+(a.[AirTimeLeftToRight]+a.[AirTimeRightToLeft])/2), 0 )),0)*((a.[StrideLengthLeftToRight]+a.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((((b.[GroundTimeLeft]+b.[GroundTimeRight])/2)+(b.[AirTimeLeftToRight]+b.[AirTimeRightToLeft])/2), 0 )),0)*((b.[StrideLengthLeftToRight]+b.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[GroundTime]+c.[AirTime]), 0 ))*[StrideLength],0) AS decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [SprintInitialData] a Inner Join SprintCurrentData b on a.LessonId = b.LessonId  Inner Join SprintModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Velocity('Velocity');", true);
    }
    public void VelocityRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            //string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((((a.[GroundTimeLeft]+a.[GroundTimeRight])/2)+(a.[AirTimeLeftToRight]+a.[AirTimeRightToLeft])/2), 0 )),0)*((a.[StrideLengthLeftToRight]+a.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((((b.[GroundTimeLeft]+b.[GroundTimeRight])/2)+(b.[AirTimeLeftToRight]+b.[AirTimeRightToLeft])/2), 0 )),0)*((b.[StrideLengthLeftToRight]+b.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[GroundTime]+c.[AirTime]), 0 ))*[StrideLength],0) AS decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [SprintInitialData] a Inner Join SprintCurrentData b on a.LessonId = b.LessonId  Inner Join SprintModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Velocity('Velocity');", true);
    }

    //Graph type two End

    // Graph type three :- Variables that have Model values that have a specific range of values

    public void AirTimeLeftToRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.AirTimeLeftToRight,b.AirTimeLeftToRight, c.AirTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Left To Right');", true);
    }
    public void AirTimeRightToLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.AirTimeRightToLeft,b.AirTimeRightToLeft, c.AirTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Right To Left');", true);
    }
    public void AirTimeTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.AirTimeRightToLeft + a.AirTimeLeftToRight)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.AirTimeLeftToRight+b.AirTimeRightToLeft)/2 as decimal(18,3)) AS [TouchdownTotal1],c.AirTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Average  ');", true);
    }

    public void Stride_Rate()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT  d.LessonId,CAST(ISNULL((1 / NULLIF((((a.[GroundTimeLeft]+a.[GroundTimeRight])/2)+(a.[AirTimeLeftToRight]+a.[AirTimeRightToLeft])/2), 0 )),0)as decimal(18,3))AS [Stride_Rate_Intial],CAST(ISNULL((1 / NULLIF((((b.[GroundTimeLeft]+b.[GroundTimeRight])/2)+(b.[AirTimeLeftToRight]+b.[AirTimeRightToLeft])/2), 0 )),0)as decimal(18,3))AS [Stride_Rate_Final],CAST(ISNULL((1 / NULLIF((c.[GroundTime]+c.[AirTime]), 0 )),0) AS decimal(18,3))AS [Stride_Rate__Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [SprintInitialData] a Inner Join SprintCurrentData b on a.LessonId = b.LessonId  Inner Join SprintModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Stride_Rate('Stride Rate Graph');", true);
    }

    public void StrideLengthLeftToRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.StrideLengthLeftToRight,b.StrideLengthLeftToRight, c.StrideLength ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Stride_Length('Stride Length Left To Right');", true);
    }
    public void StrideLengthRightToLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.StrideLengthRightToLeft,b.StrideLengthRightToLeft, c.StrideLength ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Stride_Length('Stride Length Right To Left ');", true);
    }
    public void StrideLengthTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.StrideLengthRightToLeft + a.StrideLengthLeftToRight)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.StrideLengthLeftToRight+b.StrideLengthRightToLeft)/2 as decimal(18,3)) AS [TouchdownTotal1],c.StrideLength,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Stride_Length('Stride Length Average  ');", true);
    }

    //Start Player Graph 3 Started
    public void FrontBlock()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetFrontBlockDistance , b.SetFrontBlockDistance , c.SetFrontBlockDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FrontBlock('Front Block Distance');", true);
    }
    public void RearBlock()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetRearBlockDistance , b.SetRearBlockDistance , c.SetRearBlockDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "RearBlock('Rear Block Distance');", true);
    }
    public void FrontULAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetFrontULAngle , b.SetFrontULAngle , c.SetFrontULAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FrontUpperLegAngle('Front Upper Leg Angle');", true);
    }
    public void RearULAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetRearULAngle , b.SetRearULAngle , c.SetRearULAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "RearUpperLegAngle('Rear Upper Leg Angle');", true);
    }
    public void FrontLLAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetFrontLLAngle , b.SetFrontLLAngle , c.SetFrontLLAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FrontLowerLegAngle('Front Lower Leg Angle');", true);
    }
    public void RearLLAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetRearLLAngle , b.SetRearLLAngle , c.SetRearLLAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "RearLowerLegAngle('Rear Lower Leg Angle');", true);
    }
    public void TrunkAngle1()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "Select Distinct Top 1 d.LessonId, a.SetTrunkAngle , b.SetTrunkAngle , c.SetTrunkAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngleGraph('Trunk Angle');", true);
    }
    public void COGDistance()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.SetCOGDistance , b.SetCOGDistance , c.SetCOGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "COGDistancegraph('COG Distance');", true);
    }

    public void SetTrunkBC()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCTrunkAngleTakeoff , b.BCTrunkAngleTakeoff , c.BCTrunkAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BC_Trunk_Angle1('Trunk Angle at Takeoff');", true);
    }
    public void SetBCSt_Ride()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            //string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            string cmdstring = "SELECT Distinct Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((a.[BCFrontFootClearanceTime]+a.[BCAirTime]), 0 )),0) AS decimal(18,3)) AS  [BCStrideRate_Initial] ,CAST(ISNULL((1 / NULLIF((b.[BCFrontFootClearanceTime]+b.[BCAirTime]), 0 )),0) AS decimal(18,3)) AS  [BCStrideRate_Final],CAST(ISNULL((1 / NULLIF((c.[BCFrontFootClearanceTime]+c.[BCAirTime]), 0 )),0) AS decimal(18,3)) AS  [BCStrideRate_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "SetBCStride('Stride Rate Graph');", true);
    }
    public void StrideLength()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCStrideLength , b.BCStrideLength , c.BCStrideLength,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Stride_Length('Stride Length');", true);
    }
    public void Step1Trunk_Angle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1TrunkAngleTakeoff , b.Step1TrunkAngleTakeoff , c.Step1TrunkAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_Trunk_Angle('Trunk Angle at Takeoff');", true);
    }
    public void Step1Stride_Ride()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId,CAST(ISNULL((1/NULLIF((a.[Step1GroundTime]+a.[Step1AirTime]), 0 )),0) as decimal(18,3)) AS  [Step1StrideRate_Initial] ,CAST(ISNULL((1/NULLIF((b.[Step1GroundTime]+b.[Step1AirTime]), 0 )),0) as decimal(18,3)) AS  [Step1StrideRate_Final],CAST(ISNULL((1/NULLIF((c.[Step1GroundTime]+c.[Step1AirTime]), 0 )),0) as decimal(18,3)) AS  [Step1StrideRate_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_Stride_Rate('Stride Rate Graph');", true);
    }
    public void Step1Stride_Length()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1StrideLength , b.Step1StrideLength , c.Step1StrideLength,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_Stride_Length('Stride Length');", true);
    }
    public void Step2_TrunkTakeoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step2TrunkAngleTakeoff , b.Step2TrunkAngleTakeoff , c.Step2TrunkAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_TrunkTakeOff('Trunk Angle At Takeoff');", true);
    }
    public void Step2Stride_Rate_Graph()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId,CAST(ISNULL((1/NULLIF((a.[Step2GroundTime]+a.[Step2AirTime]), 0 )),0) as decimal(18,3)) AS  [Step2StrideRate_Initial] ,CAST(ISNULL((1/NULLIF((b.[Step2GroundTime]+b.[Step2AirTime]), 0 )),0) as decimal(18,3)) AS  [Step2StrideRate_Final],CAST(ISNULL((1/NULLIF((c.[Step2GroundTime]+c.[Step2AirTime]), 0 )),0) as decimal(18,3)) AS  [Step1StrideRate_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_Stride_Rate('Stride Rate Graph');", true);
    }
    public void Step2Stride_Length()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step2StrideLength , b.Step2StrideLength , c.Step2StrideLength,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_Stride_Length('Stride Length');", true);
    }


    //Start Player Graph 3 End 


    //Start Player Graph 2 Started

    public void LowerLAngleAnkleCross()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCLLAngleAC , b.BCLLAngleAC , c.BCLLAngleAC,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLAngleAnkle('Lower Leg Angle at Ankle Cross');", true);
    }
    public void Step1_LowerL_AngleAnkleCross()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1LLAngleAC , b.Step1LLAngleAC , c.Step1LLAngleAC,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_LowerLAngleAnkle('Lower Leg Angle at Ankle Cross');", true);
    }
    public void Step2_LowerL_AngleAnkleCross()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step2LLAngleAC , b.Step2LLAngleAC , c.Step2LLAngleAC,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_LowerLAngleAnkle('Lower Leg Angle at Ankle Cross');", true);
    }
    public void BCVelocity()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((a.[BCFrontFootClearanceTime]+a.[BCAirTime]), 0 )),0)*(a.[BCStrideLength]+(a.[SetCOGDistance]-a.[Step1COGDistance]))*1.58 as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((b.[BCFrontFootClearanceTime]+b.[BCAirTime]), 0 )),0)*(b.[BCStrideLength]+(b.[SetCOGDistance]-b.[Step1COGDistance]))*1.58 as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[BCFrontFootClearanceTime]+c.[BCAirTime]), 0 )),0)*(c.[BCStrideLength]+(c.[SetCOGDistance]-c.[Step1COGDistance]))*1.58 as decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BC_Velocity('Velocity');", true);
    }
    public void Step1_Velocity()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((a.[Step1GroundTime]+a.[Step1AirTime]), 0 )),0)*(a.[Step1StrideLength]+(a.[Step1COGDistance]-a.[Step2COGDistance]))*1.25 as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((b.[Step1GroundTime]+b.[Step1AirTime]), 0 )),0)*(b.[Step1StrideLength]+(b.[Step1COGDistance]-b.[Step2COGDistance]))*1.25 as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[Step1GroundTime]+c.[Step1AirTime]), 0 )),0)*(c.[Step1StrideLength]+(c.[Step1COGDistance]-c.[Step2COGDistance]))*1.25 as decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1Velocity('Velocity');", true);
    }
    public void Step2_Velocity()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((a.[Step2GroundTime]+a.[Step2AirTime]), 0 )),0)*(a.[Step2StrideLength]+(a.[Step2COGDistance]-a.[Step3COGDistance]))*1.08 as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((b.[Step2GroundTime]+b.[Step2AirTime]), 0 )),0)*(b.[Step2StrideLength]+(b.[Step2COGDistance]-b.[Step3COGDistance]))*1.08 as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[Step2GroundTime]+c.[Step2AirTime]), 0 )),0)*(c.[Step2StrideLength]+(c.[Step2COGDistance]-c.[Step3COGDistance]))*1.08 as decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [StartInitialData] a Inner Join StartCurrentData b on a.LessonId = b.LessonId  Inner Join StartModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2Velocity('Velocity');", true);
    }


    //Start player graph type 1 start 
    public void RearFootClearance()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCRearFootClearanceTime , b.BCRearFootClearanceTime , c.BCRearFootClearanceTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BCRearFoot('Rear Foot Clearance Time');", true);
    }
    public void FrontFootClearance()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCFrontFootClearanceTime , b.BCFrontFootClearanceTime , c.BCFrontFootClearanceTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BCFrontFoot('Front Foot Clearance Time');", true);

    }
    public void BC_RearLowerLegAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCRearLLAngleTakeoff , b.BCRearLLAngleTakeoff , c.BCRearLLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BCRearLowerLegRear('Rear Lower Leg Angle at Rear Takeoff');", true);

    }
    public void BC_FrontLowerLegAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCFrontLLAngleTakeoff , b.BCFrontLLAngleTakeoff , c.BCFrontLLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BCFrontLowerLegFront('Front Lower Leg Angle at Front Takeoff');", true);

    }
    public void BCAirTime1()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.BCAirTime , b.BCAirTime , c.BCAirTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "BCAirTime('Air Time');", true);

    }
    //step 1
    public void Step_1COG()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1COGDistance , b.Step1COGDistance , c.Step1COGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_COG('COG Touchdown Distance');", true);

    }
    public void Step_1_Rear_Leg()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step1LLAngleTakeoff , b.Step1LLAngleTakeoff , c.Step1LLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step1_Rear_Leg('Rear Lower Leg Angle at Takeoff');", true);

    }
    public void Step_1_GroundTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step1GroundTime , b.Step1GroundTime , c.Step1GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step_1_GroundTime('Ground Time');", true);

    }
    public void Step_1_AirTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step1AirTime , b.Step1AirTime , c.Step1AirTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step_1_AirTime('Air Time');", true);

    }


    //step 2
    public void Step_2COG()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step2COGDistance , b.Step2COGDistance , c.Step2COGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_COG('COG Touchdown Distance');", true);

    }
    public void Step_2_Rear_Leg()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step2LLAngleTakeoff , b.Step2LLAngleTakeoff , c.Step2LLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step2_Rear_Leg('Rear Lower Leg Angle at Takeoff');", true);

    }
    public void Step_2_GroundTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step2GroundTime , b.Step2GroundTime , c.Step2GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step_2_GroundTime('Ground Time');", true);

    }
    public void Step_2_AirTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct  d.LessonId, a.Step2AirTime , b.Step2AirTime , c.Step2AirTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step_2_AirTime('Air Time');", true);

    }

    //Step 3
    public void Step_3COG()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step3COGDistance , b.Step3COGDistance , c.Step3COGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Step3_COG('COG Touchdown Distance');", true);

    }
    public void Timeto3m()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TimeTo3m , b.TimeTo3m , c.TimeTo3m,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Time_to_3m('Time To 3m');", true);

    }
    public void Timeto5m()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TimeTo5m , b.TimeTo5m , c.TimeTo5m,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[StartInitialData] a INNER JOIN [dbo].[StartCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[StartModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Time_to_5m('Time To 5m');", true);

    }


    // Graph 1 for hurdle player
    public void HurdleGroundTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.GroundTimeInto , b.GroundTimeInto , c.GroundTimeInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleGroundTimeInto('Ground Time Into');", true);

    }
    public void HurdleGroundTimeoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.GroundTimeOff , b.GroundTimeOff , c.GroundTimeOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleGroundTimeoff('Ground Time Off');", true);

    }
    public void HurdleAirTimeoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.AirTimeOver , b.AirTimeOver , c.AirTimeOver,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleAirTimeoff('Air Time');", true);

    }
    public void HurdleTouchDownInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.COGDistanceInto , b.COGDistanceInto , c.COGDistanceInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTouchdownDistanceinto('Touchdown Distance Into');", true);

    }
    public void HurdleTouchDownoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.COGDistanceOff , b.COGDistanceOff , c.COGDistanceOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTouchdownDistanceoff('Touchdown Distance Off');", true);

    }
    public void HurdleKneeSeparationTouchdownInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.KSTouchDownInto , b.KSTouchDownInto , c.KSTouchDownInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleKneeseparationinto('Knee Separation at Touchdown Into');", true);

    }
    public void HurdleKneeSeparationTouchdownoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.KSTouchDownOff , b.KSTouchDownOff , c.KSTouchDownOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleKneeseparationoff('Knee Separation at Touchdown Off');", true);

    }
    public void HurdleTrunkMinimumAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TMAngleOver , b.TMAngleOver , c.TMAngleOver,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTrunkMinimumAngleOver('Trunk Minimum Angle Over');", true);

    }
    public void HurdleTrailUpperLegAngleatTouchdownInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct d.LessonId, a.ULAngleTDInto , b.ULAngleTDInto , c.ULAngleTDInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrailUpperLegAngleatTouchdownInto('Trail Upper Leg Angle at Touchdown Into');", true);

    }
    public void HurdleLeadUpperLegAngleatTouchdownOff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.ULAngleTDOff , b.ULAngleTDOff , c.ULAngleTDOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleLeadUpperLegAngleTouchdownOff('Lead Upper Leg Angle at Touchdown Off');", true);

    }
    public void HurdleLeadLowerLegMaximumAngleOver()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.LLMAngleOver , b.LLMAngleOver , c.LLMAngleOver,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadLowerLegMaximumAngleOver('Lead Lower Leg Angle at Touchdown Off');", true);

    }
    public void HurdleLeadLowerLegAngleOver()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.LLAngleTOOff , b.LLAngleTOOff , c.LLAngleTOOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadLowerLegMaximumAngleOver('Lead Lower Leg Maximum Angle Over');", true);

    }
    public void HurdleStrideLengthTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.StrideLengthTotal , b.StrideLengthTotal , c.StrideLengthTotal,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "StrideLengthTotal('Stride Length Total');", true);

    }

    //Start hurdle step graph type 3

    public void HurdleStrideLengthInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.StrideLengthInto , b.StrideLengthInto , c.StrideLengthInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_StrideLengthInto('Stride Length Into');", true);

    }
    public void HurdleStrideLengthoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.StrideLengthOff , b.StrideLengthOff , c.StrideLengthOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_StrideLengthoff('Stride Length Off');", true);

    }
    //End hurdle step graph type 3

    //Start hurdle step graph type 2
    public void HurdleVelocity()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Velocity , b.Velocity , c.Velocity,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Velocity('Velocity');", true);

    }
    public void HurdleTrunkAngleTouchdownInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TTDAngleInto , b.TTDAngleInto , c.TTDAngleInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTrunkAngleTouchdownInto('Trunk Angle at Touchdown Into');", true);

    }
    public void HurdleTrunkAngleTouchdownoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TTDAngleOff , b.TTDAngleOff , c.TTDAngleOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTrunkAngleTouchdownoff('Trunk Angle at Touchdown Off');", true);

    }
    public void HurdleTrunkAngleTakeoffInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TTAngleInto , b.TTAngleInto , c.TTAngleInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTrunkAngleTakeoffInto('Trunk Angle at Takeoff Into');", true);

    }
    public void HurdleTrunkAngleTakeoffOff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.TTAngleOff , b.TTAngleOff , c.TTAngleOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "HurdleTrunkAngleTakeoffOff('Trunk Angle at Takeoff Off');", true);

    }
    public void HurdleTrailUpperLegAngleTakeoffInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.ULAngleTOInto , b.ULAngleTOInto , c.ULAngleTOInto,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrailUpperLegAngleTakeoffInto('Trail Upper Leg Angle at Takeoff Into');", true);

    }

    public void HurdleLeadUpperLegMaximumAngleOver()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.ULMAngleOver , b.ULMAngleOver , c.ULMAngleOver,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadUpperLegMaximumAngleOver('Lead Upper Leg Maximum Angle Over');", true);

    }
    public void HurdleLeadUpperLegAngleTakeoffOff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.ULAngleTOOff , b.ULAngleTOOff , c.ULAngleTOOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadUpperLegAngleTakeoffOff('Lead Upper Leg Angle at Takeoff Off');", true);

    }
    public void HurdleLeadLowerLegMinimumAngleInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.LeadLegMinimumAngle , b.LeadLegMinimumAngle , c.LeadLegMinimumAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadLowerLegMinimumAngleInto('Lead Lower Leg Minimum Angle Into');", true);

    }
    public void HurdleLeadLowerLegAngleAnkleCrossInto()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.LeadLegAngleAC , b.LeadLegAngleAC , c.LeadLegAngleAC,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadLowerLegAngleAnkleCrossInto('Lead Lower Leg Angle at Ankle Cross Into');", true);

    }
    public void HurdleKneeAnkleMinimumSeparationOver()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.KAMSeparationOver , b.KAMSeparationOver , c.KAMSeparationOver,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeAnkleMinimumSeparationOver('Trail Knee-Ankle Minimum Separation Over');", true);

    }
    public void HurdleLeadLowerLegAngleTakeoffOff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.LLAngleTOOff , b.LLAngleTOOff , c.LLAngleTOOff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleInitialData] a INNER JOIN [dbo].[HurdleCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LeadLowerLegAngleTakeoffOff('Lead Lower Leg Angle at Takeoff Off');", true);

    }

    //End hurdle step graph type 2

    //Hurdle Step Player
    public void HurdleStepGroundTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1GroundTime , b.Step1GroundTime , c.Step1GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_GroundTime('Ground Time');", true);

    }
    public void HurdleStepAirTime()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1AirTime , b.Step1AirTime , c.Step1AirTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_AirTime('Air Time');", true);

    }
    public void HurdleStepTouchdownDistance()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1TouchdownDistance , b.Step1TouchdownDistance , c.Step1TouchdownDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_TouchdownDistance('Touchdown Distance');", true);

    }
    public void HurdleStepKneeSeperationTouchdown()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1KneeSeperationatTouchdown , b.Step1KneeSeperationatTouchdown , c.Step1KneeSeperationatTouchdown,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_KneeSeperationTouchdown('Knee Separation at Touchdown');", true);

    }
    public void HurdleStepUpperLegAngleFullExtension()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1ULAtFullExtension , b.Step1ULAtFullExtension , c.Step1ULAtFullExtension,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_UpperLegAngleFullExtension('Upper Leg at Full Extension');", true);

    }
    public void HurdleStepLowerLegTakeoff()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1LLAtTakeoff , b.Step1LLAtTakeoff , c.Step1LLAtTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_LowerLegTakeoff('Lower Leg at Take off');", true);
        
    }

    public void HurdleStepStrideRate()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, CAST(ISNULL((1/NULLIF((a.[Step1GroundTime]+a.[Step1AirTime]), 0 )),0) as decimal(18,3)) As [Step1 Stride Rate] ,CAST(ISNULL((1/NULLIF((b.[Step1GroundTime]+b.[Step1AirTime]), 0 )),0) as decimal(18,3)) As [Step1 Stride Rate] , CAST(ISNULL((1/NULLIF((c.[Step1GroundTime]+c.[Step1AirTime]), 0 )),0) as decimal(18,3)) As [Step1 Stride Rate],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_StrideRate('Stride Rate');", true);

    }
    public void HurdleStepTrunkAngleTouchdown()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1TrunkTouchdownAngle ,b.Step1TrunkTouchdownAngle, c.Step1TrunkTouchdownAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step2_TrunkAngleTouchdown('Trunk Touchdown Angle');", true);

    }
    public void HurdleStepTrunkTakeoffAngle()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1TrunkTakeoffAngle ,b.Step1TrunkTakeoffAngle, c.Step1TrunkTakeoffAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step2_TrunkTakeoffAngle('Trunk Takeoff Angle');", true);

    }

    public void HurdleStepUpperLegAngleFullFlexion()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1ULAtFullFlexion ,b.Step1ULAtFullFlexion, c.Step1ULAtFullFlexion,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_UpperLegAngleFullFlexion('Upper Leg Angle at Full Flexion');", true);

    }

    public void HurdleStepStrideLength()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.Step1StrideLength ,b.Step1StrideLength, c.Step1StrideLength,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[HurdleStepsInitialData] a INNER JOIN [dbo].[HurdleStepsCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[HurdleStepsModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Hurdle_Step_StrideLength('Stride Length');", true);

    }

    //Hurdle Step Player end
}
