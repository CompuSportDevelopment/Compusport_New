﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class VariablePages_CanvasGraph : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int index =Convert.ToInt32( Request.QueryString["index"]);
            if (index == 1)
            {
                GroundTimeLeft();
            }
            else if (index == 2)
            {
                GroundTimeRight();

            }
            else if (index == 3)
            {
                GroundTimeTotal();
            }
            else if (index == 4)
            {
                KneeTouchdownLeft();
            }
            else if (index == 5)
            {
                KneeTouchdownRight();
            }
            else if (index == 6)
            {
                KneeTouchdownTotal();
            }
            else if (index == 7)
            {
                LowerLegAngleLeft();
            }
            else if (index == 8)
            {
                LowerLegAngleRight();
            }
            else if (index == 9)
            {
                LowerLegAngleTotal();
            }
            else if (index == 10)
            {
                TouchDownLeft();
            }
            else if (index == 11)
            {
                TouchDownRight();
            }
            else if (index == 12)
            {
                TouchDownTotal();
            }
            else if (index == 13)
            {
                FullFlexionLeft();
            }
            else if (index == 14)
            {
                FullFlexionRight();
            }
            else if (index == 15)
            {
                FullFlexionTotal();
            }
            else if (index == 16)
            {
                TrunkAngleTouchdownLeft();
            }
            else if (index == 17)
            {
                TrunkAngleTouchdownRight();
            }
            else if (index == 18)
            {
                TrunkAngleTouchdownTotal();
            }
            else if (index == 19)
            {
                UpperLegFullExtensionLeft();
            }
            else if (index == 20)
            {
                UpperLegFullExtensionRight();
            }
            else if (index == 21)
            {
                UpperLegFullExtensionTotal();
            }
            else if (index == 22)
            {
                UpperLegFullFlexionLeft();
            }
            else if (index == 23)
            {
                UpperLegFullFlexionRight();
            }
            else if (index == 24)
            {
                UpperLegFullFlexionTotal();
            }
             else if (index == 25)
            {
                LowerLegFullFlexionLeft();
            }
            else if (index == 26)
            {
                LowerLegFullFlexionRight();
            }
            else if (index == 27)
            {
                LowerLegFullFlexionTotal();
            }
            else if (index == 28)
            {
                VelocityLeft();
            }
            else if (index == 29)
            {
                VelocityRight();
            }
             else if (index == 30)
            {
               AirTimeLeftToRight();
            }
            else if (index == 31)
            {
                AirTimeRightToLeft();
            }
            else if (index == 32)
            {
                AirTimeTotal();
            }
           
            
 
            
        }
    } 

    public void GroundTimeLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]); 
             
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();
        
        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues=string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.GroundTimeLeft , b.GroundTimeLeft , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString()+":";
                xvalues += dt1.Rows[0][j + 4].ToString()+",";
                ViewState["val_"+k] = dt.Rows[0][j].ToString();
                k++;

               
            }
          
        }
      
        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;
      
     
        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Left');", true);
    }
    public void GroundTimeRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.GroundTimeRight , b.GroundTimeRight , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Right');", true);
    }
    public void GroundTimeTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.GroundTimeRight+a.GroundTimeLeft)/2 as decimal(18,3)) AS [Ground Time Average2],CAST((b.GroundTimeLeft+b.GroundTimeRight)/2 as decimal(18,3)) AS [Ground Time Average],c.GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Average');", true);
    }

    public void KneeTouchdownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.KSATouchDownLeft , b.KSATouchDownLeft, c.KSATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Left');", true);
    }
    public void KneeTouchdownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.KSATouchDownRight , b.KSATouchDownRight, c.KSATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Right');", true);
    }
    public void KneeTouchdownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.KSATouchDownRight + a.KSATouchDownLeft)/2 as decimal(18,3)) AS [KneeTouchdownTotal],CAST((b.KSATouchDownLeft+b.KSATouchDownRight)/2 as decimal(18,3)) AS [KneeTouchdownTotal1],c.KSATouchDown,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "KneeTouchDown('Knee Separation at Touchdown Average');", true);
    }

    public void LowerLegAngleLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.LLAngleTakeoffLeft , b.LLAngleTakeoffLeft , c.LLAngleTakeoff ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Left');", true);
    }
    public void LowerLegAngleRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.LLAAngleTakeoffRight , b.LLAAngleTakeoffRight , c.LLAngleTakeoff ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Right');", true);
    }
    public void LowerLegAngleTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.LLAAngleTakeoffRight + a.LLAngleTakeoffLeft)/2 as decimal(18,3)) AS [LowerLegAngleTotal],CAST((b.LLAngleTakeoffLeft+b.LLAAngleTakeoffRight)/2 as decimal(18,3)) AS [LowerLegAngleTotal1],c.LLAngleTakeoff,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Takeoff('Lower Leg Angle at Takeoff Average');", true);
    }

    public void TouchDownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.COGDistanceLeft , b.COGDistanceLeft , c.COGDistance ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Left');", true);
    }
    public void TouchDownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.COGDistanceRight , b.COGDistanceRight , c.COGDistance ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Right');", true);
    }
    public void TouchDownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.COGDistanceRight + a.COGDistanceLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.COGDistanceLeft+b.COGDistanceRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.COGDistance,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Touchdown('Touchdown Distance Average');", true);
    }

    public void FullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.FullFlexionTimeLeft , b.FullFlexionTimeLeft, c.FullFlexionTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Left');", true);
    }
    public void FullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.FullFlexionTimeRight , b.FullFlexionTimeRight, c.FullFlexionTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Right');", true);
    }
    public void FullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.FullFlexionTimeRight + a.FullFlexionTimeLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.FullFlexionTimeLeft+b.FullFlexionTimeRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.FullFlexionTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "FullFlexion('Time to Upper Leg Full Flexion Average');", true);
    }

    public void TrunkAngleTouchdownLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.TAATouchDownLeft , b.TAATouchDownLeft, c.TAATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Left');", true);
    }
    public void TrunkAngleTouchdownRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.TAATouchDownRight , b.TAATouchDownRight, c.TAATouchDown ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Right');", true);
    }
    public void TrunkAngleTouchdownTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.TAATouchDownRight + a.TAATouchDownLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.TAATouchDownLeft+b.TAATouchDownRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.TAATouchDown,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "TrunkAngle('Trunk Angle at Touchdown Average');", true);
    }


    public void UpperLegFullExtensionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullExtensionAngleLeft , b.ULFullExtensionAngleLeft, c.ULFullExtensionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Left');", true);
    }
    public void UpperLegFullExtensionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullExtensionAngleRight , b.ULFullExtensionAngleRight, c.ULFullExtensionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Right');", true);
    }
    public void UpperLegFullExtensionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.ULFullExtensionAngleRight + a.ULFullExtensionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.ULFullExtensionAngleLeft+b.ULFullExtensionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.ULFullExtensionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullExtension('Upper Leg Full Extension Angle Average');", true);
    }

    public void UpperLegFullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullFlexionAngleLeft , b.ULFullFlexionAngleLeft, c.ULFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Left');", true);
    }
    public void UpperLegFullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.ULFullFlexionAngleRight , b.ULFullFlexionAngleRight, c.ULFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Right');", true);
    }
    public void UpperLegFullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.ULFullFlexionAngleRight + a.ULFullFlexionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.ULFullFlexionAngleLeft+b.ULFullFlexionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.ULFullFlexionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "UpperLegFullFlexion('Upper Leg Full Flexion Angle Average');", true);
    }

    public void LowerLegFullFlexionLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Left');", true);
    }
    public void LowerLegFullFlexionRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleRight , b.LLFullFlexionAngleRight, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Right');", true);
    }
    public void LowerLegFullFlexionTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.LLFullFlexionAngleRight + a.LLFullFlexionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.LLFullFlexionAngleLeft+b.LLFullFlexionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.LLFullFlexionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "LowerLegFullFlexion('Lower Leg Full Flexion Angle Average');", true);
    }

    public void VelocityLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            //string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((((a.[GroundTimeLeft]+a.[GroundTimeRight])/2)+(a.[AirTimeLeftToRight]+a.[AirTimeRightToLeft])/2), 0 )),0)*((a.[StrideLengthLeftToRight]+a.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((((b.[GroundTimeLeft]+b.[GroundTimeRight])/2)+(b.[AirTimeLeftToRight]+b.[AirTimeRightToLeft])/2), 0 )),0)*((b.[StrideLengthLeftToRight]+b.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[GroundTime]+c.[AirTime]), 0 ))*[StrideLength],0) AS decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [SprintInitialData] a Inner Join SprintCurrentData b on a.LessonId = b.LessonId  Inner Join SprintModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Velocity('Velocity');", true);
    }
    public void VelocityRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            //string cmdstring = "SELECT Top 1 d.LessonId, a.LLFullFlexionAngleLeft , b.LLFullFlexionAngleLeft, c.LLFullFlexionAngle ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            string cmdstring = "SELECT Top 1 d.LessonId,CAST(ISNULL((1 / NULLIF((((a.[GroundTimeLeft]+a.[GroundTimeRight])/2)+(a.[AirTimeLeftToRight]+a.[AirTimeRightToLeft])/2), 0 )),0)*((a.[StrideLengthLeftToRight]+a.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Initial],CAST(ISNULL((1 / NULLIF((((b.[GroundTimeLeft]+b.[GroundTimeRight])/2)+(b.[AirTimeLeftToRight]+b.[AirTimeRightToLeft])/2), 0 )),0)*((b.[StrideLengthLeftToRight]+b.[StrideLengthRightToLeft])/2) as decimal(18,3))AS [Velocity_Final],CAST(ISNULL((1 / NULLIF((c.[GroundTime]+c.[AirTime]), 0 ))*[StrideLength],0) AS decimal(18,3))AS [Velocity_Model],(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [SprintInitialData] a Inner Join SprintCurrentData b on a.LessonId = b.LessonId  Inner Join SprintModelData c on c.LessonId = b.LessonId Inner Join Lesson d on d.LessonId = c.LessonId where d.LessonLocation not like ('%Summary%')and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "Velocity('Velocity');", true);
    }

    public void AirTimeLeftToRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.AirTimeLeftToRight,b.AirTimeLeftToRight, c.AirTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Left ');", true);
    }
    public void AirTimeRightToLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Distinct Top 1 d.LessonId, a.AirTimeRightToLeft,b.AirTimeRightToLeft, c.AirTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Right ');", true);
    }
    public void AirTimeTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {
            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.LLFullFlexionAngleRight + a.LLFullFlexionAngleLeft)/2 as decimal(18,3)) AS [TouchdownTotal],CAST((b.LLFullFlexionAngleLeft+b.LLFullFlexionAngleRight)/2 as decimal(18,3)) AS [TouchdownTotal1],c.LLFullFlexionAngle,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.LessonLocation not like ('%Summary%') and d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "AirTime('Air Time Average  ');", true);
    }
}

    