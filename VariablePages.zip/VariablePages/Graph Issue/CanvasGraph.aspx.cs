﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class VariablePages_CanvasGraph : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int index =Convert.ToInt32( Request.QueryString["index"]);
            if (index == 1)
            {
                GroundTimeLeft();
            }
            else if (index == 2)
            {
                GroundTimeRight();

            }
            else if (index == 3)
            {
                GroundTimeTotal();
            }
        }
    } 
    public void GroundTimeLeft()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]); 
             
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();
        
        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues=string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.GroundTimeLeft , b.GroundTimeLeft , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString()+":";
                xvalues += dt1.Rows[0][j + 4].ToString()+",";
                ViewState["val_"+k] = dt.Rows[0][j].ToString();
                k++;

               
            }
          
        }
      
        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;
      
     
        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Left');", true);
    }
    public void GroundTimeRight()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId, a.GroundTimeRight , b.GroundTimeRight , c.GroundTime ,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Right');", true);
    }
    public void GroundTimeTotal()
    {
        int CustomerID = Convert.ToInt32(Session["customerid"]);

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();

        string cmdstr = "select LessonId from Lesson where customerid = " + CustomerID;
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        //string cmdstr = "SELECT a.GroundTimeLeft, b.GroundTimeLeft,c.GroundTime FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = @LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = @LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = @LessonId where d.CustomerId ="+ CustomerID;      
        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn );
        adp.Fill(ds);
        dt = ds.Tables[0];
        //string[] x = new string[dt.Rows.Count];
        List<string> LessonIds = new List<string>();
        List<string> Values = new List<string>();
        string xvalues = string.Empty;
        string strvalues = string.Empty;
        string modelvalues = string.Empty;
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            LessonIds.Add(dt.Rows[i][0].ToString());
            //sy[i] = Convert.ToInt32(dt.Rows[i][1]);
        }
        int k = 0;
        ViewState["size"] = LessonIds.Count();
        foreach (var lessonID in LessonIds)
        {

            string cmdstring = "SELECT Top 1 d.LessonId,CAST((a.GroundTimeRight+a.GroundTimeLeft)/2 as decimal(18,3)) AS [Ground Time Average2],CAST((b.GroundTimeLeft+b.GroundTimeRight)/2 as decimal(18,3)) AS [Ground Time Average],c.GroundTime,(CONVERT(varchar(50),d.LessonDate)+' '+CONVERT(varchar(50),d.LessonLocation)) AS Session FROM [dbo].[SprintInitialData] a INNER JOIN [dbo].[SprintCurrentData] b ON a.LessonId = b.LessonId INNER JOIN  [dbo].[SprintModelData] c ON b.LessonId = c.LessonId INNER JOIN  [dbo].[Lesson] d ON c.LessonId = d.LessonId where d.CustomerId =" + CustomerID + " and d.LessonId=" + lessonID;
            SqlDataAdapter data1 = new SqlDataAdapter(cmdstring, conn);
            DataSet ds1 = new DataSet();
            data1.Fill(ds1);
            DataTable dt1 = new DataTable();
            dt1 = ds1.Tables[0];
            for (int j = 0; j < dt1.Rows.Count; j++)
            {
                if (dt1.Rows[0][j].ToString() == "0.00")
                {
                    continue;
                }
                if (dt1.Rows[0][j].ToString() == "")
                {
                    break;
                }
                Values.Add(dt.Rows[0][j].ToString());
                strvalues += dt1.Rows[0][j].ToString() + ",";
                strvalues += dt1.Rows[0][j + 1].ToString() + ",";
                strvalues += dt1.Rows[0][j + 2].ToString() + ",";
                strvalues += dt1.Rows[0][j + 3].ToString() + ":";
                xvalues += dt1.Rows[0][j + 4].ToString() + ",";
                ViewState["val_" + k] = dt.Rows[0][j].ToString();
                k++;


            }

        }

        hdnValues.Value = strvalues;
        hdnxvalues.Value = xvalues;


        Page.ClientScript.RegisterStartupScript(this.GetType(), "src", "ShowGraph('Ground Time Total');", true);
    }


}

    