﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

public partial class Admin_DeleteRedundantData : System.Web.UI.Page
{
    DataSet ds = new DataSet("Customer");
    static int cnt = 2;

    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = "data source=67.228.189.88,2433;User ID=smdbo; Password=4851ih!#;initial catalog=swingmodeldb;";
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT Customer.CustomerID,FirstName,LastName,a.LessonId,LessonDate,FilePath  FROM Movie as c,Customer,Lesson AS a WHERE Customer.CustomerID=a.CustomerID and c.LessonId =a.LessonId    and EXISTS (SELECT distinct b.LessonId  FROM Lesson AS b   WHERE a.CustomerId = b.CustomerId     ) and EXISTS  (select  d.FilePath  from Movie as d    where c.FilePath =d.FilePath    GROUP BY d.FilePath HAVING COUNT(*) > 1 ) order by FilePath ;", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Sort")
        {
        }
        else
        {
            int RowID = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "DeleteRow")
            {
                Lesson le = new Lesson();
                le = DataRepository.LessonProvider.GetByLessonId(RowID);
                DataRepository.LessonProvider.Delete(RowID);
                this.Page.Response.Redirect("~/Admin/DeleteRedundantLesson.aspx");
            }
        }
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        DataTable dt = ds.Tables[0];
        DataView dv = new DataView(dt);
        String SearchExpression = null;
        if (!String.IsNullOrEmpty(TextBox1.Text))
        {
            SearchExpression = string.Format("{0} '{1}%'",
            GridView1.SortExpression, TextBox1.Text);
            dv.RowFilter = "FirstName like " + SearchExpression + " or LastName like " + SearchExpression;
        }
        GridView1.DataSource = dv;
        GridView1.DataBind();

    }

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    private string ConvertSortDirectionToSql(SortDirection sortDirection)
    {
        string newSortDirection = String.Empty;



        switch (sortDirection)
        {
            case SortDirection.Ascending:
                newSortDirection = "DESC";

                if (cnt % 2 != 0)
                {
                    newSortDirection = "ASC";
                    cnt++;
                }
                else
                    cnt++;
                break;

            case SortDirection.Descending:
                newSortDirection = "ASC";
                break;
        }

        return newSortDirection;
    }


    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dataTable = ds.Tables[0];
        if (dataTable != null)
        {
            DataView dataView = new DataView(dataTable);
            dataView.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection);

            GridView1.DataSource = dataView;
            GridView1.DataBind();
        }
    }



    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
            lnkDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this ');");
        }
    }


}