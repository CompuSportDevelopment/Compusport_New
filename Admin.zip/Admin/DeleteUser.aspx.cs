﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using MemberDownload;
using SwingModel.Data;
using SwingModel.Data.SqlClient;
using SwingModel.Entities;
using SwingModel.Data.Bases;
using System.Web.Mail;
using System.Net.Mail;
using CompuSportDAL;
using System.Data.SqlClient;
//public partial class Facility_RenewMember : System.Web.UI.Page
public partial class Admin_RenewMember : SwingModel.UI.BasePage
{
    public GetMemberList gml = new GetMemberList();
    string FirstName = "";
    string LastName = "";
    string EmailAddress = "";
    int teacherfacility = 0;


    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CountryLookup countrylookup = new CountryLookup();
    CustomerSite customersite = new CustomerSite();
    Teacher teacher = new Teacher();
    Customer teacherc = new Customer();
    CustomerProfile teachercp = new CustomerProfile();
    Order order = new Order();
    Lesson lession = new Lesson();
	//public  TList<Lesson> lessonlist = new TList<Lesson>(); 
    CurrentFitStatus currentfitstatus = new CurrentFitStatus();
    Accounting accounting = new Accounting();
    Movie movie = new Movie();
    MovieClip movieclip = new MovieClip();
    MovieError movieeerror = new MovieError();
    SiteReferral sitereferral = new SiteReferral();
    ShotData shotdata = new ShotData();
    ShotDataAverage shotdataaverage = new ShotDataAverage();
    Teacher teacher1 = new Teacher();
    SprintAthleteEdit _sprintAthleteEdit = new SprintAthleteEdit();
    string[] roles = Roles.GetAllRoles();
    Customer AthleteSearched;
    Teacher Teacher = new Teacher();
    TeacherSite TeacherSite = new TeacherSite();

    protected void Page_Load(object sender, EventArgs e)
    {
        Button2.Enabled = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            int i = -9999;
            int cid = 0;

            ListBox1.Items.Clear();

            Label5.Text = "";
            Label7.Text = "";
            Label9.Text = "";
            Label11.Text = "";
            Label13.Text = "";
            Label15.Text = "";
            Label17.Text = "";
            Label19.Text = "";
            Label21.Text = "";
            Label23.Text = "";
            Label25.Text = "";
            Label27.Text = "";
            Label29.Text = "";
            Label31.Text = "";
            Label33.Text = "";
            Label35.Text = "";
            Label37.Text = "";
            Label39.Text = "";
            Label41.Text = "";
            Label3.Text = "";

            teacherc = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
            teachercp = DataRepository.CustomerProfileProvider.GetByCustomerId(teacherc.CustomerId)[0];
            if (teacherfacility.Equals(0))
                teacherfacility = teachercp.CustomerSite;

            //if (TextBox1.Text.Equals(null) || TextBox1.Text.Equals("") || TextBox2.Text.Equals(null) || TextBox2.Text.Equals(""))
            //{
            //    ListBox1.Items.Add("No Matches");
            //}
            if (TextBox1.Text.Equals("") && TextBox2.Text.Equals(""))
            {
                ListBox1.Items.Add("No Matches");
            }
            else
            {
                if (TextBox1.Text == "*" || TextBox2.Text == "*")
                {
                    if (TextBox1.Text == "*")
                    {
                        TextBox1.Text = "";
                    }
                    else
                    {
                        TextBox1.Text = TextBox1.Text;
                    }
                    if (TextBox2.Text == "*")
                    {
                        TextBox2.Text = "";
                    }
                    else
                        TextBox2.Text = TextBox2.Text;
                }

                #region[old code for seraching which getting all the athlets]
                //i = gml.GetMembers(TextBox1.Text, TextBox2.Text, "");

                //if (gml.GuidMatch.Count.Equals(0))
                //{
                //    ListBox1.Items.Add("No Matches");
                //}
                //else
                //{
                //    int x = 0;
                //    int y = 0;
                //    string ListBoxItem = "";
                //    foreach (string MemberGuid in gml.GuidMatch)
                //    {
                //        cid = Convert.ToInt16(gml.CustomerIdMatch[x].ToString());
                //        customer = DataRepository.CustomerProvider.GetByCustomerId(cid);
                //        //customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];

                //        ListBoxItem = gml.FirstNameMatch[x].ToString() + " " + gml.LastNameMatch[x].ToString() + ", " + gml.EmailMatch[x].ToString() + ", " + gml.UsernameMatch[x].ToString();

                //        ListBox1.Items.Add(ListBoxItem);
                //        ListBox1.Items[y].Value = gml.CustomerIdMatch[x].ToString() + "," + gml.UsernameMatch[x].ToString() + "|" + gml.EmailMatch[x].ToString();
                //        y++;
                //        //}
                //        x++;
                //    }
                //}
                #endregion[old code for seraching which getting all the athlets]

                #region[new code for seraching which getting all the athlet]
                if (Page.User.Identity.IsAuthenticated)
                {
                    DataTable dt = new DataTable();
                    teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                    DataTable dscustomer = _sprintAthleteEdit.Get_AthleteMembers(TextBox1.Text, TextBox2.Text);

                    //DataTable dstecher = _sprintAthleteEdit.GetMembers(TextBox1.Text, TextBox2.Text, teacher.TeacherId);
                    if (dscustomer != null)
                    {
                        int x = 0;
                        string ListBoxItem = "";
                        foreach (DataRow row in dscustomer.Rows)
                        {
                            DataRow r = dt.NewRow();
                            string userrolename = string.Empty;
                            int customerid = Convert.ToInt32(row["CustomerId"]);
                            AthleteSearched = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                            Guid MemGuid = new Guid(AthleteSearched.AspnetMembershipUserId.ToString());
                            MembershipUser user = Membership.GetUser(MemGuid);
                            string[] userrole = Roles.GetRolesForUser(user.UserName);
                            userrolename = userrole[0];


                            ListBoxItem = row["FirstName"].ToString() + " " + row["LastName"].ToString() + ", " + row["Email"].ToString();
                            ListBox1.Items.Add(ListBoxItem);
                            ListBox1.Items[x].Value = row["CustomerID"].ToString();
                            x++;

                        }
                        if (ListBox1.Items.Count == 0)
                        {
                            ListBox1.Items.Add("No Matches");
                        }

                    }
                    else
                    {
                        ListBox1.Items.Add("No Matches");
                    }
                }
                #endregion[new code for seraching which getting all the athlet of particular teacher]
            }
        }
        catch (Exception ex)
        {
        }

    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (!ListBox1.SelectedValue.Equals("No Matches"))
            {
                Button2.Enabled = true;
                #region[old code]
                //int x = ListBox1.SelectedIndex;
                //int comma = ListBox1.Items[x].Value.IndexOf(",");
                //int bar = ListBox1.Items[x].Value.IndexOf("|");
                //int customerid = Convert.ToInt16(ListBox1.Items[x].Value.Substring(0, comma));
                //string MemberUsername = ListBox1.Items[x].Value.Substring(comma + 1, bar - comma - 1);
                //string MemberEmail = ListBox1.Items[x].Value.Substring(bar + 1);

                //customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                //customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                //countrylookup = DataRepository.CountryLookupProvider.GetByCountryId(customer.Country);
                //customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
                //teacher = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
                //Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
                //MembershipUser user = Membership.GetUser(MemGuid);
                #endregion[old code]

                int x = ListBox1.SelectedIndex;
                int customerid = Convert.ToInt16(ListBox1.Items[x].Value);
                customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
                MembershipUser user1 = Membership.GetUser(MemGuid);
                string MemberUsername = user1.UserName.ToString();
                string MemberEmail = user1.Email;
                countrylookup = DataRepository.CountryLookupProvider.GetByCountryId(customer.Country);
                try
                {
                    customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                    customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
                    teacher1 = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
                }
                catch (Exception ex)
                {
                    customerprofile = new CustomerProfile();
                }

                Label5.Text = customer.FirstName;
                Label7.Text = customer.LastName;
                Label9.Text = MemberUsername;
                Label11.Text = MemberEmail;
                if (!customer.Address1.ToLower().Equals("none"))
                    Label13.Text = customer.Address1;
                else
                    Label13.Text = "";
                Label15.Text = customer.Address2;
                if (!customer.City.ToLower().Equals("none"))
                    Label17.Text = customer.City;
                else
                    Label17.Text = "";
                if (!customer.State.ToLower().Equals("none"))
                    Label19.Text = customer.State;
                else
                    Label19.Text = "";
                if (!customer.Zip.ToLower().Equals("none"))
                    Label21.Text = customer.Zip;
                else
                    Label21.Text = "";
                if (customer.Address1.ToLower().Equals("none") && customer.Country.Equals(248))
                    Label23.Text = "";
                else
                    Label23.Text = countrylookup.CountryName;
                Label25.Text = customer.PhoneHome;
                Label27.Text = customer.PhoneWork;
                Label29.Text = customer.PhoneMobile;
                Label31.Text = customer.Fax;
                Label33.Text = customersite.SiteName;
                Label35.Text = teacher1.FirstName + " " + teacher1.LastName;
                Label37.Text = user1.CreationDate.ToLongDateString();
                Label39.Text = customer.MembershipExpiration.ToLongDateString();
                switch (customer.MembershipStatus)
                {
                    case 0:
                        Label41.Text = "Expired";
                        break;

                    case 1:
                        Label41.Text = "Member";
                        break;

                    case 2:
                        Label41.Text = "Full Teaching";
                        break;

                    case 3:
                        Label41.Text = "Full Fitting";
                        break;

                    case 4:
                        Label41.Text = "Full Teaching & Fitting";
                        break;

                    case 97:
                        Label41.Text = "Comp Teaching";
                        break;

                    case 98:
                        Label41.Text = "Comp Fitting";
                        break;

                    case 99:
                        Label41.Text = "Comp Teaching & Fitting";
                        break;

                    default:
                        Label41.Text = "Missing";
                        break;
                }
            }
            return;
        }
        catch (Exception ex)
        {
        }

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            int x = ListBox1.SelectedIndex;
            DataTable dt = new DataTable();
            int customerid = Convert.ToInt16(ListBox1.Items[x].Value);
            customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
			//var teachers = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(customer.AspnetMembershipUserId);
			//var TeacherSite=   DataRepository.TeacherSiteProvider.GetByTeacherId(teachers[0].TeacherId);
           // DataRepository.TeacherSiteProvider.Delete(TeacherSite[0].TeacherLocationId);
           // DataRepository.TeacherProvider.Delete(teachers[0].TeacherId);
            Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());

            MembershipUser user = Membership.GetUser(MemGuid);
            Membership.DeleteUser(user.UserName, true);
            Membership.DeleteUser(user.UserName);

            try
            {
               // customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
		 //DataRepository.CustomerProfileProvider.Delete(customerid);
                 var data = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId);
		 if (data.Count > 0)
                {
                    customerprofile = data[0];
                }
               
            }
            catch (Exception ex)
            {
                var error = ex.Message;
            }

            currentfitstatus = DataRepository.CurrentFitStatusProvider.GetByCurrentFitStatusId(customer.CustomerId);
            order = DataRepository.OrderProvider.GetByOrderId(customerid);
            lession = DataRepository.LessonProvider.GetByLessonId(customerid);
            shotdata = DataRepository.ShotDataProvider.GetByShotDataId(customerid);
            try
            {
                if (lession != null)
                {
                    movie = DataRepository.MovieProvider.GetByMovieId(lession.LessonId);
                }
                if (movie != null)
                {
                    movieclip = DataRepository.MovieClipProvider.GetByMovieClipId(movieclip.MovieClipId);
                }
                if (movieclip != null)
                {
                    movieeerror = DataRepository.MovieErrorProvider.GetByMovieErrorId(movieclip.MovieClipId);
                }
                SqlMembershipProvider sqlmembership = new SqlMembershipProvider();

                //Customer--AccountingB
                DataRepository.AccountingProvider.Delete(customerid);
                //Customer--Current Status Fit dependencies
                DataRepository.CurrentFitStatusProvider.Delete(customerid);
                DataRepository.CustomerSiteBillingDetailsProvider.Delete(customer.CustomerId);
                if (currentfitstatus != null)
                {
                    DataRepository.FinalIronFitProvider.Delete(currentfitstatus.CurrentFitStatusId);
                    DataRepository.FinalIronFitProvider.Delete(currentfitstatus.CurrentFitStatusId);
                    DataRepository.InitialIronFitProvider.Delete(currentfitstatus.CurrentFitStatusId);
                    DataRepository.InitialWoodFitProvider.Delete(currentfitstatus.CurrentFitStatusId);
                    DataRepository.StudentClubDetailsProvider.Delete(currentfitstatus.CurrentFitStatusId);
                }
                if (customerprofile != null)
                {
                    //DataRepository.CustomerProfileProvider.Delete(customerid);
                    _sprintAthleteEdit.DeleteCustomerProfileByCustomerId(customerid);
                }

                //Order- dependencies
                if (order != null && order.OrderId != 0)
                {
                    DataRepository.ClubOrderProvider.Delete(order.OrderId);
                    DataRepository.OrderProvider.Delete(customerid);
                }
                if (sitereferral != null && sitereferral.SiteReferralId != 0)
                {
                    DataRepository.SiteReferralProvider.Delete(customerid);
                }
                if (shotdata != null && shotdata.ShotDataId != 0)
                {
                    DataRepository.ShotDataProvider.Delete(customerid);
                }
                if (shotdataaverage != null && shotdataaverage.ShotDataAverageId != 0)
                {
                    DataRepository.ShotDataAverageProvider.Delete(customerid);
                }
                //Customer- Lession Dependencies.
                try
                {
                    if (lession != null)
                    {
                        if (movieeerror != null && movieeerror.MovieErrorId != 0)
                        {
                            DataRepository.MovieErrorProvider.Delete(movieeerror.MovieClipId);
                        }
                        if (movieclip != null && movieclip.MovieClipId != 0)
                        {
                            DataRepository.MovieClipProvider.Delete(movieclip.MovieClipId);
                            DataRepository.MovieClipProvider.Delete(movie.MovieId);

                        }
                        if (movie != null && movie.MovieId != 0)
                        {

                            DataRepository.MovieProvider.Delete(lession.LessonId);
                        }
                        DataRepository.LessonProvider.Delete(customerid);
                    }
                    _sprintAthleteEdit.DeleteFromAssignSecondaryCoach(customerid);
                    _sprintAthleteEdit.DeleteFromAssignPrimaaryCoach(customerid);
                    DataRepository.CustomerProvider.Delete(customerid);
                }
                catch (Exception ex)
                {

                }
				
				try
                {
                    var teachers = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(customer.AspnetMembershipUserId);
                   // Teacher = DataRepository.TeacherProvider.GetByTeacherId(teachers[0].TeacherId);
                    var TeacherSite = DataRepository.TeacherSiteProvider.GetByTeacherId(teachers[0].TeacherId);
                   // DataTable spdata = _sprintAthleteEdit.GetPrimaryAthletsCoach(Teacher.TeacherId);
                    if (TeacherSite != null)
                    {
                        DataRepository.TeacherSiteProvider.Delete(TeacherSite[0].TeacherLocationId);
                        Assignprimarycoach(teachers[0].TeacherId);
                    }
                    if (teachers != null)
                    {
                        DataRepository.TeacherProvider.Delete(teachers[0].TeacherId);
                        
                    }
                    
                }
                catch { 
                
                }
				
                //  DataRepository.MembershipStatusLookupProvider.Delete();
                ListBox1.SelectedItem.Text = "";
                ListBox1.ClearSelection();
                Label3.Text = "User " + user.UserName.ToString() + " has been deleted with his all releted data.";
                SmtpMail.SmtpServer = "localhost";
                SmtpMail.Send("dev@swingmodel.com", "dev@swingmodel.com", "User Deleted", "The user " + customer.FirstName.ToString() + " " + customer.LastName.ToString() + " " + " has been deleted with his related data.");


            }
            catch (Exception ex)
            {

            }
        }
        catch (Exception ex)
        {
        }
    }
	 public void Assignprimarycoach(int TeacherId) {
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        try
        {
            using (var connection = new SqlConnection(ConnectionString))
            using (var cmd = connection.CreateCommand())
            {
                connection.Open();
                cmd.CommandText = "DELETE FROM AssignPrimaryCoach WHERE TeacherId = @TeacherId";
                cmd.Parameters.AddWithValue("@TeacherId", TeacherId);
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            
        }
		
		try
        {
            using (var connection = new SqlConnection(ConnectionString))
            using (var cmd = connection.CreateCommand())
            {
                connection.Open();
                cmd.CommandText = "DELETE FROM AssignAthleteCoach WHERE TeacherId = @TeacherId";
                cmd.Parameters.AddWithValue("@TeacherId", TeacherId);
                cmd.ExecuteNonQuery();
            }

        }
        catch
        {

        }
    
    }
}
