﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using SwingModel.Data;
using SwingModel.Entities;

public partial class Admin_CustomerInformation : System.Web.UI.Page
{
    string PassedUsername = "";
    int x;
    Customer customer = new Customer();

    protected override void OnPreLoad(EventArgs e)
    {
        if (ddlCountry.SelectedValue.Equals(""))
        {
            TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
            ddlCountry.Items.Clear();
            ddlCountry.Items.Add("Select Country");
            ddlCountry.Items[0].Value = "0";
            ddlCountry.Items[0].Selected = false;
            x = 0;
            foreach (CountryLookup country in countries)
            {
                x++;
                ddlCountry.Items.Add(country.CountryName);
                ddlCountry.Items[x].Value = country.CountryId.ToString();
            }
        }
        if (ddlShippingCountry.SelectedValue.Equals(""))
        {
            TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
            ddlShippingCountry.Items.Clear();
            ddlShippingCountry.Items.Add("Select Country");
            ddlShippingCountry.Items[0].Value = "0";
            ddlShippingCountry.Items[0].Selected = false;
            x = 0;
            foreach (CountryLookup country in countries)
            {
                x++;
                ddlShippingCountry.Items.Add(country.CountryName);
                ddlShippingCountry.Items[x].Value = country.CountryId.ToString();
            }
        }
    }

    protected void ddlShippingCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Convert.ToInt16(ddlCountry.SelectedValue).Equals(248) || Convert.ToInt16(ddlCountry.SelectedValue).Equals(287))
        {
            //DropDownList5.Visible = true;
            //txtPostalCode.Visible = false;

            //DropDownList5.Items.Clear();
            //DropDownList5.Items.Add("Select State/Province");
            //DropDownList5.Items[0].Value = "0";
            //x = 0;
            //TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(Convert.ToInt16(ddlCountry.SelectedValue));
            //foreach (StateProvince sp in states)
            //{
            //    x++;
            //    DropDownList5.Items.Add(sp.StateProvinceName);
            //    DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
            //}
            //DropDownList5.SelectedValue = DropDownList5.Items[0].Value;
        }
        else
        {
            //DropDownList5.Visible = false;
            //txtPostalCode.Visible = true;
            //txtPostalCode.Text = "";
        }
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Convert.ToInt16(ddlCountry.SelectedValue).Equals(248) || Convert.ToInt16(ddlCountry.SelectedValue).Equals(287))
        {
            //DropDownList5.Visible = true;
            //txtPostalCode.Visible = false;

            //DropDownList5.Items.Clear();
            //DropDownList5.Items.Add("Select State/Province");
            //DropDownList5.Items[0].Value = "0";
            //x = 0;
            //TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(Convert.ToInt16(ddlCountry.SelectedValue));
            //foreach (StateProvince sp in states)
            //{
            //    x++;
            //    DropDownList5.Items.Add(sp.StateProvinceName);
            //    DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
            //}
            //DropDownList5.SelectedValue = DropDownList5.Items[0].Value;
        }
        else
        {
            //DropDownList5.Visible = false;
           // txtPostalCode.Visible = true;
            //txtPostalCode.Text = "";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        PassedUsername = Request.QueryString.Get("Username");
        lblUserNameValue.Text = Request.QueryString.Get("Username");
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int Country = 0;
            int ShipCountry = 0;
            string FirstName = txtFirstName.Text.Trim();
            string LastName = txtLastName.Text.Trim();
            string Address1 = "";
            string Address2 = "";
            string City = "";
            string State = "";
            string Zip = "";
            string ShippingFirstName = "";
            string ShippingLastName = "";
            string ShippingAddress1 = "";
            string ShippingAddress2 = "";
            string ShippingCity = "";
            string ShippingState = "";
            string ShippingZip = "";
            string ShippingRegion = "";


            #region[This Value Passed By Hard Coded]
            //int MembershipStatus = 1
            //if (txtMembershipExpirationDate.Text.Trim() != "")
            //{
            //    MembershipExpiration = Convert.ToDateTime(txtMembershipExpirationDate.Text.Trim());
            //}
            //if (txtMembershipRenewal.Text.Trim() != "")
            //{
            //    MembershipRenewal = Convert.ToDateTime(txtMembershipRenewal.Text.Trim());
            //}
            //if (txtIsRenewal.Text.Trim() != "")
            //{
            //    IsRenewal = Convert.ToInt32(txtIsRenewal.Text.Trim()); ;
            //}
            //if (txtMembershipCost.Text.Trim() != "")
            //{
            //    MembershipCost = Convert.ToInt32(txtMembershipCost.Text.Trim());
            //}
            //if (txtBillFacility.Text.Trim() != "")
            //{
            //    BillFacility = Convert.ToInt32(txtBillFacility.Text.Trim()); ;
            //}
            #endregion[This Value Passed By Hard Coded]
            //customer.AppType
            //if (ddlCountry.SelectedItem.Text == "Select Country")
            //{
            //    lblerrorcountry.Visible = true;
            //    lblerrorcountry.Text = "Please Select country name";
            //}
            //else
            //{
            //    lblerrorcountry.Visible = false;
            //    Country = Convert.ToInt32(ddlCountry.SelectedValue);

            //}
            //if (ddlShippingCountry.SelectedItem.Text == "Select Country")
            //{
            //    lblerrorshppingcountry.Visible = true;
            //    lblerrorshppingcountry.Text = "Please Select country name";
            //}
            //else
            //{
            //    lblerrorshppingcountry.Visible = false;
            //    ShipCountry = Convert.ToInt32(ddlShippingCountry.SelectedValue);
            //}
            
            ShipCountry = 1;
            Country = 1;
            string PhoneHome = "";
            string PhoneWork = "";
            string PhoneMobile = "";
            string Fax = "";
            //int AppType;

            Guid AspnetMembershipUserId=new Guid();
            if (!(lblerrorshppingcountry.Visible || lblerrorcountry.Visible))
            {
                MembershipUser user = Membership.GetUser(PassedUsername);
                user.IsApproved = true;
                Membership.UpdateUser(user);

                //Bydefault user is Golfer(athlete)
                Roles.AddUserToRole(user.UserName, "Athletes");
                AspnetMembershipUserId = ((Guid)user.ProviderUserKey);
            }


            #region[Assign Values and insert the Customer]
            customer.FirstName = FirstName;
            customer.LastName = LastName;
            customer.Address1 = Address1;
            customer.Address2 = Address2;
            customer.City = City;
            customer.State = State;
            customer.Zip = Zip;

            customer.ShippingFirstName = ShippingFirstName;
            customer.ShippingLastName = ShippingLastName;
            customer.ShippingAddress1 = ShippingAddress1;
            customer.ShippingAddress2 = ShippingAddress2;
            customer.ShippingCity = ShippingCity;
            customer.ShippingState = ShippingState;
            customer.ShippingZip = ShippingZip;
            customer.ShippingRegion = ShippingRegion;

            customer.AspnetMembershipUserId = AspnetMembershipUserId;
            customer.MembershipStatus = 1;
            customer.MembershipExpiration = DateTime.Today.AddYears(1); ;
            customer.MembershipRenewal = DateTime.Today;
            customer.IsRenewal = 0;
            customer.MembershipCost = 50;
            customer.BillFacility = 0;

            customer.Country = Country;
            customer.ShipCountry = ShipCountry;
            customer.PhoneHome = PhoneHome;
            customer.PhoneWork = PhoneWork;
            customer.PhoneMobile = PhoneMobile;
            customer.Fax = Fax;
          
            if (!(lblerrorshppingcountry.Visible || lblerrorcountry.Visible))
            {
                DataRepository.CustomerProvider.Insert(customer);
            #endregion[Assign Values and insert the Customer]
                ClearAllData();
                Response.Redirect("~/Admin/MakeNewMember.aspx",false);
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    private void ClearAllData()
    {
        try
        {
            txtFirstName.Text="";
            txtLastName.Text="";
            txtAddress1.Text="";
            txtAddress2.Text="";
            txtCity.Text="";
            txtState.Text="";
            txtPostalCode.Text="";
            txtShippingFirstName.Text="";
            txtShippingLastName.Text="";
            txtShippingAddress1.Text="";
            txtShippingAddress2.Text="";
            txtShippingCity.Text="";
            txtShippingState.Text="";
            txtShippingPostalCode.Text="";
            txtShippingPostalCode.Text="";
            txtShippingRegion.Text = "";
            ddlCountry.SelectedIndex = 0;
            ddlShippingCountry.SelectedIndex = 0;
            txtphoneHome.Text = "";
            txtPhoneWork.Text = "";
            txtMobile.Text = "";
            txtFax.Text = "";
        }
        catch (Exception ex)
        { 
        
        }
    }
}
