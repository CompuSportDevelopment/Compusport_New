﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using CompuSportDAL;

//public partial class Teachers_MemberList : System.Web.UI.Page
public partial class Teachers_MemberList : SwingModel.UI.BasePage
{

    public Customer customer;
    public CustomerProfile customerprofile;
    public IEnumerable teachersatsite;
    public Teacher teacher;
    public CustomerSite customersite;
    public IEnumerable teacherall;
    bool AthleteAlreadyInList;
    int x;
    string[] roles = Roles.GetAllRoles();
    SprintAthleteEdit _sprintAthleteEdit = new SprintAthleteEdit();
    Customer AthleteSearched;
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                var data = DataRepository.CustomerProfileProvider.GetByCustomerId(teacher.TeacherId);
                if (data.Count > 0)
                {
                    customerprofile = data[0];
                }
            }
            catch (Exception ex)
            {
                var error = ex.Message;
            }
            string logusrname1 = User.Identity.Name;
            if (DropDownList1.Items.Count.Equals(0))
            {
                DropDownList1.Items.Clear();
                DataTable dt1 = new DataTable();
                dt1 = sae.GetAllTeachers();
                DataRow dr = dt1.NewRow();
                DropDownList1.DataSource = dt1;
                DropDownList1.DataTextField = "FullName";
                DropDownList1.DataValueField = "TeacherId";
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, new ListItem("Make a Selection", "0"));

                //foreach (TeacherSite ts in teacherall)
                //{
                //    teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                //    teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                //    string userrolename = string.Empty;
                //    Guid MemGuid = new Guid(teacher.AspnetMembershipUserId.ToString());
                //    MembershipUser user = Membership.GetUser(MemGuid);
                //    //Error ---------------------------------------------------------------------------------------

                //    teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                //    if (DropDownList1.Items.Count > 0)
                //    {
                //        if (DropDownList1.Items.Contains(DropDownList1.Items.FindByValue(teacher.TeacherId.ToString())))
                //            AthleteAlreadyInList = true;
                //        else
                //            AthleteAlreadyInList = false;
                //    }

                //    if (!AthleteAlreadyInList)
                //    {
                //        x++;
                //        DropDownList1.Items.Add(teacher.FirstName + " " + teacher.LastName);
                //        DropDownList1.Items[x].Value = teacher.TeacherId.ToString();
                //    }
                //    if(user != null)
                //    {
                //    var userrole = Roles.GetRolesForUser(user.UserName);
                //    foreach (var res in userrole)
                //    {
                //        userrolename = res;
                //    }
                //    }
                //    if (userrolename != "Athletes")
                //    {
                //        if (DropDownList1.Items.Count > 0)
                //        {
                //            if (DropDownList1.Items.Contains(DropDownList1.Items.FindByValue(teacher.TeacherId.ToString())))
                //                AthleteAlreadyInList = true;
                //            else
                //                AthleteAlreadyInList = false;
                //        }

                //        if (!AthleteAlreadyInList)
                //        {
                //            x++;
                //            DropDownList1.Items.Add(teacher.FirstName + " " + teacher.LastName);
                //            DropDownList1.Items[x].Value = teacher.TeacherId.ToString();
                //        }
                //    }
                //}
            }
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int SelectedTeacherId = Convert.ToInt16(DropDownList1.SelectedValue);

        try
        {
            teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
            //  customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(teacher.TeacherId)[0];           
        }
        catch
        {

        }
        CustomerSite siteid;
        int x = 0;
        DataTable dt = new DataTable();
        dt.Columns.Add("Count", typeof(int));
        dt.Columns.Add("First Name", typeof(string));
        dt.Columns.Add("Last Name", typeof(string));

        dt.Columns.Add("Email Address", typeof(string));
        dt.Columns.Add("Facility", typeof(string));
        dt.Columns.Add("ExpirationDate", typeof(string));
        // dt.Columns.Add("Status", typeof(string));
        dt.Columns.Add("Tier", typeof(int));
        dt.Columns.Add("TeacherType", typeof(int));
        try
        {
            DataTable dtathlets = _sprintAthleteEdit.GetPrimaryAthletsCoach(SelectedTeacherId);
            DataTable dtathlets1 = _sprintAthleteEdit.GetSecondaryAthlets_Coach(SelectedTeacherId);

            #region[Primary Coach Data]
            if (dtathlets != null)
            {
                foreach (DataRow row in dtathlets.Rows)
                {
                    DataRow r = dt.NewRow();
                    string userrolename = string.Empty;
                    int customerid = Convert.ToInt32(row["CustomerId"]);
                    AthleteSearched = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                    Guid MemGuid = new Guid(AthleteSearched.AspnetMembershipUserId.ToString());
                    MembershipUser user = Membership.GetUser(MemGuid);
                    string[] userrole = Roles.GetRolesForUser(user.UserName);
                    userrolename = userrole[0];
                    if (userrolename == "Athletes")
                    {
                        string custid = row["CustomerId"].ToString();
                        x++;
                        r["First Name"] = row["FirstName"].ToString();
                        r["Last Name"] = row["LastName"].ToString();
                        r["Email Address"] = row["Email"].ToString();

                        DateTime date = new DateTime();
                        date = Convert.ToDateTime(row["MemberShipExpiration"]);
                        string onlydate = date.Month + "/" + date.Day + "/" + date.Year;
                        r["ExpirationDate"] = onlydate;
                        // r["Status"] = row["MemberShipStatus"].ToString();
                        r["Count"] = x.ToString();
                        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(Convert.ToInt16(custid))[0];
                        if (!string.IsNullOrEmpty(customerprofile.InitialTeacher.ToString()))
                        {
                            r["Tier"] = customerprofile.InitialTeacher;//tier number of athlete
                        }
                        else
                        {
                            r["Tier"] = Convert.ToInt16(null);
                        }
                        r["TeacherType"] = 1;
                        siteid = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
                        r["Facility"] = siteid.SiteName.ToString();
                        dt.Rows.Add(r);
                    }
                }
            }
            #endregion[Primary Coach Data]
            #region[Secondary Coach Data]
            if (dtathlets1 != null)
            {
                foreach (DataRow row in dtathlets1.Rows)
                {
                    DataRow r = dt.NewRow();
                    string userrolename1 = string.Empty;
                    int customerid1 = Convert.ToInt32(row["CustomerId"]);
                    AthleteSearched = DataRepository.CustomerProvider.GetByCustomerId(customerid1);
                    Guid MemGuid1 = new Guid(AthleteSearched.AspnetMembershipUserId.ToString());
                    MembershipUser user1 = Membership.GetUser(MemGuid1);
                    string[] userrole1 = Roles.GetRolesForUser(user1.UserName);
                    userrolename1 = userrole1[0];
                    if (userrolename1 == "Athletes")
                    {
                        string custid = row["CustomerId"].ToString();
                        x++;
                        r["First Name"] = row["FirstName"].ToString();
                        r["Last Name"] = row["LastName"].ToString();
                        r["Email Address"] = row["Email"].ToString();

                        DateTime date = new DateTime();
                        date = Convert.ToDateTime(row["MemberShipExpiration"]);
                        string onlydate = date.Month + "/" + date.Day + "/" + date.Year;
                        r["ExpirationDate"] = onlydate;
                        //r["Status"] = row["MemberShipStatus"].ToString();
                        r["Count"] = x.ToString();
                        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(Convert.ToInt16(custid))[0];
                        if (!string.IsNullOrEmpty(customerprofile.InitialTeacher.ToString()))
                        {
                            r["Tier"] = customerprofile.InitialTeacher;//tier number of athlete
                        }
                        else
                        {
                            r["Tier"] = Convert.ToInt16(null);
                        }
                        r["TeacherType"] = 2;
                        siteid = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
                        r["Facility"] = siteid.SiteName.ToString();
                        dt.Rows.Add(r);
                    }
                }
            }
            #endregion[Secondary Coach Data]
        }
        catch
        {
        }
        DataTable AthleteData = dt;
        // AthleteData.DefaultView.Sort = "First Name";
        GridView1.DataSource = AthleteData;
        GridView1.DataBind();

    }
}
