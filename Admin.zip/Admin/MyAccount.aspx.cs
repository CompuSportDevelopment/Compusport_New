﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;
using System.Data.SqlClient;

//public partial class Users_MyAccount : System.Web.UI.Page
public partial class Users_MyAccount : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    bool customerexists = false;
    bool customerprofileexists = false;
    bool sitechanged = false;
    int stateprovinceid = -1;
    int x;
    CustomerSite site_names;
    CompuSportDAL.SprintAthleteEdit _sprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();
    protected override void OnPreLoad(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
                Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
                Guid rollid = _sprintAthleteEdit.GetRollIdByUserId(MemGuid);
                if (rollid.ToString().Trim().ToUpper() != "3C195D36-1032-4CF9-A383-757A2EC5BEA2")//Administrators
                {
                    // DropDownList3.Enabled = false;
                    DropDownList3.Enabled = false;
                    DropDownList4.Enabled = false;
                }
                if (rollid.ToString().Trim().ToUpper() != "D27F6DE3-A8D4-492E-B154-CF1BC5B44129")//Golfer
                {
                    //Label39.Visible = false;
                    Label40.Visible = false;
                    DropDownList4.Visible = false;
                }
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
                if (DropDownList2.SelectedValue.Equals("") || DropDownList2.SelectedValue.Equals(null))
                {
                    TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
                    DropDownList2.Items.Clear();
                    DropDownList2.Items.Add("Select Country");
                    DropDownList2.Items[0].Value = "0";
                    DropDownList2.Items[0].Selected = false;
                    x = 0;
                    foreach (CountryLookup country in countries)
                    {
                        x++;
                        DropDownList2.Items.Add(country.CountryName);
                        DropDownList2.Items[x].Value = country.CountryId.ToString();
                    }
                }
            }

            try
            {
                customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                customerprofileexists = true;
            }
            catch
            {
                //no entery in CustomerProfile table for current member
                customerprofileexists = false;
                #region[Old Code For Home Location change the code on the basis of primary coach home location]
                //if (DropDownList3.SelectedValue.Equals("") || DropDownList3.SelectedValue.Equals(null))
                //{
                //    TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
                //    DropDownList3.Items.Clear();
                //    DropDownList3.Items.Add("Select Home Location");
                //    DropDownList3.Items[0].Value = "0";
                //    DropDownList3.Items[0].Selected = false;
                //    x = 0;
                //    foreach (CustomerSite cs in customersites)
                //    {
                //        x++;
                //        DropDownList3.Items.Add(cs.SiteName);
                //        DropDownList3.Items[x].Value = cs.CustomerSiteId.ToString();
                //    }
                //}


                //if (DropDownList4.SelectedValue.Equals("") || DropDownList4.SelectedValue.Equals(null))
                //{
                //    //DropDownList4.Items.Clear();
                //    //DropDownList4.Items.Add("Select Teacher");
                //    //DropDownList4.Items[0].Value = "0";
                //    //DropDownList4.Items[0].Selected = false;
                //    DropDownList4.Items.Clear();
                //    DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customer.CustomerId);
                //    DropDownList4.DataSource = dsCoachName.Tables[0];
                //    DropDownList4.DataTextField = "CoachName";
                //    DropDownList4.DataValueField = "TeacherId";
                //    DropDownList4.DataBind();
                //    DropDownList4.SelectedIndex = 0;
                //}
                #endregion[Old Code For Home Location change the code on the basis of primary coach home location]
            }
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        try
        {
            if (Page.User.Identity.IsAuthenticated)
            {
                if (customerexists)
                {
                    Label24.Text = Membership.GetUser().UserName;
                    Label28.Text = Membership.GetUser().Email;

                    if (customer.FirstName.Equals("") || customer.FirstName.Equals(null))
                    {
                        Label15.Visible = true;
                    }
                    else
                    {
                        TextBox1.Text = customer.FirstName;
                        Label15.Visible = false;
                    }
                    if (customer.LastName.Equals("") || customer.LastName.Equals(null))
                    {
                        Label16.Visible = true;
                    }
                    else
                    {
                        TextBox2.Text = customer.LastName;
                        Label16.Visible = false;
                    }
                    if (customer.Address1.Equals("") || customer.Address1.Equals(null))
                    {
                        Label20.Visible = true;
                    }
                    else
                    {
                        if (customer.Address1.Trim().Equals("None"))
                            TextBox5.Text = "";
                        else
                            TextBox5.Text = customer.Address1;
                        Label20.Visible = false;
                    }
                    //if (customer.Address2.Equals("") || customer.Address2.Equals(null))
                    //{
                    //Address2 is empty
                    //}
                    //else
                    //{
                    TextBox6.Text = customer.Address2;
                    //}
                    if (customer.City.Equals("") || customer.City.Equals(null))
                    {
                        Label21.Visible = true;
                    }
                    else
                    {
                        if (customer.City.Trim().Equals("None"))
                            TextBox7.Text = "";
                        else
                            TextBox7.Text = customer.City;
                        Label21.Visible = false;
                    }
                    if (customer.Country.Equals("") || customer.Country.Equals(null))
                    {
                        Label19.Visible = true;
                    }
                    else
                    {
                        TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Select Country");
                        DropDownList2.Items[0].Value = "0";
                        DropDownList2.Items[0].Selected = false;
                        x = 0;
                        foreach (CountryLookup country in countries)
                        {
                            x++;
                            DropDownList2.Items.Add(country.CountryName);
                            DropDownList2.Items[x].Value = country.CountryId.ToString();
                            if (customer.Country.Equals(country.CountryId))
                            {
                                DropDownList2.Items[x].Selected = true;
                            }
                        }
                        Label19.Visible = false;
                    }
                    if (customer.State.Equals("") || customer.State.Equals(null))
                    {
                        if (customer.Country.Equals(248) || customer.Country.Equals(287))
                        {
                            DropDownList5.Visible = true;
                            TextBox8.Visible = false;

                            DropDownList5.Items.Clear();
                            DropDownList5.Items.Add("Select State/Province");
                            DropDownList5.Items[0].Value = "0";
                            x = 0;
                            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(customer.Country);
                            foreach (StateProvince sp in states)
                            {
                                x++;
                                DropDownList5.Items.Add(sp.StateProvinceName);
                                DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
                            }
                            DropDownList5.SelectedValue = DropDownList5.Items[0].Value;
                        }
                        else
                        {
                            DropDownList5.Visible = false;
                            TextBox8.Visible = true;
                            TextBox8.Text = "";
                        }

                        Label22.Visible = true;
                    }
                    else
                    {
                        string stateprovinceabbvr = "0";
                        if (customer.Country.Equals(248) || customer.Country.Equals(287))
                        {
                            try
                            {
                                StateProvince stateprovince = DataRepository.StateProvinceProvider.GetByStateProvinceAbbvr(customer.State)[0];
                                stateprovinceid = stateprovince.Country;
                                stateprovinceabbvr = stateprovince.StateProvinceAbbvr;
                            }
                            catch
                            {
                                stateprovinceid = -1;
                                stateprovinceabbvr = "0";
                                Label22.Visible = true;
                            }

                            DropDownList5.Visible = true;
                            TextBox8.Visible = false;

                            DropDownList5.Items.Clear();
                            DropDownList5.Items.Add("Select State/Province");
                            DropDownList5.Items[0].Value = "0";
                            x = 0;
                            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(customer.Country);
                            foreach (StateProvince sp in states)
                            {
                                x++;
                                DropDownList5.Items.Add(sp.StateProvinceName);
                                DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
                            }
                            DropDownList5.SelectedValue = stateprovinceabbvr;
                        }
                        else
                        {
                            DropDownList5.Visible = false;
                            TextBox8.Visible = true;
                            if (customer.State.Trim().Equals("None"))
                                TextBox8.Text = "";
                            else
                                TextBox8.Text = customer.State;
                        }
                        //if (customer.Country.Equals(248) || customer.Country.Equals(287))
                        //{
                        //    if (stateprovinceabbvr.Equals("0"))
                        //        Label22.Visible = true;
                        //    else
                        //        Label22.Visible = false;
                        //}
                        //else
                        //{
                        if (customer.State.Trim().Equals("None"))
                            Label22.Visible = true;
                        else
                            Label22.Visible = false;
                        // }
                    }
                    if (customer.Zip.Equals("") || customer.Zip.Equals(null))
                    {
                        Label23.Visible = true;
                    }
                    else
                    {
                        if (customer.Zip.Trim().Equals("None"))
                            TextBox9.Text = "";
                        else
                            TextBox9.Text = customer.Zip;
                        Label23.Visible = false;
                    }
                    //if (customer.PhoneHome.Equals("") || customer.PhoneHome.Equals(null))
                    //{
                    //}
                    //else
                    //{
                    TextBox10.Text = customer.PhoneHome;
                    //}
                    //if (customer.PhoneMobile.Equals("") || customer.PhoneMobile.Equals(null))
                    //{
                    //}
                    //else
                    //{
                    TextBox11.Text = customer.PhoneMobile;
                    //}
                    //if (customer.PhoneWork.Equals("") || customer.PhoneWork.Equals(null))
                    //{
                    //}
                    //else
                    //{
                    TextBox12.Text = customer.PhoneWork;
                    //}
                    //if (customer.Fax.Equals("") || customer.Fax.Equals(null))
                    //{
                    //}
                    //else
                    //{
                    TextBox13.Text = Profile.Fax;
                    //}
                }
                else
                {
                    Label15.Visible = true;
                    Label16.Visible = true;
                    Label19.Visible = true;
                    Label20.Visible = true;
                    Label21.Visible = true;
                    Label22.Visible = true;
                    Label23.Visible = true;
                }

                if (customerprofileexists)
                {
                    if (customerprofile.Gender.Equals("") || customerprofile.Gender.Equals(null) || customerprofile.Gender.ToString().Equals("0"))
                    {
                        Label17.Visible = true;
                    }
                    else
                    {
                        DropDownList1.SelectedValue = customerprofile.Gender;
                        Label17.Visible = false;
                    }

                    if (customerprofile.CustomerSite.Equals("") || customerprofile.CustomerSite.Equals(null))
                    {
                        #region[Old Code For Home Location change the code on the basis of primary coach home location]
                        //TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
                        //DropDownList3.Items.Clear();
                        //DropDownList3.Items.Add("Select Home Location");
                        //DropDownList3.Items[0].Value = "0";
                        //DropDownList3.Items[0].Selected = true;
                        //x = 0;
                        //customersites.Sort("SiteName ASC");
                        //foreach (CustomerSite cs in customersites)
                        //{
                        //    x++;
                        //    DropDownList3.Items.Add(cs.SiteName);
                        //    DropDownList3.Items[x].Value = cs.CustomerSiteId.ToString();
                        //}
                        //Label38.Visible = true;
                        #endregion[Old Code For Home Location change the code on the basis of primary coach home location]
                    }
                    else
                    {
                        if (!IsPostBack)
                        {
                            #region[Old Code For Home Location change the code on the basis of primary coach home location]
                            //TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
                            //DropDownList3.Items.Clear();
                            //DropDownList3.Items.Add("Select Home Location");
                            //DropDownList3.Items[0].Value = "0";
                            //DropDownList3.Items[0].Selected = false;
                            //x = 0;
                            //customersites.Sort("SiteName ASC");
                            //foreach (CustomerSite cs in customersites)
                            //{

                            //    x++;
                            //    DropDownList3.Items.Add(cs.SiteName);
                            //    DropDownList3.Items[x].Value = cs.CustomerSiteId.ToString();
                            //}
                            //DropDownList3.SelectedValue = customerprofile.CustomerSite.ToString();
                            //Label38.Visible = false;
                            #endregion[Old Code For Home Location change the code on the basis of primary coach home location]
                            TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
                            DropDownList3.Items.Clear();
                            foreach (CustomerSite cs in customersites)
                            {
                                if (cs.CustomerSiteId == customerprofile.CustomerSite)
                                {
                                    DropDownList3.Items.Add(cs.SiteName);
                                    DropDownList3.Items[0].Value = cs.CustomerSiteId.ToString();
                                    DropDownList3.SelectedValue = customerprofile.CustomerSite.ToString();
                                    break;
                                }
                            }
                            //  Label38.Visible = false;
                        }
                        else
                        {
                            //if (sitechanged)
                            //{
                            //    customerprofile.Teacher = 0;
                            //    sitechanged = false;
                            //    if (DropDownList3.SelectedValue.Equals("0"))
                            //        Label38.Visible = true;
                            //    else
                            //        Label38.Visible = false;
                            //}
                        }
                    }

                    if (customerprofile.Teacher.Equals("") || customerprofile.Teacher.Equals(null) || customerprofile.Teacher.Equals(0) || DropDownList3.SelectedValue.Equals("0") || DropDownList3.SelectedValue.Equals(null) || DropDownList3.SelectedValue.Equals(""))
                    {
                        #region[oldecode]
                        //TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList3.SelectedValue));
                        //Teacher teacher = new Teacher();
                        //DropDownList4.Items.Clear();
                        //DropDownList4.Items.Add("Select Teacher");
                        //DropDownList4.Items[0].Value = "0";
                        //DropDownList4.Items[0].Selected = false;
                        //int x = 0;
                        //foreach (TeacherSite tas in teachersatsite)
                        //{
                        //    x++;
                        //    teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                        //    DropDownList4.Items.Add(teacher.FirstName + " " + teacher.LastName);
                        //    DropDownList4.Items[x].Value = teacher.TeacherId.ToString();
                        //}
                        //Label41.Visible = true;
                        #endregion[oldecode]

                        DropDownList4.Items.Clear();
                        DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customer.CustomerId);
                        DropDownList4.DataSource = dsCoachName.Tables[0];
                        DropDownList4.DataTextField = "CoachName";
                        DropDownList4.DataValueField = "TeacherId";
                        DropDownList4.DataBind();
                        DropDownList4.SelectedIndex = 0;
                    }
                    else
                    {
                        #region[oldecode]
                        //if (!IsPostBack)
                        //{
                        //    TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList3.SelectedValue));
                        //    Teacher teacher = new Teacher();
                        //    DropDownList4.Items.Clear();
                        //    DropDownList4.Items.Add("Select Teacher");
                        //    DropDownList4.Items[0].Value = "0";
                        //    DropDownList4.Items[0].Selected = false;
                        //    int x = 0;
                        //    foreach (TeacherSite tas in teachersatsite)
                        //    {
                        //        x++;
                        //        teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                        //        DropDownList4.Items.Add(teacher.FirstName + " " + teacher.LastName);
                        //        DropDownList4.Items[x].Value = teacher.TeacherId.ToString();
                        //    }
                        //    DropDownList4.SelectedValue = customerprofile.Teacher.ToString();
                        //    Label41.Visible = false;
                        //}
                        //else
                        //{
                        //    if (DropDownList4.SelectedValue.Equals("0"))
                        //        Label41.Visible = true;
                        //    else
                        //        Label41.Visible = false;
                        //}
                        #endregion[oldecode]
                        if (!IsPostBack)
                        {
                            DropDownList4.Items.Clear();
                            DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customer.CustomerId);
                            DropDownList4.DataSource = dsCoachName.Tables[0];
                            DropDownList4.DataTextField = "CoachName";
                            DropDownList4.DataValueField = "TeacherId";
                            DropDownList4.DataBind();
                            DropDownList4.SelectedIndex = 0;
                        }
                        else
                        {
                            //if (DropDownList4.SelectedValue.Equals("0"))
                            //    Label41.Visible = true;
                            //else
                            //    Label41.Visible = false;
                        }
                    }
                }
                else
                {
                    Label17.Visible = true;
                    //Label38.Visible = true;
                    //if (DropDownList4.SelectedValue.Equals("0"))
                    //    Label41.Visible = true;
                    //else
                    //    Label41.Visible = false;
                }
            }
            else
            {
                //MessageBox.Show("You must be logged in to submit your information.");
            }
            base.OnPreRender(e);
        }
        catch (Exception ex)
        {
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {

            customer.FirstName = TextBox1.Text.Trim();
            customer.LastName = TextBox2.Text.Trim();
            customer.Country = Convert.ToInt16(DropDownList2.SelectedValue);
            customer.Address1 = TextBox5.Text.Trim();
            customer.Address2 = TextBox6.Text.Trim();
            customer.City = TextBox7.Text.Trim();
            customer.State = TextBox8.Text.Trim();
            if (DropDownList5.Visible)
                customer.State = DropDownList5.SelectedValue;
            else
                customer.State = TextBox8.Text.Trim();
            customer.Zip = TextBox9.Text.Trim();
            customer.ShippingFirstName = TextBox1.Text.Trim();
            customer.ShippingLastName = TextBox2.Text.Trim();
            customer.ShipCountry = Convert.ToInt16(DropDownList2.SelectedValue);
            customer.ShippingAddress1 = TextBox5.Text.Trim();
            customer.ShippingAddress2 = TextBox6.Text.Trim();
            customer.ShippingCity = TextBox7.Text.Trim();
            customer.ShippingState = TextBox8.Text.Trim();
            if (DropDownList5.Visible)
                customer.ShippingState = DropDownList5.SelectedValue;
            else
                customer.ShippingState = TextBox8.Text.Trim();
            customer.ShippingZip = TextBox9.Text.Trim();
            customer.ShippingRegion = customer.ShipCountry.ToString().Trim();
            customer.PhoneHome = TextBox10.Text.Trim();
            customer.PhoneMobile = TextBox11.Text.Trim();
            customer.PhoneWork = TextBox12.Text.Trim();
            customer.Fax = TextBox13.Text.Trim();

            if (customerexists)
            {
                customer.MembershipStatus = customer.MembershipStatus;
                customer.MembershipExpiration = customer.MembershipExpiration;
                customer.MembershipRenewal = customer.MembershipRenewal;
                customer.IsRenewal = customer.IsRenewal;
                customer.MembershipCost = customer.MembershipCost;
                customer.BillFacility = customer.BillFacility;
            }
            else
            {
                customer.MembershipStatus = 2;
                customer.MembershipExpiration = DateTime.Today.AddYears(1);
                customer.MembershipRenewal = DateTime.Today;
                customer.IsRenewal = 0;
                customer.MembershipCost = 100;
                customer.BillFacility = 0;
            }

            customerprofile.CustomerId = customer.CustomerId;
            customerprofile.Gender = DropDownList1.SelectedValue.ToString();
            if (DropDownList3.SelectedValue != "")
            {
                customerprofile.CustomerSite = Convert.ToInt16(DropDownList3.SelectedValue);
            }
            else
            {
                MessageBox.Show("please assign primary coach for athlet");
                return;
            }
            if (DropDownList4.SelectedValue != "")
            {
                customerprofile.Teacher = Convert.ToInt16(DropDownList4.SelectedValue);
            }
            else
            {
                MessageBox.Show("please assign primary coach for athlet");
                return;
            }

            if (customerexists)
              

                DataRepository.CustomerProvider.Update(customer);
            else
                DataRepository.CustomerProvider.Insert(customer);
            if (customerprofileexists)
                DataRepository.CustomerProfileProvider.Update(customerprofile);
            else
                DataRepository.CustomerProfileProvider.Insert(customerprofile);
        }
        else
        {
            //MessageBox.Show("You must be logged in to submit your information.");
        }

        Response.Redirect("~/Users/Default.aspx");
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        customer.Country = Convert.ToInt16(DropDownList2.SelectedValue);
        customer.State = "";
    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region[oldecode]
        //sitechanged = true;
        //TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList3.SelectedValue));
        //Teacher teacher = new Teacher();

        //DropDownList4.Items.Clear();
        //DropDownList4.Items.Add("Select Teacher");
        //DropDownList4.Items[0].Value = "0";
        //DropDownList4.Items[0].Selected = false;
        //int x = 0;
        //foreach (TeacherSite tas in teachersatsite)
        //{
        //    x++;
        //    teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
        //    DropDownList4.Items.Add(teacher.FirstName + " " + teacher.LastName);
        //    DropDownList4.Items[x].Value = teacher.TeacherId.ToString();
        //}
        //Label41.Visible = true;
        #endregion[oldecode]
    }



}
