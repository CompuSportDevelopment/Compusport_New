﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;
using System.Web.Profile;

//public partial class Admin_FindUsersByEmail : System.Web.UI.Page
public partial class Admin_FindUsersByEmail : SwingModel.UI.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MembershipUserCollection listUsers = new MembershipUserCollection();
        listUsers = Membership.FindUsersByEmail(TextBox3.Text);

        ListBox1.Items.Clear();
        foreach (MembershipUser user in listUsers)
        {
            Guid puk = new Guid(user.ProviderUserKey.ToString());
            Customer customer;
            customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(puk)[0];

            string strName;
            strName = customer.FirstName + " " + customer.LastName;

            ListBox1.Items.Add(strName);
        }
        if (listUsers.Count.Equals(0))
        {
            ListBox1.Items.Add("No Users Found");
        }
    }
}
