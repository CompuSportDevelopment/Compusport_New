﻿using System;
using System.Collections;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Net.Mail;

public partial class Admin_EmailTeachers : System.Web.UI.Page
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    public CustomerSite customersite;
    public TList<Teacher> teachers = new TList<Teacher>();
    public TList<TeacherSite> teachersatsite = new TList<TeacherSite>();
    public Teacher teacher;
    public Customer customer;
    public CustomerProfile customerprofile;

    protected void Page_Load(object sender, EventArgs e)
    {
        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            DropDownList1.Items.Add("All Facilities/All Teachers");
            DropDownList1.Items[1].Value = "0";
            int x = 1;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList1.Items.Add(cs.SiteName);
                DropDownList1.Items[x].Value = cs.CustomerSiteId.ToString();
            }
        }
    }
    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label5.Visible = false;
        int SelectedFacility = Convert.ToInt16(DropDownList1.SelectedValue);
        if (!SelectedFacility.Equals(-1))
        {
            if (!SelectedFacility.Equals(0))
            {
                teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(SelectedFacility);
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("Make a Selection");
                DropDownList2.Items[0].Value = "-1";
                DropDownList2.Items.Add("All Teachers");
                DropDownList2.Items[1].Value = "0";
                int x = 1;
                foreach (TeacherSite ts in teachersatsite)
                {
                    x++;
                    teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                    customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(teacher.AspnetMembershipUserId)[0];
                    //customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                    DropDownList2.Items.Add(teacher.FirstName + " " + teacher.LastName);
                    DropDownList2.Items[x].Value = customer.CustomerId.ToString();
                }
                DropDownList2.Visible = true;
            }
            else
            {
                DropDownList2.Visible = false;
            }
        }
        else
        {
            DropDownList2.Visible = false;
        }
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        //MessageBox.Show(FreeTextBox1.Text);
        Label5.Visible = false;
        int SelectedFacility = Convert.ToInt16(DropDownList1.SelectedValue);
        string EmailSentTo = "";

        if (SelectedFacility.Equals(-1))
        {
            //Do Nothing
        }
        else
        {
            if (SelectedFacility.Equals(0))
            {
                //teachersatsite = DataRepository.TeacherSiteProvider.GetAll();
                teachers = DataRepository.TeacherProvider.GetAll();
                foreach (Teacher t in teachers)
                {
                    teacher = DataRepository.TeacherProvider.GetByTeacherId(t.TeacherId);
                    customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(teacher.AspnetMembershipUserId)[0];
                    MembershipUser user = Membership.GetUser(customer.AspnetMembershipUserId);

                    if (teacher.IsApproved.Equals(1))
                    {
                        TeacherSite tas = new TeacherSite();
                        tas = DataRepository.TeacherSiteProvider.GetByTeacherId(teacher.TeacherId)[0];
                        CustomerSite cs = new CustomerSite();
                        cs = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(tas.SiteId);
                        if (cs.IsApproved.Equals(1))
                        {
                            EmailSentTo = EmailSentTo + user.Email + "<br>";

                            SendEmail(TextBox1.Text, user.Email, TextBox2.Text, FreeTextBox1.Text);
                        }
                    }
                }
                EmailSentTo = EmailSentTo + "<br><br>"
                    + FreeTextBox1.Text;
                SendEmail(TextBox1.Text, TextBox1.Text, TextBox2.Text, EmailSentTo);
                SendEmail(TextBox1.Text, "dev@swingmodel.com", TextBox2.Text, EmailSentTo);
            }
            else
            {
                int SelectedTeacher = Convert.ToInt16(DropDownList2.SelectedValue);

                if (SelectedTeacher.Equals(0))
                {
                    teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList1.SelectedValue));
                    foreach (TeacherSite ts in teachersatsite)
                    {
                        teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(teacher.AspnetMembershipUserId)[0];
                        MembershipUser user = Membership.GetUser(customer.AspnetMembershipUserId);
                        EmailSentTo = EmailSentTo + user.Email + "<br>";

                        SendEmail(TextBox1.Text, user.Email, TextBox2.Text, FreeTextBox1.Text);
                    }
                    EmailSentTo = EmailSentTo + "<br><br>"
                        + FreeTextBox1.Text;
                    SendEmail(TextBox1.Text, TextBox1.Text, TextBox2.Text, EmailSentTo);
                    SendEmail(TextBox1.Text, "dev@swingmodel.com", TextBox2.Text, EmailSentTo);
                }
                else
                {
                    customer = DataRepository.CustomerProvider.GetByCustomerId(SelectedTeacher);
                    MembershipUser user = Membership.GetUser(customer.AspnetMembershipUserId);
                    EmailSentTo = EmailSentTo + user.Email + "<br>";

                    SendEmail(TextBox1.Text, user.Email, TextBox2.Text, FreeTextBox1.Text);
                    EmailSentTo = EmailSentTo + "<br><br>"
                        + FreeTextBox1.Text;
                    SendEmail(TextBox1.Text, TextBox1.Text, TextBox2.Text, EmailSentTo);
                    SendEmail(TextBox1.Text, "dev@swingmodel.com", TextBox2.Text, EmailSentTo);
                }
            }
        }
    }

    protected void SendEmail(string From, string To, string Subject, string Body)
    {
        MailAddress from = new MailAddress(From);
        MailAddress to = new MailAddress(To);
        MailMessage message = new MailMessage(from, to);

        message.IsBodyHtml = true;
        message.Subject = Subject;
        Body = "<img src=\"http://www.swingmodel.com/Images/EmailHeader.jpg\"><br><br>" + Body;
        //MessageBox.Show(Body);
        message.Body = Body;

        Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        MailSettingsSectionGroup settings = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");
        SmtpClient client = new SmtpClient(settings.Smtp.Network.Host);
        try
        {
            client.Send(message);
            Label5.Text = "Your Email has been sent sucessfully - Thank You";
            Label5.Visible = true;
        }
        catch (Exception ex)
        {
            Label5.Text = "Send failure: " + ex.ToString();
            Label5.Visible = true;
        }
    }
}
