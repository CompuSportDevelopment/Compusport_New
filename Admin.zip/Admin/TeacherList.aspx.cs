﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Admin_TeacherList : System.Web.UI.Page
public partial class Admin_TeacherList : SwingModel.UI.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TList<Teacher> teachers = DataRepository.TeacherProvider.GetAll();
        TeacherSite tas;
        CustomerSite customersite;
        MembershipUser user;
        DataTable dt = new DataTable();
        dt.Columns.Add("Name", typeof(string));
        dt.Columns.Add("Email", typeof(string));
        dt.Columns.Add("Facility", typeof(string));

        teachers.Sort("LastName ASC");
        foreach (Teacher t in teachers)
        {
            try
            {
                //MessageBox.Show(t.FirstName + " " + t.LastName);
                tas = DataRepository.TeacherSiteProvider.GetByTeacherId(t.TeacherId)[0];
                customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(tas.SiteId);
                user = Membership.GetUser(t.AspnetMembershipUserId);

                dt.Rows.Add(t.FirstName + " " + t.LastName, user.Email, customersite.SiteName);
            }
            catch (Exception ex)
            { 
            }
        }

        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
}
