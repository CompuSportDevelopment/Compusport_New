﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using MemberDownload;
using SwingModel.Data;
using SwingModel.Entities;
using CompuSportDAL;

//public partial class Facility_AddTeachers : System.Web.UI.Page
public partial class Facility_AddTeachers : SwingModel.UI.BasePage
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    public GetMemberList gml = new GetMemberList();

    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    CountryLookup countrylookup = new CountryLookup();
    Teacher teacher = new Teacher();
    Customer teacherc = new Customer();
    Teacher teacher1 = new Teacher();
    CustomerProfile teachercp = new CustomerProfile();
    int SelectedFacility;
    DataTable dt = new DataTable();
    string[] roles = Roles.GetAllRoles();
    int x;
    TList<TeacherSite> facilityteachers = new TList<TeacherSite>();
    SprintAthleteEdit _sprintAthleteEdit = new SprintAthleteEdit();

    Customer AthleteSearched;
    protected void Page_Load(object sender, EventArgs e)
    {
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        SelectedFacility = customerprofile.CustomerSite;
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(SelectedFacility);
        //Label1.Text = customersite.SiteName;
        facilityteachers = DataRepository.TeacherSiteProvider.GetAll();// (SelectedFacility);
        //facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(SelectedFacility);
        dt.Columns.Add("TeacherId", typeof(int));
        dt.Columns.Add("First Name", typeof(string));
        dt.Columns.Add("Last Name", typeof(string));
        //dt.Columns.Add("Work Phone", typeof(string));teacher.WorkPhone
        dt.Columns.Add("Roles", typeof(string));
        dt.Columns.Add("Mobile Phone", typeof(string));
        dt.Columns.Add("Fax", typeof(string));
        dt.Columns.Add("AspNetMembershipUserId", typeof(string));
        dt.Columns.Add("Picture Path", typeof(string));
        dt.Columns.Add("Bio Text", typeof(string));
        dt.Columns.Add("Welcome Text", typeof(string));
        dt.Columns.Add("Teaching Password", typeof(string));
        dt.Columns.Add("TeacherLocationId", typeof(int));
        dt.Columns.Add("Facility", typeof(string));
        x = 0;
        foreach (TeacherSite ts in facilityteachers)
        {
            try
            {
                teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(ts.SiteId);
                Guid MemGuid = new Guid(teacher.AspnetMembershipUserId.ToString());
                MembershipUser user = Membership.GetUser(MemGuid);
                string[] userrole = Roles.GetRolesForUser(user.UserName);
                string userrolename = string.Empty;
                if (userrole.Length > 0)
                {
                    userrolename = userrole[0];
                }
                dt.Rows.Add(teacher.TeacherId, teacher.FirstName, teacher.LastName, userrolename, teacher.MobilePhone, teacher.Fax, teacher.AspnetMembershipUserId.ToString(), teacher.PicturePath, teacher.BioText, teacher.WelcomeText, teacher.TeachingPassword, ts.TeacherLocationId, customersite.SiteName);
                x++;
            }
            catch
            { }
        }
        dt.DefaultView.Sort = "Facility ASC";
        GridView1.DataSource = dt;
        GridView1.DataBind();
        if (!IsPostBack)
        {
            customersites = DataRepository.CustomerSiteProvider.GetAll();
            customersites.Sort("SiteName ASC");
            if (DropDownList1.Items.Count.Equals(0))
            {
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add("Make a Selection");
                DropDownList1.Items[0].Value = "-1";
                int y = 0;
                foreach (CustomerSite cs in customersites)
                {
                    y++;
                    DropDownList1.Items.Add(cs.SiteName);
                    DropDownList1.Items[y].Value = cs.CustomerSiteId.ToString();
                }
            }
            string[] roles = Roles.GetAllRoles();
            if (DropDownList2.Items.Count.Equals(0))
            {
                DropDownList2.Items.Clear();
                DropDownList2.DataSource = roles;
                DropDownList2.DataBind();
                DropDownList2.Items.Insert(0, new ListItem("Make a Selection", "0"));
            }
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int RowID = Convert.ToInt32(e.CommandArgument);
        TeacherSite tas = new TeacherSite();
        Customer cust_role = new Customer();
        CustomerProfile cpid;
        if (e.CommandName == "DeleteRow")
        {
            tas.TeacherLocationId = Convert.ToInt32(RowID);
            tas = DataRepository.TeacherSiteProvider.GetByTeacherLocationId(RowID);
            teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
            DataRepository.TeacherSiteProvider.Delete(tas.TeacherLocationId);
            this.Page.Response.Redirect("~/Admin/AddTeachers.aspx");
        }
        if (e.CommandName == "EditRow")
        {
            this.Page.Response.Redirect("~/Admin/EditTeacher.aspx?TeacherId=" + RowID.ToString() + "");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = -9999;

        ListBox1.Items.Clear();

        if (TextBox1.Text.Equals(null) || TextBox1.Text.Equals("") || TextBox2.Text.Equals(null) || TextBox2.Text.Equals(""))
        {
            ListBox1.Items.Add("No Matches");
        }
        else
        {
            //i = gml.GetMembers(TextBox1.Text, TextBox2.Text, TextBox3.Text);

            #region[old code for seraching which getting all the athlets]
            //i = gml.GetMembers(TextBox1.Text, TextBox2.Text, "");

            //if (gml.GuidMatch.Count.Equals(0))
            //{
            //    //MessageBox.Show("No Matches");
            //    ListBox1.Items.Add("No Matches");
            //}
            //else
            //{
            //    int x = 0;
            //    string ListBoxItem = "";
            //    foreach (string MemberGuid in gml.GuidMatch)
            //    {
            //        ListBoxItem = gml.FirstNameMatch[x].ToString() + " " + gml.LastNameMatch[x].ToString() + ", " + gml.EmailMatch[x].ToString() + ", " + gml.UsernameMatch[x].ToString();

            //        ListBox1.Items.Add(ListBoxItem);
            //        ListBox1.Items[x].Value = gml.CustomerIdMatch[x].ToString() + "," + gml.UsernameMatch[x].ToString() + "|" + gml.EmailMatch[x].ToString();
            //        x++;
            //    }
            //}
            #endregion[old code for seraching which getting all the athlets]

            #region[new code for seraching which getting all the athlets]
            //if (Page.User.Identity.IsAuthenticated)
            //{
            //    teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
            //    DataSet dscustomer = _sprintAthleteEdit.Get_AthleteMembers(TextBox1.Text, TextBox2.Text);
            //    if (dscustomer != null)
            //    {
            //        if (dscustomer.Tables[0].Rows.Count > 0)
            //        {
            //            int x = 0;
            //            string ListBoxItem = "";
            //            for (int record = 0; record < dscustomer.Tables[0].Rows.Count; record++)
            //            {
            //                ListBoxItem = dscustomer.Tables[0].Rows[record]["FirstName"].ToString() + " " + dscustomer.Tables[0].Rows[record]["LastName"].ToString() + ", " + dscustomer.Tables[0].Rows[record]["Email"].ToString();

            //                ListBox1.Items.Add(ListBoxItem);
            //                ListBox1.Items[x].Value = dscustomer.Tables[0].Rows[record]["CustomerID"].ToString();
            //                x++;
            //            }
            //        }
            //        else
            //        {
            //            ListBox1.Items.Add("No Matches");
            //        }
            //    }
            //    else
            //    {
            //        ListBox1.Items.Add("No Matches");
            //    }
            //}
            #endregion[new code for seraching which getting all the athlets]

            #region[new code for seraching which getting all the athlet]
            if (Page.User.Identity.IsAuthenticated)
            {
                DataTable dt = new DataTable();
                teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                DataTable dscustomer = _sprintAthleteEdit.Get_AthleteMembers(TextBox1.Text, TextBox2.Text);

                //DataTable dstecher = _sprintAthleteEdit.GetMembers(TextBox1.Text, TextBox2.Text, teacher.TeacherId);
                if (dscustomer != null)
                {
                    int x = 0;
                    string ListBoxItem = "";
                    foreach (DataRow row in dscustomer.Rows)
                    {
                        DataRow r = dt.NewRow();
                        string userrolename = string.Empty;
                        int customerid = Convert.ToInt32(row["CustomerId"]);
                        AthleteSearched = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                        Guid MemGuid = new Guid(AthleteSearched.AspnetMembershipUserId.ToString());
                        MembershipUser user = Membership.GetUser(MemGuid);
                        string[] userrole = Roles.GetRolesForUser(user.UserName);
                        if (userrole.Length > 0)
                        {
                            userrolename = userrole[0];
                        }
                        ListBoxItem = row["FirstName"].ToString() + " " + row["LastName"].ToString() + ", " + row["Email"].ToString();
                        ListBox1.Items.Add(ListBoxItem);
                        ListBox1.Items[x].Value = row["CustomerID"].ToString();
                        x++;
                    }
                    if (ListBox1.Items.Count == 0)
                    {
                        ListBox1.Items.Add("No Matches");
                    }

                }
                else
                {
                    ListBox1.Items.Add("No Matches");
                }
            }
            #endregion[new code for seraching which getting all the athlet of particular teacher]

        }
    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TeacherSite teachersite = new TeacherSite();

        if (!ListBox1.SelectedValue.Equals("No Matches"))
        {
            #region[old code]
            //int x = ListBox1.SelectedIndex;
            //int comma = ListBox1.Items[x].Value.IndexOf(",");
            //int bar = ListBox1.Items[x].Value.IndexOf("|");
            //int customerid = Convert.ToInt16(ListBox1.Items[x].Value.Substring(0, comma));
            //string MemberUsername = ListBox1.Items[x].Value.Substring(comma + 1, bar - comma - 1);
            //string MemberEmail = ListBox1.Items[x].Value.Substring(bar + 1);

            //customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            //customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            //countrylookup = DataRepository.CountryLookupProvider.GetByCountryId(customer.Country);


            ////int SelectedFacilitynew = customerprofile.CustomerSite;
            ////customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(SelectedFacility);
            //teacher = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
            //teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teacher.TeacherId)[0];

            //customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(teachersite.SiteId);

            //Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
            //MembershipUser user = Membership.GetUser(MemGuid);
            //string[] userrole = Roles.GetRolesForUser(user.UserName.ToString());

            ////DropDownList1.SelectedValue = SelectedFacilitynew.ToString();
            //if (userrole.Length > 0)
            //{
            //    DropDownList2.SelectedValue = userrole[0];
            //}
            //else
            //{
            //    DropDownList2.SelectedValue = "Golfers";

            //}
            #endregion[old code]

            int x = ListBox1.SelectedIndex;
            int customerid = Convert.ToInt16(ListBox1.Items[x].Value);
            customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
            MembershipUser user1 = Membership.GetUser(MemGuid);
            string MemberUsername = user1.UserName.ToString();
            string MemberEmail = user1.Email;
            countrylookup = DataRepository.CountryLookupProvider.GetByCountryId(customer.Country);
            try
            {
                customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
                teacher1 = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
            }
            catch (Exception ex)
            {
                customerprofile = new CustomerProfile();
            }
            Label45.Text = customer.FirstName;
            Label7.Text = customer.LastName;
            Label9.Text = MemberUsername;
            Label11.Text = MemberEmail;
            if (!customer.Address1.ToLower().Equals("none"))
                Label13.Text = customer.Address1;
            else
                Label13.Text = "";
            Label15.Text = customer.Address2;
            if (!customer.City.ToLower().Equals("none"))
                Label17.Text = customer.City;
            else
                Label17.Text = "";
            if (!customer.State.ToLower().Equals("none"))
                Label19.Text = customer.State;
            else
                Label19.Text = "";
            if (!customer.Zip.ToLower().Equals("none"))
                Label21.Text = customer.Zip;
            else
                Label21.Text = "";
            if (customer.Address1.ToLower().Equals("none") && customer.Country.Equals(248))
                Label23.Text = "";
            else
            Label23.Text = countrylookup.CountryName;
            Label25.Text = customer.PhoneHome;
            Label27.Text = customer.PhoneWork;
            Label29.Text = customer.PhoneMobile;
            Label31.Text = customer.Fax;
            Label33.Text = customersite.SiteName;
            Label35.Text = teacher1.FirstName + " " + teacher1.LastName;
            Label37.Text = user1.CreationDate.ToLongDateString();
            Label39.Text = customer.MembershipExpiration.ToLongDateString();
            switch (customer.MembershipStatus)
            {
                case 0:
                    Label41.Text = "Expired";
                    break;

                case 1:
                    Label41.Text = "Member";
                    break;

                case 2:
                    Label41.Text = "Full Teaching";
                    break;

                case 3:
                    Label41.Text = "Full Fitting";
                    break;

                case 4:
                    Label41.Text = "Full Teaching & Fitting";
                    break;

                case 97:
                    Label41.Text = "Comp Teaching";
                    break;

                case 98:
                    Label41.Text = "Comp Fitting";
                    break;

                case 99:
                    Label41.Text = "Comp Teaching & Fitting";
                    break;

                default:
                    Label41.Text = "Missing";
                    break;
            }

        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        bool teacherexists = false;

        if (!ListBox1.SelectedValue.Equals("No Matches") && !ListBox1.Items.Count.Equals(0))
        {
            Customer tc = new Customer();
            Teacher teach = new Teacher();
            TeacherSite teachersite = new TeacherSite();
            int customerid1 = -1;
            bool CurrentTeacher = false;
            int SelectedFacilityNew = Convert.ToInt16(DropDownList1.SelectedValue);
            string selectedrole = Convert.ToString(DropDownList2.SelectedValue);

            if (!ListBox1.SelectedValue.Equals("No Matches") && !ListBox1.Items.Count.Equals(0))
            {   
                int x = ListBox1.SelectedIndex;
                int comma = ListBox1.Items[x].Value.IndexOf(",");
                // customerid = Convert.ToInt16(ListBox1.Items[x].Value.Substring(0, comma));
                customerid1 = Convert.ToInt16(ListBox1.Items[x].Value);
            }
            //MessageBox.Show("customerid: " + customerid.ToString());
            if(!customerid1.Equals(-1))
            {   
                tc = DataRepository.CustomerProvider.GetByCustomerId(customerid1);
                
                try
                {
                    //teach = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(tc.AspnetMembershipUserId)[0]; 
                    var data = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(tc.AspnetMembershipUserId); //New Code 3-12-19
                    if (data.Count > 0)
                    {
                        teach = data[0];
                    }
                    //MessageBox.Show("Teacher First Name: " + teach.FirstName);
                    CurrentTeacher = true;
                }
                catch (Exception ex)
                {
                    //Selected member is not a current Teacher in database
                    //MessageBox.Show("Not a current teacher");
                    CurrentTeacher = false;
                }
                //teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teach.TeacherId);



                if (!CurrentTeacher)  //New Code 3-12-19
                {
                    Guid MemGuid = new Guid(teach.AspnetMembershipUserId.ToString());
                    MembershipUser user = Membership.GetUser(MemGuid);
                    teachersite.SiteId = SelectedFacilityNew;
                    teachersite.TeacherId = teach.TeacherId;
                    foreach (TeacherSite ts in facilityteachers)
                    {
                        if (ts.TeacherId == teach.TeacherId && ts.SiteId == teachersite.SiteId)
                        {
                            teacherexists = true;

                        }
                    }
                    if (!teacherexists)   //New Code 3-12-19
                    {
                        // DataRepository.TeacherSiteProvider.Insert(teachersite);       commented on feb12
                        #region[inserting data into teachersite]
                        teachersite.SiteId = 12;
                        teachersite.TeacherId = teach.TeacherId;
                        DataRepository.TeacherSiteProvider.Insert(teachersite);
                        #endregion[inserting data into teachersite]

                        string[] AllRoles = Roles.GetRolesForUser(user.UserName);
                            Roles.RemoveUserFromRoles(user.UserName, AllRoles);
                            Roles.AddUserToRole(user.UserName, selectedrole);
                    }
                    else
                    {
                        //Label1.Text = "This teacher is already exists for this facility";
                    }
                    //Response.Write("The Teacher is already in exist");
                }
                else
                {
                    teach.FirstName = tc.FirstName;
                    teach.LastName = tc.LastName;
                    teach.WorkPhone = tc.PhoneWork;
                    teach.MobilePhone = tc.PhoneMobile;
                    teach.AspnetMembershipUserId = tc.AspnetMembershipUserId;
                    teach.PicturePath = "/TeacherPics/" + tc.FirstName + tc.LastName + ".jpg";
                    teach.BioText = "Bio Text";
                    teach.WelcomeText = "<P>Welcome to the SwingModel learning program. If you haven't "
                        + "taken a look at your most recent lesson video(s), please visit the My Swing "
                        + "page. There you will be able to review the errors we discussed during the "
                        + "lesson. For further review, you may click on the My Summary button in the "
                        + "video player. Continue working the drills as discussed in the lesson. If "
                        + "you'd like to ask questions about your swing or golf game, click on the Email "
                        + "My Teacher link. Be sure to schedule a lesson with me in the near future. You "
                        + "can request a lesson appointment time by clicking on the Schedule A Lesson "
                        + "link.</P>";
                    teach.TeachingPassword = tc.FirstName;
                    DataRepository.TeacherProvider.Insert(teach);


                    //if (DropDownList1.SelectedValue!= "-1")
                    //{
                    //    teachersite.SiteId = SelectedFacilityNew;
                    //    teachersite.TeacherId = teach.TeacherId;
                    //    DataRepository.TeacherSiteProvider.Insert(teachersite);
                    //}
                    //else
                    //{
                    //}
                    teachersite.SiteId = 12;
                    teachersite.TeacherId = teach.TeacherId;
                    DataRepository.TeacherSiteProvider.Insert(teachersite);

                    Guid MemGuid = new Guid(teach.AspnetMembershipUserId.ToString());
                    MembershipUser user = Membership.GetUser(MemGuid);
                    string[] AllRoles = Roles.GetRolesForUser(user.UserName);

                    Roles.RemoveUserFromRoles(user.UserName, AllRoles);
                    Roles.AddUserToRole(user.UserName, selectedrole);

                }
            }

            this.Page.Response.Redirect("~/Admin/AddTeachers.aspx");
        }
        else
        {
            Label5.Text = "Please select Teacher to Add";
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selectedrole = DropDownList2.SelectedValue.ToString();
        //string selectedrole1 = Convert.ToString(selectedrole);

    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
            lnkDelete.OnClientClick = "javascript:return confirm('Do you want to delete details of this teacher " + "?');";
            //lnkDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this teacher');");
        }
    }
}
 