﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Admin_CurrentVersion : System.Web.UI.Page
public partial class Admin_CurrentVersion : SwingModel.UI.BasePage
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    DataTable dt = new DataTable();
    int x;

    protected void Page_Load(object sender, EventArgs e)
    {
        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        dt.Columns.Add("FacilityId", typeof(int));
        dt.Columns.Add("Facility", typeof(string));
        dt.Columns.Add("Current Version", typeof(string));
        x = 0;
        foreach (CustomerSite cs in customersites)
        {
            dt.Rows.Add(cs.CustomerSiteId, cs.SiteName, DateTime.Parse(cs.TeachVersion.ToString()).ToShortDateString());
            x++;
        }
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int RowID = Convert.ToInt32(e.CommandArgument);

        if (e.CommandName == "EditRow")
        {
            this.Page.Response.Redirect("~/Admin/EditCurrentVersion.aspx?FacilityId=" + dt.Rows[RowID].Field<int>("FacilityId").ToString());
        }
    }
}
