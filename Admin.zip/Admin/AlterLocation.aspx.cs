﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Drawing;
using System.Data.SqlClient;

public partial class Admin_AlterLocation : System.Web.UI.Page
{
    TList<RegionLookup> regions = new TList<RegionLookup>();
    TList<CustomerSite> customersites = new TList<CustomerSite>();
    StateProvince sp = new StateProvince();
    Teacher teacher = new Teacher();
    TList<TeacherSite> facilityteachers = new TList<TeacherSite>();
    string stateID;
    string stateAbb;

    string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString.ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            rdbGlobalLocations.Visible = false;
            ddlSubLocations.Visible = false;
            grdLocation.Visible = false;
            lblGlobalLocations.Visible = false;
            btnAddNewLocation.Visible = false;
        }
    }

    protected void rdbSports_SelectedIndexChanged(object sender, EventArgs e)
    {
        //lblGlobalLocations.Visible = true;
        //rdbGlobalLocations.Visible = true;
        lblGlobalLocations.Visible = true;
        rdbGlobalLocations.Visible = true;
       // rdbGlobalLocations_SelectedIndexChanged(null, null);
    }
    protected void rdbGlobalLocations_SelectedIndexChanged(object sender, EventArgs e)
    {
        TList<RegionLookup> regions = DataRepository.RegionLookupProvider.GetAll();
        ddlSubLocations.Visible = true;

        ddlSubLocations.Items.Clear();
        ddlSubLocations.Items.Add("---Select Locations---");
        ddlSubLocations.Items[0].Value = "0";
        int count = 0;
        if (rdbGlobalLocations.SelectedValue == "US")
        {
            foreach (RegionLookup regn in regions)
            {
                if (regn.Us == 1)
                {
                    count++;
                    ddlSubLocations.Items.Add(regn.RegionName);
                    ddlSubLocations.Items[count].Value = regn.RegionId.ToString();
                }
            }
        }
        else
        {
            foreach (RegionLookup regn in regions)
            {
                if (regn.Us == 0)
                {
                    count++;
                    ddlSubLocations.Items.Add(regn.RegionName);
                    ddlSubLocations.Items[count].Value = regn.RegionId.ToString();
                }
            }
        }
        grdLocation.Visible = false;
    }
    protected void ddlSubLocations_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnAddNewLocation.Visible = true;
        string i = ddlSubLocations.SelectedValue;
        DataTable dt = new DataTable();
        dt.Columns.Add("SiteName", typeof(string));
        dt.Columns.Add("Address", typeof(string));
        //dt.Columns.Add("City", typeof(string));
        //dt.Columns.Add("StateProvince",typeof(Int32));
        //dt.Columns.Add("ZipCode", typeof(Int32));
        dt.Columns.Add("Website", typeof(string));
        //dt.Columns.Add("CoachName", typeof(string));
        dt.Columns.Add("CustomerSiteId", typeof(Int32));
        //dt.Columns.Add("CoachId", typeof(Int32));
        //dt.Columns.Add("Region", typeof(Int32));
        //dt.Columns.Add("Country", typeof(Int32));

        int count = 0;
        count++;
        customersites = DataRepository.CustomerSiteProvider.GetByRegion(Convert.ToInt16(i));
        customersites.Sort("SiteName");
        foreach (CustomerSite cs in customersites)
        {
            #region[Track and Field]
            if (rdbSports.SelectedValue == "Track")
            {
                if (rdbGlobalLocations.SelectedValue == "US")
                {
                    if (cs.CustomerSiteId != 15)
                    {
                        if (cs.IsApproved.Equals(1) && !cs.CustomerSiteId.Equals(9))
                        {
                            facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(cs.CustomerSiteId);
                            try
                            {
                                if ((cs.StateProvince.ToString() != null) && (cs.StateProvince.ToString() != string.Empty))
                                {
                                    sp = DataRepository.StateProvinceProvider.GetByStateProvinceId(Convert.ToInt16(cs.StateProvince));
                                    if (sp == null)
                                    {
                                        sp = new StateProvince();
                                        sp.StateProvinceAbbvr = " ";
                                    }
                                }
                                dt.Rows.Add(cs.SiteName, cs.Address1 + "," + cs.Address2 + "," + cs.City + "," + sp.StateProvinceAbbvr + "," + cs.ZipCode,
                                            cs.Website, cs.CustomerSiteId);
                            }
                            catch (Exception ex)
                            {
                                ex.Message.ToString();
                            }
                        }
                    }
                }
                else
                {
                    if (cs.IsApproved.Equals(1) && !cs.CustomerSiteId.Equals(9))
                    {
                        facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(cs.CustomerSiteId);
                        try
                        {
                            if ((cs.StateProvince.ToString() != null) && (cs.StateProvince.ToString() != string.Empty))
                            {
                                sp = DataRepository.StateProvinceProvider.GetByStateProvinceId(Convert.ToInt16(cs.StateProvince));
                                if (sp == null)
                                {
                                    sp = new StateProvince();
                                    sp.StateProvinceAbbvr = " ";
                                }
                            }
                            dt.Rows.Add(cs.SiteName, cs.Address1 + "," + cs.Address2 + "," + cs.City + "," + sp.StateProvinceAbbvr + "," + cs.ZipCode,
                                        cs.Website, cs.CustomerSiteId);
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                    }
                }

            }
            #endregion[Track and Field]

            #region[Football]
            else if (rdbSports.SelectedValue == "Football")
            {
                if (rdbGlobalLocations.SelectedValue == "US")
                {
                    if (cs.IsApproved.Equals(1) && cs.CustomerSiteId.Equals(23))
                    {
                        facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(cs.CustomerSiteId);
                        try
                        {
                            if ((cs.StateProvince.ToString() != null) && (cs.StateProvince.ToString() != string.Empty))
                            {
                                sp = DataRepository.StateProvinceProvider.GetByStateProvinceId(Convert.ToInt16(cs.StateProvince));
                                if (sp == null)
                                {
                                    sp = new StateProvince();
                                    sp.StateProvinceAbbvr = " ";
                                }
                            }
                            dt.Rows.Add(cs.SiteName, cs.Address1 + "," + cs.Address2 + "," + cs.City + "," + sp.StateProvinceAbbvr + "," + cs.ZipCode,
                                        cs.Website, cs.CustomerSiteId);
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                    }
                }
                else
                {
                    if (cs.IsApproved.Equals(1) && cs.CustomerSiteId.Equals(23))
                    {
                        facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(cs.CustomerSiteId);
                        try
                        {
                            if ((cs.StateProvince.ToString() != null) && (cs.StateProvince.ToString() != string.Empty))
                            {
                                sp = DataRepository.StateProvinceProvider.GetByStateProvinceId(Convert.ToInt16(cs.StateProvince));
                                if (sp == null)
                                {
                                    sp = new StateProvince();
                                    sp.StateProvinceAbbvr = " ";
                                }
                            }
                            dt.Rows.Add(cs.SiteName, cs.Address1 + "," + cs.Address2 + "," + cs.City + "," + sp.StateProvinceAbbvr + "," + cs.ZipCode,
                                        cs.Website, cs.CustomerSiteId);
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                    }
                }
            #endregion[Football]
            }
            grdLocation.DataSource = dt;
            grdLocation.DataBind();
            pnlAdd.Visible = false;
            grdLocation.Visible = true;
        }
        if (customersites.Count == 0)
        {
            grdLocation.Visible = false;
        }

    }
    private bool CheckValidation()
    {
        bool returnValue = true;
        if ((txtEditAddress1.Text.ToString() == string.Empty) || (txtEditAddress1.Text.Equals(null)))
        {
            Labeladd.Visible = true;
            returnValue = false;
            //return false;

        }
        else
        {
            Labeladd.Visible = false;
        }
        if ((txtEditCity.Text.ToString() == string.Empty) || (txtEditCity.Text.Equals(null)))
        {
            Labelcity.Visible = true;
            returnValue = false;
           // return false;

        }
        else
        {
            Labelcity.Visible = false;
        }
        if (rdbGlobalLocations.SelectedValue.Equals("US"))
        {
            if (ddlEditState.SelectedIndex.Equals(0))
            {
                Labelstate.Visible = true;
                returnValue = false;
                //return false;
            }
            else
            {
                Labelstate.Visible = false;
            }
        }
        else
        {
            if (ddlSubLocations.SelectedValue.Equals("7"))
            {
                if (ddlEditState.SelectedIndex.Equals(0))
                {
                    Labelstate.Visible = true;
                    returnValue = false;
                    //return false;
                }

                else
                {
                    Labelstate.Visible = false;
                }
            }
            else
            {
                if (ddlEditState.SelectedIndex.Equals(0))
                {
                    Labelstate.Visible = true;
                    returnValue = false;
                    //return false;
                }

                else
                {
                    Labelstate.Visible = false;
                }
            }
        }
        if ((txtEditZipCode.Text.ToString() == string.Empty) || (txtEditZipCode.Text.Equals(null)))
        {
            Labelzip.Visible = true;
            returnValue = false;
            //return false;

        }
        else
        {
            Labelzip.Visible = false;
        }
        if (returnValue == true)
        {
            Labeladd.Visible = false;
            Labelzip.Visible = false;
            Labelstate.Visible = false;
            Labelcity.Visible = false;
        }
        return returnValue;
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (CheckValidation())
        {
            try
            {
                TList<StateProvince> spState = new TList<StateProvince>();
                grdLocation.Visible = false;
                CustomerSite CustSite;
                int custSiteId = Convert.ToInt32(Session["CustomerSiteId"]);
                CustSite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(custSiteId);

                if (rdbGlobalLocations.SelectedValue == "US")
                {
                    stateID = Convert.ToString(ddlEditState.SelectedValue);
                    CustSite.StateProvince = stateID;
                }
                else
                {

                    if (ddlSubLocations.SelectedValue.Equals("7"))
                    {
                        Label6.Visible = true;
                        LabelEditCountry.Visible = false;
                        stateID = Convert.ToString(ddlEditState.SelectedValue);
                        CustSite.StateProvince = stateID;
                    }
                    else
                    {
                        Label6.Visible = false;
                        LabelEditCountry.Visible = true;
                        string countryID = Convert.ToString(ddlEditState.SelectedValue);
                        CustSite.Country = int.Parse(countryID);
                    }
                }

                CustSite.SiteName = txtEditLocation.Text;
                CustSite.Address1 = txtEditAddress1.Text;
                CustSite.Address2 = txtEditAddress2.Text;
                CustSite.City = txtEditCity.Text;
                string Site = (txtEditWebsite.Text.Equals("")) ? "-1" : txtEditWebsite.Text;
                CustSite.Website = Site;
                if (stateID == null)
                {
                    CustSite.StateProvince = "";
                    
                }
                else
                {
                    CustSite.StateProvince = stateID;
                }
                CustSite.ZipCode = txtEditZipCode.Text;
                DataRepository.CustomerSiteProvider.Update(CustSite);
                pnlEdit.Visible = false;
                btnAddNewLocation.Visible = true;
                rdbGlobalLocations.Enabled = true;
                rdbSports.Enabled = true;
                ddlSubLocations.Enabled = true;
                ddlSubLocations_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please enter all values marked as Required');", true);


        }
    }


    protected void grdLocation_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string[] arg = new string[2];
        arg = e.CommandArgument.ToString().Split(';');
        Session["CustomerSiteId"] = arg[0];
        //  Session["CoachId"] = arg[1];
        Teacher teachName;
        int custSiteId = Convert.ToInt32(Session["CustomerSiteId"]);
        // int coachId = Convert.ToInt32(Session["CoachId"]);

        if (e.CommandName == "DeleteRow")
        {
            try
            {
                TList<TeacherSite> teachersSite = new TList<TeacherSite>();
                TList<Lesson> lesson = new TList<Lesson>();
                TeacherSite teachSite = new TeacherSite();
                Lesson lessonUpdate = new Lesson();
                teachersSite = DataRepository.TeacherSiteProvider.GetBySiteId(custSiteId);
                foreach (TeacherSite ts in teachersSite)
                {
                    teachSite.SiteId = 12;
                    teachSite.TeacherLocationId = ts.TeacherLocationId;
                    teachSite.TeacherId = ts.TeacherId;
                    DataRepository.TeacherSiteProvider.Update(teachSite);
                }
                lesson = DataRepository.LessonProvider.GetBySiteId(custSiteId);
                foreach (Lesson l in lesson)
                {
                    lessonUpdate.SiteId = 12;
                    lessonUpdate.TeacherId = l.TeacherId;
                    lessonUpdate.LessonId = l.LessonId;
                    lessonUpdate.LessonDate = l.LessonDate;
                    lessonUpdate.CustomerId = l.CustomerId;
                    lessonUpdate.LessonTypeId = l.LessonTypeId;
                    lessonUpdate.MachineNumber = l.MachineNumber;
                    DataRepository.LessonProvider.Update(lessonUpdate);
                }
                DataRepository.CustomerSiteProvider.Delete(custSiteId);
                ddlSubLocations_SelectedIndexChanged(null, null);

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        if (e.CommandName == "EditRow")
        {
            try
            {
                CustomerSite CustSite;
                pnlEdit.Visible = true;
                grdLocation.Visible = false;
                btnAddNewLocation.Visible = false;
                CustSite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(custSiteId);
                if ((CustSite.StateProvince.ToString() != null) && (CustSite.StateProvince.ToString() != string.Empty))
                {
                    String StateID = CustSite.StateProvince;
                    sp = DataRepository.StateProvinceProvider.GetByStateProvinceId(Convert.ToInt16(StateID));
                }
                txtEditLocation.Text = CustSite.SiteName;
                txtEditAddress1.Text = CustSite.Address1;
                txtEditAddress2.Text = CustSite.Address2;
                txtEditCity.Text = CustSite.City;
                string Site = (CustSite.Website == "-1") ? " " : CustSite.Website;
                txtEditWebsite.Text = Site;
                txtEditZipCode.Text = CustSite.ZipCode;
                if (rdbGlobalLocations.SelectedValue == "US")
                {
                    ddlEditState.Visible = true;
                    Label36.Visible = true;
                    LabelEditCountry.Visible = false;
                    Label6.Visible = true;
                    if (sp != null)
                    {
                        SelectedState(sp.StateProvinceName);

                    }
                    else
                    {
                        string SelectSate = "---Select State---";
                        SelectedState(SelectSate);
                    }
                    //SelectedState(sp.StateProvinceName);
                    txtEditState.Visible = false;
                }
                else
                {
                    if (ddlSubLocations.SelectedValue.Equals("7"))
                    {
                        Label36.Visible = true;
                        Label6.Visible = true;
                        LabelEditCountry.Visible = false;
                        ddlEditState.Visible = true;
                        BindCanadaState(sp.StateProvinceName);
                        txtEditState.Visible = false;
                    }
                    else
                    {
                        txtEditState.Visible = false;
                        Label6.Visible = false;
                        LabelEditCountry.Visible = true;
                        TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
                        countries.RemoveAt(0);
                        countries.RemoveAt(38);
                        ddlEditState.Items.Clear();
                        ddlEditState.Items.Add("Select Country");
                        ddlEditState.Items[0].Value = "0";
                        ddlEditState.Items[0].Selected = false;
                        int x = 0;
                        foreach (CountryLookup country in countries)
                        {
                            x++;
                            ddlEditState.Items.Add(country.CountryName);
                            ddlEditState.Items[x].Value = country.CountryId.ToString();
                            if (country.CountryId.ToString().Equals(CustSite.Country.ToString()))
                            {
                                ddlEditState.Items[x].Selected = true;
                            }
                        }
                        //ddlEditState.Items.RemoveAt(40);
                        //ddlEditState.Items.RemoveAt(1);
                    }
                }
                rdbGlobalLocations.Enabled = false;
                rdbSports.Enabled = false;
                ddlSubLocations.Enabled = false;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }
    }
    private void BindCanadaState(string selectedState)
    {
        //TList<StateProvince> states = DataRepository.StateProvinceProvider.GetAll();
        TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(41);
        ddlEditState.Items.Clear();
        ddlEditState.Items.Add("---Select State---");
        ddlEditState.Items[0].Value = "0";
        ddlEditState.Items[0].Selected = false;
        int countState = 0;
        foreach (StateProvince SP in states)
        {
            countState++;
            ddlEditState.Items.Add(SP.StateProvinceName);
            ddlEditState.Items[countState].Value = Convert.ToString(SP.StateProvinceId);
            if (SP.StateProvinceName.Equals(selectedState))
            {
                ddlEditState.Items[countState].Selected = true;
            }
        }
    }

    private void SelectedState(string selectedState)
    {
        if (selectedState.Equals("---Select State---"))
        {
            string c = selectedState;
            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(1);
           // TList<StateProvince> states = DataRepository.StateProvinceProvider.GetAll();
            ddlEditState.Items.Add("---Select State---");
            ddlEditState.Items[0].Value = "0";
            ddlEditState.Items[0].Selected = true;
            int countState = 0;
            foreach (StateProvince SP in states)
            {
                countState++;
                ddlEditState.Items.Add(SP.StateProvinceName);
                ddlEditState.Items[countState].Value = Convert.ToString(SP.StateProvinceId);

            }
        }
        else
        {
            //TList<StateProvince> states = DataRepository.StateProvinceProvider.GetAll();
            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(1);
            ddlEditState.Items.Clear();
            ddlEditState.Items.Add("---Select State---");
            ddlEditState.Items[0].Value = "0";
            ddlEditState.Items[0].Selected = false;
            int countState = 0;
            foreach (StateProvince SP in states)
            {
                countState++;
                ddlEditState.Items.Add(SP.StateProvinceName);
                ddlEditState.Items[countState].Value = Convert.ToString(SP.StateProvinceId);
                if (SP.StateProvinceName.Equals(selectedState))
                {
                    ddlEditState.Items[countState].Selected = true;
                }
            }
        }
    }
    private void ClearAllAddFeilds()
    {
        txtAddSiteName.Text = "";
        txtAddAddress1.Text = "";
        txtAddAddress2.Text = "";
        txtAddCity.Text = "";
        txtAddState.Text = "";
        txtAddZipCode.Text = "";
        txtAddWebSite.Text = "";
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");
            lnkDelete.OnClientClick = "javascript:return confirm('Do you want to delete this Location " + "?');";
            //lnkDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this teacher');");
        }
    }
    private bool CheckAddValidation()
    {
        bool returnValue = true;
        if ((txtAddSiteName.Text.ToString() == string.Empty) || (txtAddSiteName.Text.Equals(null)))
        {
            Labeladdsite.Visible = true;
            returnValue = false;

        }
        else
        {
            Labeladdsite.Visible = false;
        }

        if ((txtAddAddress1.Text.ToString() == string.Empty) || (txtAddAddress1.Text.Equals(null)))
        {
            Labeladdaddress.Visible = true;
            returnValue = false;
        }
        else
        {
            Labeladdaddress.Visible = false;
        }
        if ((txtAddCity.Text.ToString() == string.Empty) || (txtAddCity.Text.Equals(null)))
        {
            Labeladdcity.Visible = true;
            returnValue = false;
        }
        else
        {
            Labeladdcity.Visible = false;
        }
        if (rdbGlobalLocations.SelectedValue.Equals("US"))
        {
            if (ddlAddState.SelectedIndex.Equals(0))
            {
                Labeladdstate.Visible = true;
                returnValue = false;
            }
            else
            {
                Labeladdstate.Visible = false;
            }
        }
        else
        {
            if (ddlSubLocations.SelectedValue.Equals("7"))
            {
                if (ddlAddState.SelectedIndex.Equals(0))
                {
                    Labeladdstate.Visible = true;
                    returnValue = false;
                }

                else
                {
                    Labeladdstate.Visible = false;
                }
            }
            else
            {
                if (ddlAddState.SelectedIndex.Equals(0))
                {   
                    Labeladdstate.Visible = true;
                    returnValue = false;
                }
                else
                {
                    Labeladdstate.Visible = false;
                }
            }
        }       
        if ((txtAddZipCode.Text.ToString() == string.Empty) || (txtAddZipCode.Text.Equals(null)))
        {
            Labeladdzip.Visible = true;
            returnValue = false;
        }
        else
        {
            Labeladdzip.Visible = false;
        }
        if (returnValue == true)
        {
            Labeladdsite.Visible = false;
            Labeladdstate.Visible = false;
            Labeladdzip.Visible = false;
            Labeladdcity.Visible = false;
            Labeladdaddress.Visible = false;
        }
        return returnValue;
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (CheckAddValidation())
        {
            CustomerSite CustSite_ADD = new CustomerSite();
            TeacherSite AddTeach = new TeacherSite();
            TList<StateProvince> spState = new TList<StateProvince>();
            try
            {
                CustSite_ADD.SiteName = txtAddSiteName.Text;
                CustSite_ADD.Address1 = txtAddAddress1.Text;
                CustSite_ADD.Address2 = txtAddAddress2.Text;
                CustSite_ADD.City = txtAddCity.Text;
                CustSite_ADD.Website = txtAddWebSite.Text;
                CustSite_ADD.ZipCode = txtAddZipCode.Text;
                CustSite_ADD.SiteInfo1 = "SiteInfo1";
                CustSite_ADD.SiteInfo2 = "SiteInfo2";
                CustSite_ADD.Region = Convert.ToInt16(ddlSubLocations.SelectedValue);
                CustSite_ADD.Country = 1;
                CustSite_ADD.IsApproved = 1;
                CustSite_ADD.ClubBuilder = 2;
                CustSite_ADD.FacilityAdministratorId = 12;
                CustSite_ADD.NumberOfSystems = 1;
                if (rdbGlobalLocations.SelectedValue == "US")
                {
                    string stateId = ddlAddState.SelectedValue;
                    CustSite_ADD.StateProvince = stateId;
                }
                else
                {
                    if (ddlSubLocations.SelectedValue.Equals("7"))
                    {
                        string stateId = ddlAddState.SelectedValue;
                        CustSite_ADD.StateProvince = stateId;
                        CustSite_ADD.Country = 41;
                    }
                    else
                    {

                        CustSite_ADD.Country = int.Parse(ddlAddState.SelectedValue);
                        CustSite_ADD.StateProvince = "";
                    } 
                }
                DataRepository.CustomerSiteProvider.Insert(CustSite_ADD);
                AddTeach.SiteId = CustSite_ADD.CustomerSiteId;
                AddTeach.TeacherId = 1;
                DataRepository.TeacherSiteProvider.Insert(AddTeach);
                pnlAdd.Visible = false;
                rdbGlobalLocations.Enabled = true;
                rdbSports.Enabled = true;
                ddlSubLocations.Enabled = true;
                ddlSubLocations_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please enter all values marked as Required');", true);
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }
    protected void btnAddNewLocation_Click(object sender, EventArgs e)
    {
        if (ddlSubLocations.SelectedIndex.Equals(0))
        {

            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please  select Location');", true);
        }
        else
        {

            pnlAdd.Visible = true;
            ClearAllAddFeilds();
            grdLocation.Visible = false;
            if (rdbGlobalLocations.SelectedValue == "US")
            {
                Label13.Visible = true;
                LabelCountry.Visible = false;
                BindStates();
                ddlAddState.Visible = true;
                txtAddState.Visible = false;
            }
            else
            {
                if (ddlSubLocations.SelectedValue.Equals("7"))
                {
                    Label13.Visible = true;
                    LabelCountry.Visible = false;
                    ddlAddState.Visible = true;
                    TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(41);
                    ddlAddState.Items.Clear();
                    ddlAddState.Items.Add("---Select State---");
                    ddlAddState.Items[0].Value = "0";
                    int countState = 0;
                    foreach (StateProvince SP in states)
                    {
                        countState++;
                        ddlAddState.Items.Add(SP.StateProvinceName);
                        ddlAddState.Items[countState].Value = Convert.ToString(SP.StateProvinceId);
                    }

                    txtAddState.Visible = false;
                }
                else
                {
                    LabelCountry.Visible = true;
                    Label13.Visible = false;
                    txtAddState.Visible = false;
                    TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
                    countries.RemoveAt(0);
                    countries.RemoveAt(38);
                    ddlAddState.Items.Clear();
                    ddlAddState.Items.Add("---Select Country---");
                    ddlAddState.Items[0].Value = "0";
                    ddlAddState.Items[0].Selected = false;
                    int x = 0;
                    foreach (CountryLookup country in countries)
                    {
                        x++;
                        ddlAddState.Items.Add(country.CountryName);
                        ddlAddState.Items[x].Value = country.CountryId.ToString();
                    }
                    //ddlAddState.Items.RemoveAt(40);
                    //ddlAddState.Items.RemoveAt(1);
                }
            }
            rdbGlobalLocations.Enabled = false;
            rdbSports.Enabled = false;
            ddlSubLocations.Enabled = false;
        }
    }
    private void BindStates()
    {
        //TList<StateProvince> states = DataRepository.StateProvinceProvider.GetAll();
        TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(1);
        ddlAddState.Items.Clear();
        ddlAddState.Items.Add("---Select State---");
        ddlAddState.Items[0].Value = "0";
        int countState = 0;
        foreach (StateProvince SP in states)
        {
            countState++;
            ddlAddState.Items.Add(SP.StateProvinceName);
            ddlAddState.Items[countState].Value = Convert.ToString(SP.StateProvinceId);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        pnlAdd.Visible = false;
        pnlEdit.Visible = false;
        grdLocation.Visible = true;
        btnAddNewLocation.Visible = true;
        rdbGlobalLocations.Enabled = true;
        rdbSports.Enabled = true;
        ddlSubLocations.Enabled = true;
        Labeladd.Visible = false;
        Labelzip.Visible = false;
        Labelstate.Visible = false;
        Labelcity.Visible = false;
        ddlSubLocations_SelectedIndexChanged(null, null);
    }
    protected void BtnAddCancel_Click(object sender, EventArgs e)
    {
        pnlAdd.Visible = false;
        pnlEdit.Visible = false;
        grdLocation.Visible = true;
        btnAddNewLocation.Visible = true;
        rdbGlobalLocations.Enabled = true;
        rdbSports.Enabled = true;
        ddlSubLocations.Enabled = true;
        Labeladdsite.Visible = false;
        Labeladdstate.Visible = false;
        Labeladdzip.Visible = false;
        Labeladdcity.Visible = false;
        Labeladdaddress.Visible = false;
        ddlSubLocations_SelectedIndexChanged(null, null);
    }
    protected void ddlAddState_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Convert.ToInt16(ddlAddState.SelectedValue);
    }
}
