﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Facility_EditTeacher : System.Web.UI.Page
public partial class Facility_EditTeacher : SwingModel.UI.BasePage
{
    public int TeacherId;
    Teacher teacher = new Teacher();
    TeacherSite teachersite = new TeacherSite();
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    CustomerProfile customerprofile = new CustomerProfile();
    CompuSportDAL.SprintAthleteEdit _SprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();
    protected void Page_Load(object sender, EventArgs e)
    {

        TeacherId = Convert.ToInt16(Request.QueryString.Get("TeacherId"));
        teacher = DataRepository.TeacherProvider.GetByTeacherId(TeacherId);



        if (!IsPostBack)
        {
            TextBox1.Text = teacher.FirstName;
            TextBox2.Text = teacher.LastName;
            TextBox3.Text = teacher.WorkPhone;
            TextBox4.Text = teacher.MobilePhone;
            TextBox5.Text = teacher.Fax;
            TextBox6.Text = teacher.TeachingPassword;

            customersites = DataRepository.CustomerSiteProvider.GetAll();
            customersites.Sort("SiteName ASC");

            if (DropDownList1.Items.Count.Equals(0))
            {
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add("Make a Selection");
                DropDownList1.Items[0].Value = "-1";
                int y = 0;
                foreach (CustomerSite cs in customersites)
                {
                    y++;
                    DropDownList1.Items.Add(cs.SiteName);
                    DropDownList1.Items[y].Value = cs.CustomerSiteId.ToString();
                }
            }
            teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teacher.TeacherId)[0];
            //DropDownList1.SelectedValue = teachersite.EntityIdSiteId.ToString();
            DropDownList1.SelectedValue = teachersite.SiteId.ToString();



            Guid MemGuid = new Guid(teacher.AspnetMembershipUserId.ToString());
            MembershipUser user = Membership.GetUser(MemGuid);
            //customer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            //customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(MemGuid);
            //customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            //countrylookup = DataRepository.CountryLookupProvider.GetByCountryId(customer.Country);
            //int SelectedFacilitynew = customerprofile.CustomerSite;
            string[] roles = Roles.GetAllRoles();

            if (DropDownList2.Items.Count.Equals(0))
            {
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("Make a Selection");
                DropDownList2.Items[0].Value = "-1";
                int y = 0;
                DropDownList2.DataSource = roles;
                DropDownList2.DataBind();
            }
            string[] userrole = Roles.GetRolesForUser(user.UserName.ToString());

            // DropDownList1.SelectedValue = SelectedFacilitynew.ToString();
            if (userrole.Length > 0)
            {
                DropDownList2.SelectedValue = userrole[0];
            }
            else
            {
                DropDownList2.SelectedValue = "Golfers";

            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        TeacherId = Convert.ToInt16(Request.QueryString.Get("TeacherId"));
        teacher = DataRepository.TeacherProvider.GetByTeacherId(TeacherId);
        teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teacher.TeacherId)[0];
        int SelectedFacilityNew = Convert.ToInt16(DropDownList1.SelectedValue);
        string selectedrole = Convert.ToString(DropDownList2.SelectedValue);
        bool DoSubmit = false;

        if (TextBox1.Text.Equals("") || TextBox1.Text.Equals(null))
        {
            DoSubmit = false;
            Label7.Visible = true;
        }
        else
        {
            DoSubmit = true;
            Label7.Visible = false;
        }
        if (TextBox2.Text.Equals("") || TextBox2.Text.Equals(null))
        {
            DoSubmit = false;
            Label8.Visible = true;
        }
        else
        {
            if (DoSubmit)
                DoSubmit = true;
            Label8.Visible = false;
        }
        if (TextBox6.Text.Equals("") || TextBox6.Text.Equals(null))
        {
            DoSubmit = false;
            Label9.Visible = true;
        }
        else
        {
            if (DoSubmit)
                DoSubmit = true;
            Label9.Visible = false;
        }
        if (DropDownList1.SelectedItem.Value != "-1")
        {
            DoSubmit = true;

        }


        if (DoSubmit)
        {
            teacher.FirstName = TextBox1.Text;
            teacher.LastName = TextBox2.Text;
            if (!TextBox3.Text.Equals("") && !TextBox3.Text.Equals(null))
                teacher.WorkPhone = TextBox3.Text;
            else
                teacher.WorkPhone = null;
            if (!TextBox4.Text.Equals("") && !TextBox4.Text.Equals(null))
                teacher.MobilePhone = TextBox4.Text;
            else
                teacher.MobilePhone = null;
            if (!TextBox5.Text.Equals("") && !TextBox5.Text.Equals(null))
                teacher.Fax = TextBox5.Text;
            else
                teacher.Fax = null;
            teacher.TeachingPassword = TextBox6.Text;

            DataRepository.TeacherProvider.Update(teacher);
            teachersite.SiteId = SelectedFacilityNew;
            DataRepository.TeacherSiteProvider.Update(teachersite);
            _SprintAthleteEdit.UpdateCustomerProfile_Customersite(TeacherId, SelectedFacilityNew);
            try
            {
                Guid MemGuid = new Guid(teacher.AspnetMembershipUserId.ToString());

                MembershipUser user = Membership.GetUser(MemGuid);
                string[] allroles = Roles.GetRolesForUser(user.UserName);
                Roles.RemoveUserFromRoles(user.UserName, allroles);
                Roles.AddUserToRole(user.UserName, selectedrole);
            }
            catch { }

            this.Page.Response.Redirect("~/Admin/AddTeachers.aspx");
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selectedrole = Convert.ToString(DropDownList2.SelectedValue);
    }
}
