﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using MemberDownload;

public partial class Admin_GetMemberList : System.Web.UI.Page
{
    public GetMemberList gml = new GetMemberList();
    string FirstName = "";
    string LastName = "";
    string EmailAddress = "";

    protected override void OnPreRender(EventArgs e)
    {
        FirstName = Request.QueryString.Get("FirstName");
        LastName = Request.QueryString.Get("LastName");
        EmailAddress = Request.QueryString.Get("Email");

        //MessageBox.Show("FN: " + FirstName);
        //MessageBox.Show("LN: " + LastName);
        //MessageBox.Show("EA: " + EmailAddress);

        TextBox1.Text = FirstName;
        TextBox2.Text = LastName;
        TextBox3.Text = EmailAddress;

        if (!TextBox1.Text.Equals("") && !TextBox1.Text.Equals(null) && !TextBox2.Equals("") && !TextBox2.Equals(null))
            Button1_Click(this, null);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = -9999;

        ListBox1.Items.Clear();

        if (TextBox1.Text.Equals(null) || TextBox1.Text.Equals("") || TextBox2.Text.Equals(null) || TextBox2.Text.Equals(""))
        {
            ListBox1.Items.Add("No Matches");
        }
        else
        {
            i = gml.GetMembers(TextBox1.Text, TextBox2.Text, TextBox3.Text);

            if (gml.GuidMatch.Count.Equals(0))
            {
                //MessageBox.Show("No Matches");
            }
            else
            {
                int x = 0;
                string ListBoxItem = "";
                foreach (string MemberGuid in gml.GuidMatch)
                {
                    ListBoxItem = gml.FirstNameMatch[x].ToString() + " " + gml.LastNameMatch[x].ToString() + ", " + gml.EmailMatch[x].ToString() + ", " + gml.UsernameMatch[x].ToString() + ", " + gml.Address1Match[x].ToString();

                    ListBox1.Items.Add(ListBoxItem);
                    ListBox1.Items[x].Value = gml.GuidMatch.ToString() + "," + gml.CustomerIdMatch.ToString();
                    x++;
                }

                string path = @"G:\SwingModelLive\files\download\list.txt";
                if (File.Exists(path))
                    File.Delete(path);
                FileStream fs = File.Create(path);
                StreamWriter sw = new StreamWriter(fs);
                string swLine = "";

                x = 0;
                foreach (string MemberGuid in gml.GuidMatch)
                {
                    swLine = gml.FirstNameMatch[x].ToString() + " | " + gml.LastNameMatch[x].ToString() + " | " + gml.EmailMatch[x].ToString() + " | " + gml.UsernameMatch[x].ToString() + " | " + gml.Address1Match[x].ToString() + " | " + gml.GuidMatch[x].ToString() + " | " + gml.CustomerIdMatch[x].ToString();
                    sw.WriteLine(swLine);
                    x++;
                }
                sw.Close();
            }
        }

        Response.Redirect("~/files/download/list.txt");
        //nothing
    }
}
