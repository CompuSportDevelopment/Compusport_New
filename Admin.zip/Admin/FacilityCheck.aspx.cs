﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

public partial class Admin_FacilityCheck : System.Web.UI.Page
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    public CustomerSite customersite;
    public TList<TeacherSite> teachersatsite = new TList<TeacherSite>();
    public Teacher teacher;
    string FacilityName = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        FacilityName = Request.QueryString.Get("Facility");

        //MessageBox.Show("Facility: [" + FacilityName + "]");

        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            int x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList1.Items.Add(cs.SiteName);
                DropDownList1.Items[x].Value = cs.CustomerSiteId.ToString();
            }
        }
        
        if (!IsPostBack)
        {
            try
            {
                customersite = DataRepository.CustomerSiteProvider.GetBySiteName(FacilityName)[0];
                DropDownList1.SelectedValue = customersite.CustomerSiteId.ToString();
                //MessageBox.Show("ddl1sv: " + DropDownList1.SelectedValue.ToString());
            }
            catch (Exception)
            {
                DropDownList1.SelectedValue = "-1";
            }
        }
        else
        {
            //MessageBox.Show("IsPostBack");
        }

        if (!DropDownList1.SelectedValue.Equals("-1"))
            Button1_Click(this, null);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //MessageBox.Show("SelectedFacilty: " + DropDownList1.SelectedValue);
        int FacilityNumber = Convert.ToInt16(DropDownList1.SelectedValue);

        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(FacilityNumber);
        teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(FacilityNumber);

        string path = @"G:\SwingModelLive\files\download\facility.txt";
        if (File.Exists(path))
            File.Delete(path);
        FileStream fs = File.Create(path);
        StreamWriter sw = new StreamWriter(fs);
        if (customersite.IsApproved.Equals(1))
        {
            //Facility Approved
            sw.WriteLine(FacilityNumber.ToString());
            sw.WriteLine("1");
            foreach (TeacherSite tas in teachersatsite)
            {
                teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                sw.WriteLine(teacher.FirstName + " " + teacher.LastName + " | " + teacher.TeachingPassword);
            }
            if (!FacilityNumber.Equals(9))
            {
                sw.WriteLine("Ralph Mann | Olympic");
                sw.WriteLine("Joey Hidock | Joey");
            }
            sw.WriteLine("SwingModel Development | Sport");
        }
        else
        {
            //Facility Not Approved
            sw.WriteLine(FacilityNumber.ToString());
            sw.WriteLine("0");
            foreach (TeacherSite tas in teachersatsite)
            {
                teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                sw.WriteLine(teacher.FirstName + " " + teacher.LastName + " | " + teacher.TeachingPassword);
            }
            if (!FacilityNumber.Equals(9))
            {
                sw.WriteLine("Ralph Mann | Olympic");
                sw.WriteLine("Joey Hidock | Joey");
            }
            sw.WriteLine("SwingModel Development | Sport");
        }
        sw.Close();

        Response.Redirect("~/files/download/facility.txt");
    }
}
