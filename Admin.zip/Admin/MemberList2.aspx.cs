﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Admin_MemberList : System.Web.UI.Page
public partial class Admin_MemberList : SwingModel.UI.BasePage
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    
    public Customer customer;
    public CustomerProfile customerprofile;
    public TList<TeacherSite> teachersatsite = new TList<TeacherSite>();
    public Teacher teacher;
    public CustomerSite customersite;

    protected void Page_Load(object sender, EventArgs e)
    {
        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            int x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList1.Items.Add(cs.SiteName);
                DropDownList1.Items[x].Value = cs.CustomerSiteId.ToString();
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int SelectedFacilityId = Convert.ToInt16(DropDownList1.SelectedValue);
        TList<CustomerProfile> customerprofiles = new TList<CustomerProfile>();
        TList<SiteReferral> sitereferrals = new TList<SiteReferral>();
        Customer cus2;

        bool RunReport = false;
        if (SelectedFacilityId.Equals(-1))
        {
            Label12.Text = "Please select a facility.";
            RunReport = false;
        }
        else
        {
            Label12.Text = "";
            RunReport = true;
        }

        if (TextBox1.Text.Equals("") || TextBox1.Text.Equals(null))
        {
            Label4.Text = "Please select a beginning date.";
            RunReport = false;
        }
        else
        {
            Label4.Text = "";
            RunReport = true;
        }

        if (TextBox2.Text.Equals("") || TextBox2.Text.Equals(null))
        {
            Label5.Text = "Please select an ending date.";
            RunReport = false;
        }
        else
        {
            Label5.Text = "";
            RunReport = true;
        }

        if (!TextBox1.Text.Equals("") && !TextBox2.Text.Equals(""))
        {
            if (DateTime.Parse(TextBox2.Text) < DateTime.Parse(TextBox1.Text))
            {
                Label4.Text = "Please select a beginning date before the ending date.";
                Label5.Text = "Please select an ending date after the beginning date.";
                RunReport = false;
            }
            else
            {
                Label4.Text = "";
                Label5.Text = "";
                RunReport = true;
            }
        }

        if (RunReport)
        {
            Label13.Text = "";
            Label14.Text = "";
            Label15.Text = "";
            Label16.Text = "";
            Label17.Text = "";
            Label18.Text = "";
            int x = 1;
            DataTable dt = new DataTable();
            dt.Columns.Add("Count", typeof(int));
            dt.Columns.Add("First Name", typeof(string));
            dt.Columns.Add("Last Name", typeof(string));
            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("HiddenDate", typeof(DateTime));
            dt.Columns.Add("Teacher", typeof(string));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("Renewal", typeof(string));
            dt.Columns.Add("Bill", typeof(string));
            dt.Columns.Add("Billed", typeof(string));
            dt.Columns.Add("Commission", typeof(string));
            string StatusText = "";
            string RenewalText = "";
            string BillText = "";
            decimal BilledAmount = 0;
            decimal CommissionAmount = 0;

            customerprofiles = DataRepository.CustomerProfileProvider.GetByCustomerSite(SelectedFacilityId);
            foreach (CustomerProfile cp in customerprofiles)
            {
                Customer cus = DataRepository.CustomerProvider.GetByCustomerId(cp.CustomerId);
                Guid MemGuid = new Guid(cus.AspnetMembershipUserId.ToString());
                MembershipUser user = Membership.GetUser(MemGuid);
                Teacher teach = DataRepository.TeacherProvider.GetByTeacherId(cp.Teacher);

                StatusText = "";
                switch (cus.MembershipStatus)
                {
                    case 0:
                        StatusText = "Expired";
                        break;

                    case 1:
                        StatusText = "Member";
                        break;

                    case 2:
                        StatusText = "FullTeach";
                        break;

                    case 3:
                        StatusText = "FullFit";
                        break;

                    case 4:
                        StatusText = "FullTeachFit";
                        break;

                    case 97:
                        StatusText = "CompTeach";
                        break;

                    case 98:
                        StatusText = "CompFit";
                        break;

                    case 99:
                        StatusText = "CompTeachFit";
                        break;

                    default:
                        StatusText = "?";
                        break;
                }
                RenewalText = "";
                switch (cus.IsRenewal)
                {
                    case 0:
                        RenewalText = "No";
                        break;

                    case 1:
                        RenewalText = "Yes";
                        break;

                    default:
                        RenewalText = "?";
                        break;
                }
                BillText = "";
                if (cus.BillFacility.Equals(1))
                {
                    BillText = "Yes";

                }
                else
                {
                    BillText = "No";
                }
                //switch (cus.BillFacility)
                //{
                //    case 0:
                //        BillText = "No";
                //        break;

                //    case 1:
                //        BillText = "Yes";
                //        break;

                //    default:
                //        BillText = "?";
                //        break;
                //}

                try
                {
                    //if (user.CreationDate >= DateTime.Parse(TextBox1.Text) && user.CreationDate <= DateTime.Parse(TextBox2.Text))
                    if (cus.MembershipRenewal >= DateTime.Parse(TextBox1.Text) && cus.MembershipRenewal <= DateTime.Parse(TextBox2.Text))
                    {
                        if (cus.MembershipStatus.Equals(0) || cus.MembershipStatus.Equals(1) || cus.MembershipStatus.Equals(97) || cus.MembershipStatus.Equals(98) || cus.MembershipStatus.Equals(99))
                            dt.Rows.Add(x, cus.FirstName, cus.LastName, cus.MembershipRenewal, cus.MembershipRenewal, teach.FirstName + " " + teach.LastName, StatusText, RenewalText, BillText, "$0.00", "$0.00");
                        else if (cus.MembershipStatus.Equals(2) || cus.MembershipStatus.Equals(3))
                        {
                            if (cus.BillFacility.Equals(1))
                                BilledAmount = BilledAmount + Convert.ToDecimal(cus.MembershipCost);
                            if (cus.MembershipCost < 99)
                            {
                                CommissionAmount = CommissionAmount + 0;
                                dt.Rows.Add(x, cus.FirstName, cus.LastName, cus.MembershipRenewal, cus.MembershipRenewal, teach.FirstName + " " + teach.LastName, StatusText, RenewalText, BillText, "$" + cus.MembershipCost.ToString() + ".00", "$0.00");
                            }
                            else
                            {
                                CommissionAmount = CommissionAmount + 50;
                                dt.Rows.Add(x, cus.FirstName, cus.LastName, cus.MembershipRenewal, cus.MembershipRenewal, teach.FirstName + " " + teach.LastName, StatusText, RenewalText, BillText, "$" + cus.MembershipCost.ToString() + ".00", "$50.00");
                            }
                        }
                        else if (cus.MembershipStatus.Equals(4))
                        {
                            if (cus.BillFacility.Equals(1))
                                BilledAmount = BilledAmount + Convert.ToDecimal(cus.MembershipCost);
                            if (cus.MembershipCost < 99)
                            {
                                CommissionAmount = CommissionAmount + 0;
                                dt.Rows.Add(x, cus.FirstName, cus.LastName, cus.MembershipRenewal, cus.MembershipRenewal, teach.FirstName + " " + teach.LastName, StatusText, RenewalText, BillText, "$" + cus.MembershipCost.ToString() + ".00", "$0.00");
                            }
                            else
                            {
                                CommissionAmount = CommissionAmount + 50;
                                dt.Rows.Add(x, cus.FirstName, cus.LastName, cus.MembershipRenewal, cus.MembershipRenewal, teach.FirstName + " " + teach.LastName, StatusText, RenewalText, BillText, "$" + cus.MembershipCost.ToString() + ".00", "$50.00");
                            }
                        }
                    }
                    x++;
                }
                catch (Exception ex)
                {
                    //MessageBox.Show("customer: " + cp.CustomerId.ToString());
                    //MessageBox.Show("ex: " + ex.ToString());
                    continue;
                }
            }
            dt.DefaultView.Sort = "Date ASC";

            DataTable dt2 = new DataTable();
            dt2 = dt.Clone();
            int dochange = 0;
            foreach (DataColumn dc in dt2.Columns)
            {
                if (dc.DataType == typeof(DateTime))
                {
                    if (dochange.Equals(0))
                    {
                        dc.DataType = typeof(string);
                        dochange = 1;
                    }
                }
            }
            foreach (DataRow dr in dt.Rows)
            {
                dt2.ImportRow(dr);
            }
            dt2.DefaultView.Sort = "HiddenDate ASC";

            x = 0;
            foreach (DataRowView row in dt2.DefaultView)
            {
                x++;
                row.Row.SetField("Count", x);
                row.Row.SetField("Date", row["Date"].ToString().Substring(0, row["Date"].ToString().IndexOf(" ")));
            }
            GridView1.DataSource = dt2;
            GridView1.DataBind();

            Label1.Text = DropDownList1.SelectedItem.Text;

            Label7.Text = "$" + BilledAmount.ToString("###,##0.00");
            Label9.Text = "$" + CommissionAmount.ToString("###,##0.00");
            Label11.Text = "$" + (BilledAmount - CommissionAmount).ToString("###,##0.00");

            try
            {
                sitereferrals = DataRepository.SiteReferralProvider.GetByCustomerSiteId(SelectedFacilityId);
                int y = 0;
                decimal comm;
                foreach (SiteReferral sr in sitereferrals)
                {
                    y++;
                    cus2 = DataRepository.CustomerProvider.GetByCustomerId(sr.CustomerId);
                    comm = (BilledAmount - CommissionAmount) * Convert.ToDecimal(sr.Percentage / 100);
                    switch (y)
                    {
                        case 1:
                            Label13.Text = cus2.FirstName + " " + cus2.LastName + " Commission: ";
                            Label14.Text = "$" + comm.ToString("#,##0.00");
                            break;

                        case 2:
                            Label15.Text = cus2.FirstName + " " + cus2.LastName + " Commission: ";
                            Label16.Text = "$" + comm.ToString("#,##0.00");
                            break;

                        case 3:
                            Label17.Text = cus2.FirstName + " " + cus2.LastName + " Commission: ";
                            Label18.Text = "$" + comm.ToString("#,##0.00");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
