﻿using System;
using System.Collections;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using System.Net.Mail;

public partial class Admin_SendRepeatMemberEmail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //MailAddress from = new MailAddress("info@swingmodel.com");
        //MailAddress to = new MailAddress(TextBox3.Text);
        //MailMessage message = new MailMessage(from, to);
        MailMessage message = new MailMessage();
        message.From = new MailAddress("info@swingmodel.com");
        message.To.Add(TextBox3.Text);
        message.CC.Add(TextBox2.Text);
        message.CC.Add("dev@swingmodel.com");

        message.IsBodyHtml = true;
        message.Subject = "Your SwingModel Lesson";
        message.Body = "<html>"
            + "<head>"
            + "    <title></title>"
            + "    <style type=\"text/css\">"
            + "        .style1"
            + "        {"
            + "            text-align: justify;"
            + "        }"
            + "    </style>"
            + "</head>"
            + "<body style=\"font-family: Calibri; font-size: small; width: 980px;\">"
            + "    <p style=\"text-align: left\">"
            + "        <img alt=\"\" src=\"http://www.swingmodel.com/Images/EmailHeader.jpg\" width=\"980\" height=\"151\" /></p>"
            + "    <p>"
            + "        Hello " + TextBox1.Text + ",</p>"
            + "    <p class=\"style1\">"
            + "        Greetings from SwingModel. We're glad to see you've taken another lesson, and are "
            + "        continuing to improve your golf game.</p>"
            + "    <p class=\"style1\">"
            + "        As you already know, all of your lessons are found in the My SwingModel section on the "
            + "        website. The video player on the My Swing page allows you to load your entire history "
            + "        of lessons. You can view the side and back views of the same swing, or compare different "
            + "        swings from either the side or back view. You may also view your Teacher Summary in the "
            + "        player at the bottom of the page, if your Teacher recorded one at the end of your lesson.</p>"
            + "    <p class=\"style1\">"
            + "        To login to your personalized My SwingModel site, visit"
            + "        <a href=\"http://www.swingmodel.com\">http://www.swingmodel.com</a>. Once at the "
            + "        SwingModel site, click on the Login link in the upper-right section of the Home "
            + "        Page, or click on the desired option in the My SwingModel menu. You will be "
            + "        taken to the Login page. Enter the following login details, and click on the Log "
            + "        In button.</p>"
            + "    <p class=\"style1\">"
            + "        <b>Username:</b> " + TextBox4.Text + "</p>"
            + "    <p class=\"style1\">"
            + "        To view your swing videos and associated errors, go to the My Swing page. If you "
            + "        need to update any of your personal or golf details, visit the My Account, My "
            + "        Dimensions, and My Golf pages. Send email to your instructor through the Email "
            + "        My Teacher page, or request a lesson appointment on the Schedule A Lesson page.</p>"
            + "    <p class=\"style1\">"
            + "        If you have any questions, or need any help with your My SwingModel site, please "
            + "        email us at <a href=\"mailto:info@swingmodel.com\">info@swingmodel.com</a>.</p>"
            + "    <p class=\"style1\">"
            + "        Cordially,<br />"
            + "        The SwingModel Staff</p>"
            + "</body>"
            + "</html>";

        Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        MailSettingsSectionGroup settings = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");
        SmtpClient client = new SmtpClient(settings.Smtp.Network.Host);
        try
        {
            client.Send(message);
            Response.Write("Your Email has been sent sucessfully - Thank You");
        }
        catch (Exception ex)
        {
            Response.Write("Send failure: " + ex.ToString());
        }
    }
}
