﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using SwfDotNet.IO;
using System.Drawing;
using CompuSportDAL;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;

public partial class Admin_DataBaseAccess : System.Web.UI.Page
{
    public Customer customer;
    public CustomerProfile customerprofile;
    public IEnumerable teachersatsite;
    public Teacher teacher;
    public CustomerSite customersite;
    public IEnumerable teacherall;
    string[] roles = Roles.GetAllRoles();
    SprintAthleteEdit _sprintAthleteEdit = new SprintAthleteEdit();
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
        if (!Page.IsPostBack)
        {

            string script = "$(document).ready(function () { $('[id*=btnSubmit]').click(); });";
            ClientScript.RegisterStartupScript(this.GetType(), "load", script, true);

            IDictionary<int, string> Eventlist = new Dictionary<int, string>();
            Eventlist.Add(1, "Start");
            Eventlist.Add(2, "Sprint");
            Eventlist.Add(3, "Hurdle");
            Eventlist.Add(6, "Hurdle Step");
            DropDownList1.DataSource = Eventlist;
            DropDownList1.DataTextField = "Value";
            DropDownList1.DataValueField = "Key";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("Select Event", "0"));


            IDictionary<int, string> Tablelist = new Dictionary<int, string>();
            Tablelist.Add(1, "Initial");
            Tablelist.Add(2, "Model");
            Tablelist.Add(3, "Final");
            Tablelist.Add(4, "Competition");
            DropDownList6.DataSource = Tablelist;
            DropDownList6.DataTextField = "Value";
            DropDownList6.DataValueField = "Key";
            DropDownList6.DataBind();
            DropDownList6.Items.Insert(0, new ListItem("Select Session", "0"));

            DropDownList2.Items.Insert(0, new ListItem("Select variable 1", "0"));
            DropDownList3.Items.Insert(0, new ListItem("Select variable 2", "0"));
            DropDownList4.Items.Insert(0, new ListItem("Select variable 3", "0"));
            DropDownList5.Items.Insert(0, new ListItem("Select variable 4", "0"));

        }
        //DropDownList1.Items.Clear();
        //DropDownList1.Items.Clear();

    }

    private void SprintVariableListInInial(int EventId)
    {

        DataTable dtathlets = _sprintAthleteEdit.GetAllAthleteSessonData(EventId);
        IDictionary<string, string> Variablelist = new Dictionary<string, string>();
        Variablelist.Add("Velocity", "Result: Sprint Velocity");
        Variablelist.Add("Ground Time Left", "General: Ground Time Left");
        Variablelist.Add("Ground Time Right", "General: Ground Time Righ");
        Variablelist.Add("Ground Time Average", "General: Ground Time Average");
        Variablelist.Add("Air Time Left to Right", "General: Air Time Left to Right");
        Variablelist.Add("Air Time Right to Left", "General: Air Time Right to Left");
        Variablelist.Add("Air Time Average", "General: Air Time Average");
        Variablelist.Add("Time to Upper Leg Full Flexion Left", "General: Time to Upper Leg Full Flexion Left");
        Variablelist.Add("Time to Upper Leg Full Flexion Right", "General: Time to Upper Leg Full Flexion Right");
        Variablelist.Add("Time to Upper Leg Full Flexion Average", "General: Time to Upper Leg Full Flexion Average");
        Variablelist.Add("Stride Rate", "General: Stride Rate");
        Variablelist.Add("Stride Length Left to Right", "Special: Stride Length Left to Right");
        Variablelist.Add("Stride Length Right to Left", "Special: Stride Length Right to Left");
        Variablelist.Add("Stride Length Average", "Special: Stride Length Average");
        Variablelist.Add("TAATouchDownLeft", "Specific: Trunk Angle at Touchdown Left");
        Variablelist.Add("TAATouchDownRight", "Specific: Trunk Angle at Touchdown Right");
        Variablelist.Add("Trunk Angle at Touchdown Average", "Specific: Trunk Angle at Touchdown Average");
        Variablelist.Add("KSATouchDownLeft", "Specific: Knee-Knee Separation at Touchdown Left");
        Variablelist.Add("KSATouchDownRight", "Specific: Knee-Knee Separation at Touchdown Right");
        Variablelist.Add("Knee Separation at Touchdown Average", "Specific: Knee-Knee Separation at Touchdown Average");
        Variablelist.Add("Touchdown Distance Left", "Specific: COG to Foot Touchdown Distance Left");
        Variablelist.Add("Touchdown Distance Right", "Specific: COG to Foot Touchdown Distance Right");
        Variablelist.Add("Touchdown Distance Average", "Specific: COG to Foot Touchdown Distance Average");
        Variablelist.Add("Upper Leg Full Extension Angle Left", "Specific: Upper Leg Full Extension Angle Left");
        Variablelist.Add("Upper Leg Full Extension Angle Right", "Specific: Upper Leg Full Extension Angle Right");
        Variablelist.Add("Upper Leg Full Extension Angle Average", "Specific: Upper Leg Full Extension Angle Average");
        Variablelist.Add("Lower Leg Angle at Takeoff Left", "Specific: Upper Leg Full Flexion Angle Left");
        Variablelist.Add("Lower Leg Angle at Takeoff Right", "Specific: Upper Leg Full Flexion Angle Right");
        Variablelist.Add("Lower Leg Angle at Takeoff Average", "Specific: Upper Leg Full Flexion Angle Average");
        Variablelist.Add("Lower Leg Full Flexion Angle Left", "Specific: Lower Leg Angle at Takeoff Left");
        Variablelist.Add("Lower Leg Full Flexion Angle Right", "Specific: Lower Leg Angle at Takeoff Right");
        Variablelist.Add("Lower Leg Full Flexion Angle Average", "Specific: Lower Leg Angle at Takeoff Average");
        Variablelist.Add("Upper Leg Full Flexion Angle Left", "Specific: Lower Leg Full Flexion Angle Left");
        Variablelist.Add("Upper Leg Full Flexion Angle Right", "Specific: Lower Leg Full Flexion Angle Right");
        Variablelist.Add("Upper Leg Full Flexion Angle Average", "Specific: Lower Leg Full Flexion Angle Average");


        DropDownList2.DataSource = Variablelist;
        DropDownList2.DataTextField = "Value";
        DropDownList2.DataValueField = "Key";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select variable 1", "0"));
        DropDownList3.DataSource = Variablelist;
        DropDownList3.DataTextField = "Value";
        DropDownList3.DataValueField = "Key";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select variable 2", "0"));
        DropDownList4.DataSource = Variablelist;
        DropDownList4.DataTextField = "Value";
        DropDownList4.DataValueField = "Key";
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select variable 3", "0"));
        DropDownList5.DataSource = Variablelist;
        DropDownList5.DataTextField = "Value";
        DropDownList5.DataValueField = "Key";
        DropDownList5.DataBind();
        DropDownList5.Items.Insert(0, new ListItem("Select variable 4", "0"));

    }

    private void StartVariableListIninial(int EventId)
    {
        DataTable dtathlets = _sprintAthleteEdit.GetAllAthleteSessonData(EventId);
        IDictionary<string, string> Variableliststartstartstart = new Dictionary<string, string>();
        //-----------------start variable start--------->>
        //-------------set position
        // start.add(" select variable 2");

        Variableliststartstartstart.Add("SetFrontBlockDistance", "specific: front block distance");
        Variableliststartstartstart.Add("SetRearBlockDistance", "specific: rear block distance");
        Variableliststartstartstart.Add("SetFrontULAngle", "specific: front upper leg angle");
        Variableliststartstartstart.Add("SetRearULAngle", "specific: rear upper leg angle");
        Variableliststartstartstart.Add("SetFrontLLAngle", "specific: front lower leg angle");
        Variableliststartstartstart.Add("SetRearLLAngle", "specific: rear lower leg angle");
        Variableliststartstartstart.Add("SetTrunkAngle", "specific: trunk angle");
        Variableliststartstartstart.Add("SetCOGDistance", "specific: cog distance from front block");

        //-------------block clearance
        Variableliststartstartstart.Add("BCRearFootClearanceTime", "general: rear foot clearance time");
        Variableliststartstartstart.Add("BCFrontFootClearanceTime", "general: front foot clearance time");
        Variableliststartstartstart.Add("BCAirTime", "general: air time");
        Variableliststartstartstart.Add("BCLLAngleAC", "specific: lower leg angle at ankle cross");
        Variableliststartstartstart.Add("BCRearLLAngleTakeoff", "specific: rear lower leg angle at rear takeoff");
        Variableliststartstartstart.Add("BC StrideRate", "general: stride rate");
        Variableliststartstartstart.Add("BC Stride Length", "general: stride length from front block");
        Variableliststartstartstart.Add("BCFrontLLAngleTakeoff", "specific: front lower leg angle at front takeoff");
        Variableliststartstartstart.Add("BCTrunkAngleTakeoff", "specific: trunk angle at takeoff");
        //-------------step 1
        Variableliststartstartstart.Add("Step1GroundTime", "general: ground time");
        Variableliststartstartstart.Add("Step1AirTime", "general: air time");
        Variableliststartstartstart.Add("Step1 Stride Rate", "general: stride rate");
        Variableliststartstartstart.Add("Step1StrideLength", "general: stride length");
        Variableliststartstartstart.Add("Step1COGDistance", "specific: cog to foot touchdown distance");
        Variableliststartstartstart.Add("Step1LLAngleAC", "specific: lower leg angle at ankle cross");
        Variableliststartstartstart.Add("Step1LLAngleTakeoff", "specific: rear lower leg angle at takeoff");
        Variableliststartstartstart.Add("Step1TrunkAngleTakeoff", "specific: trunk angle at takeoff");

        //-------------step 2
        Variableliststartstartstart.Add("Step2GroundTime", "general: ground time");
        Variableliststartstartstart.Add("Step2AirTime", "general: air time");
        Variableliststartstartstart.Add("Step2 Stride Rate", "general: stride rate");
        Variableliststartstartstart.Add("Step2StrideLength", "general: stride length");
        Variableliststartstartstart.Add("Step2COGDistance", "specific: cog to foot touchdown distance");
        Variableliststartstartstart.Add("Step2LLAngleAC", "specific: lower leg angle at ankle cross");
        Variableliststartstartstart.Add("Step2LLAngleTakeoff", "specific: rear lower leg angle at takeoff");
        Variableliststartstartstart.Add("Step2TrunkAngleTakeoff", "specific: trunk angle at takeoff");
        //-------------step 3
        Variableliststartstartstart.Add("Step3COGDistance", "specific: cog to foot touchdown distance");
        //-------------results at markers
        Variableliststartstartstart.Add("TimeTo3m", "result: time to 3m (head position)");
        Variableliststartstartstart.Add("TimeTo5m", "result: time to 5m (head position)");
        Variableliststartstartstart.Add("BodyVolAt3Meters", "result: body velocity at 3 meters (cog position)");
        //-----------------sprint variable end--------->>

        DropDownList2.DataSource = Variableliststartstartstart;
        DropDownList2.DataTextField = "Value";
        DropDownList2.DataValueField = "Key";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select variable 1", "0"));
        DropDownList3.DataSource = Variableliststartstartstart;
        DropDownList3.DataTextField = "Value";
        DropDownList3.DataValueField = "Key";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select variable 2", "0"));
        DropDownList4.DataSource = Variableliststartstartstart;
        DropDownList4.DataTextField = "Value";
        DropDownList4.DataValueField = "Key";
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select variable 3", "0"));
        DropDownList5.DataSource = Variableliststartstartstart;
        DropDownList5.DataTextField = "Value";
        DropDownList5.DataValueField = "Key";
        DropDownList5.DataBind();
        DropDownList5.Items.Insert(0, new ListItem("Select variable 4", "0"));
    }

    private void HurdleVariableListIninial(int EventId)
    {
        DataTable dtathlets = _sprintAthleteEdit.GetAllAthleteSessonData(EventId);
        IDictionary<string, string> VariableliststartstartHurdle = new Dictionary<string, string>();

        //-----------------Hurdle Variable Start--------->>
        //---  Result: Hurdle Clearance Velocity
        //Hurdle.Add("Select Variable 3");
        VariableliststartstartHurdle.Add("Velocity", "Result: Hurdle Clearance Velocity");
        VariableliststartstartHurdle.Add("GroundTimeInto", "General: Ground Time Into");
        VariableliststartstartHurdle.Add("GroundTimeOff", "General: Ground Time Off");
        VariableliststartstartHurdle.Add("AirTimeOver", "General: Air Time");
        VariableliststartstartHurdle.Add("StrideLengthInto", "General: Stride Length Into");
        VariableliststartstartHurdle.Add("StrideLengthOff", "General: Stride Length Off");
        VariableliststartstartHurdle.Add("StrideLengthTotal", "General: Stride Length Total");
        VariableliststartstartHurdle.Add("COGDistanceInto", "Specific: COG to Foot Touchdown Distance Into");
        VariableliststartstartHurdle.Add("COGDistanceOff", "Specific: COG to Foot Touchdown Distance Off");
        VariableliststartstartHurdle.Add("KSTouchDownInto", "Specific: Knee-Knee Separation at Touchdown Into");
        VariableliststartstartHurdle.Add("KSTouchDownOff", "Specific: Knee-Ankle Separation at Touchdown Off");
        VariableliststartstartHurdle.Add("TTDAngleInto", "Specific: Trunk Angle at Touchdown Into");
        VariableliststartstartHurdle.Add("TTAngleInto", "Specific: Trunk Angle at Takeoff Into");
        VariableliststartstartHurdle.Add("TMAngleOver", "Specific: Trunk Minimum Angle Over");
        VariableliststartstartHurdle.Add("TTDAngleOff", "Specific: Trunk Angle at Touchdown Off");
        VariableliststartstartHurdle.Add("TTAngleOff", "Specific: Trunk Angle at Takeoff Off");
        VariableliststartstartHurdle.Add("ULAngleTDInto", "Specific: Trail Upper Leg Angle at Touchdown Into");
        VariableliststartstartHurdle.Add("ULAngleTOInto", "Specific: Trail Upper Leg Angle at Takeoff Into");
        VariableliststartstartHurdle.Add("ULMAngleOver", "Specific: Lead Upper Leg Maximum Angle Over");
        VariableliststartstartHurdle.Add("ULAngleTDOff", "Specific: Lead Upper Leg Angle at Touchdown Off");
        VariableliststartstartHurdle.Add("ULAngleTOOff", "Specific: Lead Upper Leg Angle at Takeoff Off");
        VariableliststartstartHurdle.Add("LeadLegMinimumAngle", "Specific: Lead Lower Leg Minimum Angle Into");
        VariableliststartstartHurdle.Add("LeadLegAngleAC", "Specific: Lead Lower Leg Angle at Ankle Cross Into");
        VariableliststartstartHurdle.Add("KAMSeparationOver", "Specific: Knee-Ankle Vertical Separation Over");
        VariableliststartstartHurdle.Add("LLMAngleOver", "Specific: Lead Lower Leg Maximum Angle Over");
        VariableliststartstartHurdle.Add("LLAngleTDOff", "Specific: Lead Lower Leg Angle at Touchdown Off");
        VariableliststartstartHurdle.Add("LLAngleTOOff", "Specific: Lead Lower Leg Angle at Takeoff Off");
        //-----------------Hurdle Variable End--------->>
        DropDownList2.DataSource = VariableliststartstartHurdle;
        DropDownList2.DataTextField = "Value";
        DropDownList2.DataValueField = "Key";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select variable 1", "0"));
        DropDownList3.DataSource = VariableliststartstartHurdle;
        DropDownList3.DataTextField = "Value";
        DropDownList3.DataValueField = "Key";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select variable 2", "0"));
        DropDownList4.DataSource = VariableliststartstartHurdle;
        DropDownList4.DataTextField = "Value";
        DropDownList4.DataValueField = "Key";
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select variable 3", "0"));
        DropDownList5.DataSource = VariableliststartstartHurdle;
        DropDownList5.DataTextField = "Value";
        DropDownList5.DataValueField = "Key";
        DropDownList5.DataBind();
        DropDownList5.Items.Insert(0, new ListItem("Select variable 4", "0"));
    }

    private void HurdleStepVariableListIninial(int EventId)
    {

        DataTable dtathlets = _sprintAthleteEdit.GetAllAthleteSessonData(EventId);
        IDictionary<string, string> VariableliststartstartHurdleStep = new Dictionary<string, string>();
        //-----------------Hurdle Step Variable Start--------->>
        //  Hurdle_Step.Add(" Select Variable 4");
        //-------------------- Hurdle Distances
        VariableliststartstartHurdleStep.Add("Velocity", "Result: Hurdle Step Velocity");

        VariableliststartstartHurdleStep.Add("SetDistanceBetweenHurdleSteps", "Setting: Between the Hurdles");
        VariableliststartstartHurdleStep.Add("SetDistanceIntoHurdleSteps", "General: Stride Length Into");
        VariableliststartstartHurdleStep.Add("SetDistanceOffHurdleSteps", "General: Stride Length Off");
        //VariableliststartstartHurdleStep.Add("Velocity", "Result: Hurdle Step Velocity");
        //--------------------Step One
        VariableliststartstartHurdleStep.Add("Step1GroundTime", "General: Ground Time");
        VariableliststartstartHurdleStep.Add("Step1AirTime", "General: Air Time");
        //VariableliststartstartHurdleStep.Add("", "General: Stride Rate");
        VariableliststartstartHurdleStep.Add("Step1StrideLength", "General: Stride Length");
        VariableliststartstartHurdleStep.Add("Step1TouchdownDistance", "Specific: COG to Foot Touchdown Distance");
        VariableliststartstartHurdleStep.Add("Step1KneeSeperationatTouchdown", "Specific: Knee-Ankle Separation at Touchdown");
        VariableliststartstartHurdleStep.Add("Step1TrunkTouchdownAngle", "Specific: Trunk Angle at Touchdown");
        VariableliststartstartHurdleStep.Add("Step1ULAtFullExtension", "Specific: Upper Leg Angle at Full Flexion");
        VariableliststartstartHurdleStep.Add("Step1TrunkTakeoffAngle", "Specific: Lower Leg Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step1LLAtTakeoff", "Specific: Trunk Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step1ULAtFullFlexion", "Specific: Upper Leg Angle at Full Extension");
        //--------------------Step Two
        //Step2LLAtatAnkleCross
        VariableliststartstartHurdleStep.Add("Step2GroundTime", "General: Ground Time");
        VariableliststartstartHurdleStep.Add("Step2AirTime", "General: Air Time");
        //VariableliststartstartHurdleStep.Add("", "General: Stride Rate");
        VariableliststartstartHurdleStep.Add("Step2StrideLength", "General: Stride Length");
        VariableliststartstartHurdleStep.Add("Step2TouchdownDistance", "Specific: COG to Foot Touchdown Distance");
        VariableliststartstartHurdleStep.Add("Step2KneeSeperationatTouchdown", "Specific: Knee-Knee Separation at Touchdown");
        VariableliststartstartHurdleStep.Add("Step2TrunkTouchdownAngle", "Specific: Trunk Angle at Touchdown");
        VariableliststartstartHurdleStep.Add("Step2LLAtFullFlexion", "Specific: Lower Leg Angle at Full Flexion");
        VariableliststartstartHurdleStep.Add("Step2LLAtTakeoff", "Specific: Lower Leg Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step2TrunkTakeoffAngle", "Specific: Trunk Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step2ULAtFullExtension", "Specific: Upper Leg Angle at Full Extension");
        VariableliststartstartHurdleStep.Add("Step2ULAtFullFlexion", "Specific: Upper Leg Angle at Full Flexion");
        //--------------------Step Three
        //Step3ULAtFullExtension
        //Step3LLAtatAnkleCross
        VariableliststartstartHurdleStep.Add("Step3GroundTime", "General: Ground Time");
        VariableliststartstartHurdleStep.Add("Step3AirTime", "General: Air Time");
        // VariableliststartstartHurdleStep.Add("", "General: Stride Rate");
        VariableliststartstartHurdleStep.Add("Step3StrideLength", "General: Stride Length");
        VariableliststartstartHurdleStep.Add("Step3TouchdownDistance", "Specific: COG to Foot Touchdown Distance");
        VariableliststartstartHurdleStep.Add("Step3KneeSeperationatTouchdown", "Specific: Knee-Knee Separation at Touchdown");
        VariableliststartstartHurdleStep.Add("Step3TrunkTouchdownAngle", "Specific: Trunk Angle at Touchdown");
        VariableliststartstartHurdleStep.Add("Step3LLAtFullFlexion", "Specific: Lower Leg Angle at Full Flexion");
        VariableliststartstartHurdleStep.Add("Step3LLAtTakeoff", "Specific: Lower Leg Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step3TrunkTakeoffAngle", "Specific: Trunk Angle at Takeoff");
        VariableliststartstartHurdleStep.Add("Step3ULAtFullExtension", "Specific: Upper Leg Angle at Full Extension");
        VariableliststartstartHurdleStep.Add("Step3ULAtFullFlexion", "Specific: Upper Leg Angle at Full Flexion");
        //--------------------Into The Hurdle
        VariableliststartstartHurdleStep.Add("SetTouchdownDistanceIntoTheHurdle", "Specific: COG to Foot Touchdown Distance");
        VariableliststartstartHurdleStep.Add("SetKneeSeperationatTouchdownIntoTheHurdle", "Specific: Knee-Knee Separation at Touchdown");
        VariableliststartstartHurdleStep.Add("SetLLAtTouchdownIntoTheHurdle", "Specific: Lower Leg Angle at Touchdown");
        VariableliststartstartHurdleStep.Add("SetTrunkTouchdownAngleIntoTheHurdle", "Specific: Trunk Angle at Touchdown");

        // -----------------Hurdle Step Variable End--------->>
        DropDownList2.DataSource = VariableliststartstartHurdleStep;
        DropDownList2.DataTextField = "Value";
        DropDownList2.DataValueField = "Key";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select variable 1", "0"));
        DropDownList3.DataSource = VariableliststartstartHurdleStep;
        DropDownList3.DataTextField = "Value";
        DropDownList3.DataValueField = "Key";
        DropDownList3.DataBind();
        DropDownList3.Items.Insert(0, new ListItem("Select variable 2", "0"));
        DropDownList4.DataSource = VariableliststartstartHurdleStep;
        DropDownList4.DataTextField = "Value";
        DropDownList4.DataValueField = "Key";
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select variable 3", "0"));
        DropDownList5.DataSource = VariableliststartstartHurdleStep;
        DropDownList5.DataTextField = "Value";
        DropDownList5.DataValueField = "Key";
        DropDownList5.DataBind();
        DropDownList5.Items.Insert(0, new ListItem("Select variable 4", "0"));
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        // this.GridView1.DataSource = null;

        GridView1.Columns.Clear();
        GridView1.DataBind();
        //DropDownList1.Items.Clear();
        DropDownList2.Items.Clear();
        DropDownList3.Items.Clear();
        DropDownList4.Items.Clear();
        DropDownList5.Items.Clear();
        // DropDownList6.Items.Clear();
        int EventSelect = Convert.ToInt16(DropDownList1.SelectedValue);
        if (EventSelect == 2)
        {
            SprintVariableListInInial(EventSelect);
        }
        else if (EventSelect == 1)
        {
            StartVariableListIninial(EventSelect);
        }
        else if (EventSelect == 3)
        {
            HurdleVariableListIninial(EventSelect);
        }
        else if (EventSelect == 6)
        {
            HurdleStepVariableListIninial(EventSelect);
        }
    }

    public class CustomDropDownList
    {
        public string Svalue { get; set; }
        public string Fullname { get; set; }
        public string LessonLocation { get; set; }
        public string DropDownList2 { get; set; }
        public string DropDownList3 { get; set; }
        public string DropDownList4 { get; set; }
        public string DropDownList5 { get; set; }
        public string DropDownList6 { get; set; }
        public string Gvalue { get; set; }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);

        List<CustomDropDownList> DropDownList = new List<CustomDropDownList>();

        int DropDownkey1 = Convert.ToInt32(DropDownList1.SelectedValue);
        var DropDownkey2 = Convert.ToString(DropDownList2.SelectedValue);
        var DropDownkey3 = Convert.ToString(DropDownList3.SelectedValue);
        var DropDownkey4 = Convert.ToString(DropDownList4.SelectedValue);
        var DropDownkey5 = Convert.ToString(DropDownList5.SelectedValue);
        var DropDownkey6 = Convert.ToInt32(DropDownList6.SelectedValue);


        //if (DropDownkey2 != "0" && DropDownkey3 != "0" && DropDownkey4 != "0" && DropDownkey5 != "0")
        //{
        DataTable dtathlets1 = _sprintAthleteEdit.GetAllAthleteSessonData(DropDownkey1);
        DataTable datatablelessionID = new DataTable();
        DataTable datatable = new DataTable();
        bool abc = false;
        if (dtathlets1 != null)
        {
            for (int i = 0; i < dtathlets1.Rows.Count; i++)
            {
                abc = false;

                int SessionLessionID = Convert.ToUInt16(dtathlets1.Rows[i]["LessonId"]);
                string SessionLessionLocation = dtathlets1.Rows[i]["LessonLocation"].ToString();
                int mType = Convert.ToUInt16(dtathlets1.Rows[i]["MovieType"]);
                string mylist = SessionLessionLocation.Split('-').Last();


                if (DropDownkey1 == 2) //-------------------Sprint
                {
                    if (DropDownkey6 == 1 && SessionLessionLocation.Contains("Initial") && !SessionLessionLocation.Contains('(')) //--------initial
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllSprintAthletesDataInital(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 2) //---------Model
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllSprintAthletesDataModel(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 3 && SessionLessionLocation.Contains("Final") && !SessionLessionLocation.Contains('(')) //------Final
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllSprintAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 4 && SessionLessionLocation.Contains('(')) //----------Competition
                    {
                       // datatablelessionID = _sprintAthleteEdit.GetAllSprintAthletesDataModel(SessionLessionID, mType);
                        datatablelessionID = _sprintAthleteEdit.GetAllSprintAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                }
                else if (DropDownkey1 == 3) //---------------------------Hurdle
                {
                    if (DropDownkey6 == 1 && SessionLessionLocation.Contains("Initial") && !SessionLessionLocation.Contains('(')) //--------initial
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleAthletesDataIntial(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 2)
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleAthletesDataModel(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 3 && SessionLessionLocation.Contains("Final") && !SessionLessionLocation.Contains('(')) //------Final
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 4 && SessionLessionLocation.Contains('(')) //----------Competition
                    {
                        //datatablelessionID = _sprintAthleteEdit.GetAllHurdleAthletesDataModel(SessionLessionID, mType);
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                }
                else if (DropDownkey1 == 1) //------------------------Start
                {
                    if (DropDownkey6 == 1 && SessionLessionLocation.Contains("Initial") && !SessionLessionLocation.Contains('(')) //--------initial
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllStartAthletesDataInitial(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 2)
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllStartAthletesDataModel(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 3 && SessionLessionLocation.Contains("Final") && !SessionLessionLocation.Contains('(')) //------Final
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllStartAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 4 && SessionLessionLocation.Contains('(')) //----------Competition
                    {
                        //datatablelessionID = _sprintAthleteEdit.GetAllStartAthletesDataModel(SessionLessionID, mType);
                        datatablelessionID = _sprintAthleteEdit.GetAllStartAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                }
                else if (DropDownkey1 == 6) //--------------------------Hurdle Step
                {
                    if (DropDownkey6 == 1 && SessionLessionLocation.Contains("Initial") && !SessionLessionLocation.Contains('(')) //--------initial
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleStepAthletesDataInitial(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 2)
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleStepAthletesDataModel(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 3 && SessionLessionLocation.Contains("Final") && !SessionLessionLocation.Contains('(')) //------Final
                    {
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleStepAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                    else if (DropDownkey6 == 4 && SessionLessionLocation.Contains('(')) //----------Competition
                    {
                        //datatablelessionID = _sprintAthleteEdit.GetAllHurdleStepAthletesDataModel(SessionLessionID, mType);
                        datatablelessionID = _sprintAthleteEdit.GetAllHurdleStepAthletesDataFinal(SessionLessionID, mType);
                        abc = true;
                    }
                }
                if (abc == true)
                {
                    foreach (DataRow row in datatablelessionID.Rows)
                    {
                        CustomDropDownList CustomDropDownobj = new CustomDropDownList(); //LessonLocation
                        var loc = Convert.ToString(row["LessonLocation"]);
                        if (loc != "" && loc != null)
                        {
                            //CustomDropDownobj.Gvalue = Convert.ToString(row["Gender"]);
                            var Gender = Convert.ToString(row["Gender"]);
                            var LessonId = Convert.ToString(row["LessonId"]);
                            var dr = dtathlets1.Select("LessonId = " + LessonId);
                            if (DropDownkey2 != "0.000" && DropDownkey2 != "0" && DropDownkey2 != "" && DropDownkey2 != null)
                            {
                                CustomDropDownobj.DropDownList2 = Convert.ToString(row[DropDownkey2]);
                            }
                            if (DropDownkey3 != "0.000" && DropDownkey3 != "0" && DropDownkey3 != "" && DropDownkey3 != null)
                            {
                                CustomDropDownobj.DropDownList3 = Convert.ToString(row[DropDownkey3]);
                            }
                            if (DropDownkey4 != "0.000" && DropDownkey4 != "0" && DropDownkey4 != "" && DropDownkey4 != null)
                            {
                                CustomDropDownobj.DropDownList4 = Convert.ToString(row[DropDownkey4]);
                            }
                            if (DropDownkey5 != "0.000" && DropDownkey5 != "0" && DropDownkey5 != "" && DropDownkey5 != null)
                            {
                                CustomDropDownobj.DropDownList5 = Convert.ToString(row[DropDownkey5]);
                            }
                            if (DropDownkey6 == 1)
                            { 
                                // I
                                CustomDropDownobj.Svalue = "I";
                            }
                            if (DropDownkey6 == 2)
                            {
                                // M   
                                CustomDropDownobj.Svalue = "M";
                            }
                            if (DropDownkey6 == 3)
                            {
                                //F
                                CustomDropDownobj.Svalue = "F";
                            }
                            if (DropDownkey6 == 4)
                            {
                                //C
                                CustomDropDownobj.Svalue = "C";
                            }


                            CustomDropDownobj.Fullname = Convert.ToString(row["Fullname"]);
                            CustomDropDownobj.LessonLocation = Convert.ToString(row["LessonLocation"]);
                            if (Gender == "Male")
                            {
                                CustomDropDownobj.Gvalue = "M";
                            }
                            else if(Gender == "Female")
                            {
                                CustomDropDownobj.Gvalue = "W";
                            }
                            DropDownList.Add(CustomDropDownobj);
                        }
                    }
                    //CustomDropDownobj.Fullname = Convert.ToString(dr[0]["Fullname"]);
                    //CustomDropDownobj.LessonLocation = Convert.ToString(dr[0]["LessonLocation"]);
                }
            }
        }
        GridView1.DataSource = DropDownList;
        GridView1.DataBind();
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        var EventSelect2 = Convert.ToString(DropDownList2.SelectedValue);
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        var EventSelect3 = Convert.ToString(DropDownList3.SelectedValue);
    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        var EventSelect4 = Convert.ToString(DropDownList4.SelectedValue);
    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        var EventSelect5 = Convert.ToString(DropDownList5.SelectedValue);
    }
    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
    {
        var TableSelect = Convert.ToString(DropDownList6.SelectedValue);
    }
}