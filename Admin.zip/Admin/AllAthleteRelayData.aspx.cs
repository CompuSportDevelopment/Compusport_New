﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using SwingModel.Data;
using System.IO;
using SwingModel.Entities;
using System.Collections.Generic;
using System.Data.SqlClient;
using CompuSportDAL;
using System.Web.Configuration;



public partial class Admin_AllAthleteRelayData : System.Web.UI.Page
{
    SqlConnection sconn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    SqlCommand cmd1, cmd2, cmd3, cmd4;
    //List<string> l1 = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            DropDownListAthlete();

            ViewState["dd1Name"] = "";
            ViewState["dd2Name"] = "";
            ViewState["dd3Name"] = "";
            ViewState["dd4Name"] = "";

            ViewState["dd1Name1"] = "";
            ViewState["dd1Name2"] = "";
            ViewState["dd1Name3"] = "";
            ViewState["dd1Name4"] = "";

            ViewState["dd2Name1"] = "";
            ViewState["dd2Name2"] = "";
            ViewState["dd2Name3"] = "";
            ViewState["dd2Name4"] = "";

            ViewState["dd3Name1"] = "";
            ViewState["dd3Name2"] = "";
            ViewState["dd3Name3"] = "";
            ViewState["dd3Name4"] = "";

            ViewState["dd4Name1"] = "";
            ViewState["dd4Name2"] = "";
            ViewState["dd4Name3"] = "";
            ViewState["dd4Name4"] = "";

            ViewState["Final1"] = "";

            ViewState["ThirdTableResult1"] = "";
            ViewState["ThirdTableResult2"] = "";
            ViewState["ThirdTableResult3"] = "";
            ViewState["ThirdTableResult4"] = "";
            ViewState["ThirdTableResult5"] = "";
            ViewState["ThirdTableResult6"] = "";
            ViewState["ThirdTableResult7"] = "";

            ViewState["FinalResult"] = "";

            ViewState["Final2"] = "";
            ViewState["Final3"] = "";

            ViewState["dd1"] = "";
            ViewState["dd2"] = "";
            ViewState["dd3"] = "";
            ViewState["dd4"] = "";


            ViewState["dd1PassComplete"] = "";
            ViewState["ddlPassTime"] = "";


            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
            DropDownList5.Enabled = false;

            DropDownList6.Enabled = false;
            DropDownList7.Enabled = false;
        }
    }
    protected void DropDownListAthlete()
    {
        DataSet ds = new DataSet();


        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString()))
        {
            con.Open();


            SqlDataAdapter da = new SqlDataAdapter("GenderIdentify_allathlete", con);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@gender", DropDownList1.SelectedItem.Value.ToString());
            da.SelectCommand.Parameters.AddWithValue("@cutomerId", DropDownList1.DataValueField.ToString());
            da.Fill(ds);


            DropDownList4.DataSource = ds;
            DropDownList4.DataValueField = "CustomerID";
            DropDownList4.DataTextField = "FirstName";
            DropDownList4.DataBind();
            DropDownList4.Items.Insert(0, new ListItem("Select An Athlete", "0"));


            DropDownList5.DataSource = ds;
            DropDownList5.DataValueField = "CustomerID";
            DropDownList5.DataTextField = "FirstName";
            DropDownList5.DataBind();
            DropDownList5.Items.Insert(0, new ListItem("Select An Athlete", "0"));



            DropDownList6.DataSource = ds;
            DropDownList6.DataValueField = "CustomerID";
            DropDownList6.DataTextField = "FirstName";
            DropDownList6.DataBind();
            DropDownList6.Items.Insert(0, new ListItem("Select An Athlete", "0"));


            DropDownList7.DataSource = ds;
            DropDownList7.DataValueField = "CustomerID";
            DropDownList7.DataTextField = "FirstName";
            DropDownList7.DataBind();
            DropDownList7.Items.Insert(0, new ListItem("Select An Athlete", "0"));

            con.Close();
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex != 0)
        {
            DropDownList2.Enabled = true;
            DropDownList3.Enabled = true;
            DropDownList4.Enabled = true;
            DropDownList5.Enabled = true;
            DropDownList6.Enabled = true;
            DropDownList7.Enabled = true;

            DropDownListAthlete();

            ViewState["dd1Name"] = "";
            ViewState["dd2Name"] = "";
            ViewState["dd3Name"] = "";
            ViewState["dd4Name"] = "";

            ViewState["dd1Name1"] = "";
            ViewState["dd1Name2"] = "";
            ViewState["dd1Name3"] = "";
            ViewState["dd1Name4"] = "";

            ViewState["dd2Name1"] = "";
            ViewState["dd2Name2"] = "";
            ViewState["dd2Name3"] = "";
            ViewState["dd2Name4"] = "";

            ViewState["dd3Name1"] = "";
            ViewState["dd3Name2"] = "";
            ViewState["dd3Name3"] = "";
            ViewState["dd3Name4"] = "";

            ViewState["dd4Name1"] = "";
            ViewState["dd4Name2"] = "";
            ViewState["dd4Name3"] = "";
            ViewState["dd4Name4"] = "";

            //ViewState[""] = "";

            ViewState["ThirdTableResult1"] = "";
            ViewState["ThirdTableResult2"] = "";
            ViewState["ThirdTableResult3"] = "";
            ViewState["ThirdTableResult4"] = "";
            ViewState["ThirdTableResult5"] = "";
            ViewState["ThirdTableResult6"] = "";
            ViewState["ThirdTableResult7"] = "";

            ViewState["Final1"] = "";

            ViewState["Final2"] = "";
            ViewState["Final3"] = "";

            ViewState["FinalResult"] = "";

            ViewState["dd1"] = "";
            ViewState["dd2"] = "";
            ViewState["dd3"] = "";
            ViewState["dd4"] = "";


            ViewState["dd1PassComplete"] = "";
            ViewState["ddlPassTime"] = "";

        }
        else
        {
            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
            DropDownList5.Enabled = false;
            DropDownList6.Enabled = false;
            DropDownList7.Enabled = false;
        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.SelectedItem.Value == "0")
        {
            ViewState["dd1PassComplete"] = "10";
        }
        else
        {
            ViewState["dd1PassComplete"] = DropDownList2.SelectedItem.Value;
        }
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.SelectedItem.Value == "0.4")
        {
            ViewState["ddlPassTime"] = "0.4";
        }
        else
        {
            ViewState["ddlPassTime"] = DropDownList3.SelectedItem.Value;
        }
    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["dd1"] = DropDownList4.SelectedItem.Value;
        ViewState["dd1Name"] = DropDownList4.SelectedItem.Text;

        string selecteditem = DropDownList4.SelectedItem.Text;

        for (int i = DropDownList5.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList5.Items[i].Text == selecteditem)
                DropDownList5.Items.RemoveAt(i);
        }
        for (int i = DropDownList6.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList6.Items[i].Text == selecteditem)
                DropDownList6.Items.RemoveAt(i);
        }
        for (int i = DropDownList7.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList7.Items[i].Text == selecteditem)
                DropDownList7.Items.RemoveAt(i);
        }
    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["dd2"] = DropDownList5.SelectedItem.Value;
        ViewState["dd2Name"] = DropDownList5.SelectedItem.Text;

        string selectedItem = DropDownList5.SelectedItem.Text;

        for (int i = DropDownList4.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList4.Items[i].Text == selectedItem)
                DropDownList4.Items.RemoveAt(i);
        }

        for (int i = DropDownList6.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList6.Items[i].Text == selectedItem)
                DropDownList6.Items.RemoveAt(i);
        }
        for (int i = DropDownList7.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList7.Items[i].Text == selectedItem)
                DropDownList7.Items.RemoveAt(i);
        }


    }
    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
    {

        ViewState["dd3"] = DropDownList6.SelectedItem.Value;
        ViewState["dd3Name"] = DropDownList6.SelectedItem.Text;


        string selectedItem = DropDownList6.SelectedItem.Text;

        for (int i = DropDownList4.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList4.Items[i].Text == selectedItem)
                DropDownList4.Items.RemoveAt(i);
        }
        for (int i = DropDownList5.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList5.Items[i].Text == selectedItem)
                DropDownList5.Items.RemoveAt(i);
        }
        for (int i = DropDownList7.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList7.Items[i].Text == selectedItem)
                DropDownList7.Items.RemoveAt(i);
        }

    }
    protected void DropDownList7_SelectedIndexChanged(object sender, EventArgs e)
    {

        ViewState["dd4"] = DropDownList7.SelectedItem.Value;
        ViewState["dd4Name"] = DropDownList7.SelectedItem.Text;


        string selectedItem = DropDownList7.SelectedItem.Text;

        for (int i = DropDownList4.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList4.Items[i].Text == selectedItem)
                DropDownList4.Items.RemoveAt(i);
        }

        for (int i = DropDownList5.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList5.Items[i].Text == selectedItem)
                DropDownList5.Items.RemoveAt(i);
        }
        for (int i = DropDownList6.Items.Count - 1; i >= 0; i--)
        {
            if (DropDownList6.Items[i].Text == selectedItem)
                DropDownList6.Items.RemoveAt(i);
        }
    }
    protected void buttonSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string connection = ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString;
            {
                using (SqlConnection scon = new SqlConnection(connection))
                {
                    scon.Open();
                    SqlCommand scmdInsert = new SqlCommand("Insert_into_AthleteRelay", scon);
                    scmdInsert.CommandType = CommandType.StoredProcedure;
                    scmdInsert.Parameters.AddWithValue("@Relay", DropDownList1.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@PassCompletionPosition", DropDownList2.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@PassTimeQuality", DropDownList3.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@FirstAthleteName", DropDownList4.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@SecondAthleteName", DropDownList5.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@ThirdAthleteName", DropDownList6.SelectedItem.Text);
                    scmdInsert.Parameters.AddWithValue("@FourthAthleteName", DropDownList7.SelectedItem.Text);
                    scmdInsert.ExecuteNonQuery();
                    scon.Close();

                }
            }
        }
        sconn.Open();

        if (DropDownList1.SelectedValue != "0")
        {

            if ((DropDownList4.SelectedIndex > 0) && (DropDownList5.SelectedIndex > 0) && (DropDownList6.SelectedIndex > 0) && (DropDownList7.SelectedIndex > 0))
            {
                SqlDataReader dr1, dr2, dr3, dr4;
                cmd1 = new SqlCommand("select * from Input_RelayData where CustomerID = '" + Convert.ToInt32(ViewState["dd1"].ToString()) + "'", sconn);
                cmd2 = new SqlCommand("select * from Input_RelayData where CustomerID = '" + Convert.ToInt32(ViewState["dd2"].ToString()) + "'", sconn);
                cmd3 = new SqlCommand("select * from Input_RelayData where CustomerID = '" + Convert.ToInt32(ViewState["dd3"].ToString()) + "'", sconn);
                cmd4 = new SqlCommand("select * from Input_RelayData where CustomerID = '" + Convert.ToInt32(ViewState["dd4"].ToString()) + "'", sconn);

                dr1 = cmd1.ExecuteReader();


                dr1.Read();

                ViewState["dd1Name1"] = dr1.GetDecimal(1);
                ViewState["dd1Name2"] = dr1.GetDecimal(2);
                ViewState["dd1Name3"] = dr1.GetDecimal(3);
                ViewState["dd1Name4"] = dr1.GetDecimal(4);
                dr1.Close();

                dr2 = cmd2.ExecuteReader();


                dr2.Read();

                ViewState["dd2Name1"] = dr2.GetDecimal(1);
                ViewState["dd2Name2"] = dr2.GetDecimal(2);
                ViewState["dd2Name3"] = dr2.GetDecimal(3);
                ViewState["dd2Name4"] = dr2.GetDecimal(4);
                dr2.Close();

                dr3 = cmd3.ExecuteReader();

                dr3.Read();

                ViewState["dd3Name1"] = dr3.GetDecimal(1);
                ViewState["dd3Name2"] = dr3.GetDecimal(2);
                ViewState["dd3Name3"] = dr3.GetDecimal(3);
                ViewState["dd3Name4"] = dr3.GetDecimal(4);
                dr3.Close();


                dr4 = cmd4.ExecuteReader();


                dr4.Read();

                ViewState["dd4Name1"] = dr4.GetDecimal(1);
                ViewState["dd4Name2"] = dr4.GetDecimal(2);
                ViewState["dd4Name3"] = dr4.GetDecimal(3);
                ViewState["dd4Name4"] = dr4.GetDecimal(4);
                dr4.Close();



                /////////////////////////////////////////////////////////////////
                string demo1, demo2;

                if (DropDownList2.SelectedItem.Value == "10")
                    demo1 = "10";
                else
                {
                    ViewState["dd1PassComplete"] = DropDownList2.SelectedValue;
                    demo1 = DropDownList2.SelectedValue;
                }
                if (DropDownList3.SelectedItem.Value == "0.4")

                    demo2 = "0.4";
                else
                {
                    ViewState["ddlPassTime"] = DropDownList3.SelectedValue;
                    demo2 = DropDownList3.SelectedValue;
                }

                /*Formula for GoLine Column in Second Table */
                // Formula for First Exchange:

                ViewState["temp1"] = ((Convert.ToDecimal(ViewState["dd2Name3"].ToString()) * Convert.ToDecimal("0.95")) - Convert.ToDecimal(demo2.ToString()));
                ViewState["temp2"] = ((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / ((Convert.ToDecimal(ViewState["dd2Name2"].ToString()) + (Convert.ToDecimal(ViewState["dd2Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));
                ViewState["temp3"] = ((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())) * (Convert.ToDecimal(ViewState["dd1Name1"].ToString())));
                ViewState["temp4"] = (Convert.ToDecimal(demo2.ToString()) * (((Convert.ToDecimal(ViewState["dd2Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10")))) + (Convert.ToDecimal(ViewState["dd2Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00") - (Convert.ToDecimal(demo2.ToString()) * Convert.ToDecimal(ViewState["dd2Name2"].ToString()))) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));

                ViewState["Final1"] = Math.Round((Convert.ToDecimal(ViewState["temp3"].ToString()) + Convert.ToDecimal(ViewState["temp4"].ToString()) - (Convert.ToDecimal("10.00") + Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("1.00"))), 2);
             
                //ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("10"));
                //ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd2Name2"].ToString()));
                ////ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                ////   Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////   Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name2"].ToString()));
                
                //ViewState["temp3"] = (Convert.ToDecimal(ViewState["temp1"].ToString()) / Convert.ToDecimal(ViewState["temp2"].ToString()));
                //ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd2Name3"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));
                ////ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd4Name2"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));

                //ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd1Name1"].ToString()));
                ////ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd2Name1"].ToString()));

                //ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd2Name2"].ToString()));
                ////ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) + Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name2"].ToString()));
                
                //ViewState["temp6"] = (Convert.ToDecimal(DropDownList3.SelectedValue.ToString()) * Convert.ToDecimal(ViewState["temp5"].ToString()));
                //ViewState["Equ2"] = (Convert.ToDecimal("10") + Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1") - Convert.ToDecimal(ViewState["temp6"].ToString()));

                //ViewState["Final1"] = Math.Round((Convert.ToDecimal(ViewState["Equ1"].ToString()) - Convert.ToDecimal(ViewState["Equ2"].ToString())), 2);

                //Formula For Second Exchange:

                ViewState["temp1"] = ((Convert.ToDecimal(ViewState["dd3Name3"].ToString()) * Convert.ToDecimal("0.95")) - Convert.ToDecimal(demo2.ToString()));
                ViewState["temp2"] = ((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / ((Convert.ToDecimal(ViewState["dd3Name2"].ToString()) + (Convert.ToDecimal(ViewState["dd3Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));
                ViewState["temp3"] = ((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())) * (Convert.ToDecimal(ViewState["dd2Name1"].ToString())));
                ViewState["temp4"] = (Convert.ToDecimal(demo2.ToString()) * (((Convert.ToDecimal(ViewState["dd3Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10")))) + (Convert.ToDecimal(ViewState["dd3Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00") - (Convert.ToDecimal(demo2.ToString()) * Convert.ToDecimal(ViewState["dd3Name2"].ToString()))) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));

                ViewState["Final2"] = Math.Round((Convert.ToDecimal(ViewState["temp3"].ToString()) + Convert.ToDecimal(ViewState["temp4"].ToString()) - (Convert.ToDecimal("10.00") + Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("1.00"))), 2);

                //ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("10"));
                //ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name2"].ToString()));
                ////ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                ////    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name3"].ToString()));
                
                //ViewState["temp3"] = (Convert.ToDecimal(ViewState["temp1"].ToString()) / Convert.ToDecimal(ViewState["temp2"].ToString()));
                //ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd3Name3"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));
                ////ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd4Name3"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));

                //ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd2Name1"].ToString()));
                ////ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd2Name2"].ToString()));

                //ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name2"].ToString()));
                ////ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) + Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name3"].ToString()));
                
                //ViewState["temp6"] = (Convert.ToDecimal(DropDownList3.SelectedValue.ToString()) * Convert.ToDecimal(ViewState["temp5"].ToString()));
                //ViewState["Equ2"] = (Convert.ToDecimal("10") + Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1") - Convert.ToDecimal(ViewState["temp6"].ToString()));
                //ViewState["Final2"] = Math.Round((Convert.ToDecimal(ViewState["Equ1"].ToString()) - Convert.ToDecimal(ViewState["Equ2"].ToString())), 2);

              //Formula For Third Exchange:

                ViewState["temp1"] = ((Convert.ToDecimal(ViewState["dd4Name3"].ToString()) * Convert.ToDecimal("0.95")) - Convert.ToDecimal(demo2.ToString()));
                ViewState["temp2"] = ((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / ((Convert.ToDecimal(ViewState["dd4Name2"].ToString()) + (Convert.ToDecimal(ViewState["dd4Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));
                ViewState["temp3"] = ((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())) * (Convert.ToDecimal(ViewState["dd3Name1"].ToString())));
                ViewState["temp4"] = (Convert.ToDecimal(demo2.ToString()) * (((Convert.ToDecimal(ViewState["dd4Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00")) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10")))) + (Convert.ToDecimal(ViewState["dd4Name2"].ToString()) * (Convert.ToDecimal("1.00") + (((Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("10.00") - (Convert.ToDecimal(demo2.ToString()) * Convert.ToDecimal(ViewState["dd4Name2"].ToString()))) / Convert.ToDecimal("10.00")) * Convert.ToDecimal("0.10"))))) / Convert.ToDecimal("2.0")));

                ViewState["Final3"] = Math.Round((Convert.ToDecimal(ViewState["temp3"].ToString()) + Convert.ToDecimal(ViewState["temp4"].ToString()) - (Convert.ToDecimal("10.00") + Convert.ToDecimal(demo1.ToString()) - Convert.ToDecimal("1.00"))), 2);

                //ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("10"));
                //ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd4Name2"].ToString()));
                ////ViewState["temp2"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                ////    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name4"].ToString()));
                
                //ViewState["temp3"] = (Convert.ToDecimal(ViewState["temp1"].ToString()) / Convert.ToDecimal(ViewState["temp2"].ToString()));
                //ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd4Name3"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));
                ////ViewState["temp4"] = (Convert.ToDecimal(ViewState["dd4Name4"].ToString()) + Convert.ToDecimal(ViewState["temp3"].ToString()) - Convert.ToDecimal(DropDownList3.SelectedValue.ToString()));

                //ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd3Name1"].ToString()));
                ////ViewState["Equ1"] = (Convert.ToDecimal(ViewState["temp4"].ToString()) * Convert.ToDecimal(ViewState["dd2Name3"].ToString()));

                //ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) +
                //    Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd4Name2"].ToString()));
                ////ViewState["temp5"] = ((((((Convert.ToDecimal("1.182") * Convert.ToDecimal(DropDownList2.SelectedValue.ToString())) + Convert.ToDecimal("11.82")) / Convert.ToDecimal("2")) + Convert.ToDecimal("90.373")) /
                ////    Convert.ToDecimal("100")) * Convert.ToDecimal(ViewState["dd3Name4"].ToString()));
                
                //ViewState["temp6"] = (Convert.ToDecimal(DropDownList3.SelectedValue.ToString()) * Convert.ToDecimal(ViewState["temp5"].ToString()));
                //ViewState["Equ2"] = (Convert.ToDecimal("10") + Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1") - Convert.ToDecimal(ViewState["temp6"].ToString()));
                //ViewState["Final3"] = Math.Round((Convert.ToDecimal(ViewState["Equ1"].ToString()) - Convert.ToDecimal(ViewState["Equ2"].ToString())), 2);

                /*==============================================================================================================================*/

                ViewState["ThirdTableResult1"] = Math.Round(((Convert.ToDecimal(ViewState["dd1Name4"].ToString()) * Convert.ToDecimal("1.02")) - ((Convert.ToDecimal("10.0")) / ((Convert.ToDecimal(ViewState["dd1Name1"].ToString())) * Convert.ToDecimal("1.02") * Convert.ToDecimal("0.98")))), 2);//2% Competition Boost, 2% decrement due to curve

                ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1.00")) / (Convert.ToDecimal(ViewState["dd1Name1"].ToString()) * Convert.ToDecimal("1.00"));//No Competition Boost due to fatigue
                ViewState["temp2"] = (Convert.ToDecimal("20.0") - (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()))) / (((((Convert.ToDecimal("0.94") + ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) / Convert.ToDecimal("20.0")) * Convert.ToDecimal("0.12"))) * Convert.ToDecimal(ViewState["dd2Name2"].ToString())) + (Convert.ToDecimal(ViewState["dd2Name1"].ToString()) * Convert.ToDecimal("0.95"))) / Convert.ToDecimal("2.0")) * (Convert.ToDecimal("1.05")));//With 5% Competition Boost
                ViewState["ThirdTableResult2"] = Math.Round((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())), 2);
                
                //ViewState["temp2"] = ((((Convert.ToDecimal("1.182") * ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) +
                //    Convert.ToDecimal("20.00")) / Convert.ToDecimal("2"))) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * (Convert.ToDecimal(ViewState["dd2Name2"].ToString()) * (Convert.ToDecimal("1.05"))));
                //ViewState["ThirdTableResult2"] = Math.Round((((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (((Convert.ToDecimal(ViewState["dd1Name1"].ToString())) * (Convert.ToDecimal("1.05"))) * (Convert.ToDecimal("0.98"))))
                //    + ((Convert.ToDecimal("20.00") - Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (Convert.ToDecimal(ViewState["temp2"].ToString())))), 2);

                ViewState["ThirdTableResult3"] = Math.Round(((Convert.ToDecimal("80.0")) / (Convert.ToDecimal(ViewState["dd2Name1"].ToString()) * Convert.ToDecimal("1.02"))), 2);//2% Competition Boost

                ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1.00")) / (Convert.ToDecimal(ViewState["dd2Name1"].ToString()) * Convert.ToDecimal("1.00"));//No Competition Boost due to fatigue
                ViewState["temp2"] = (Convert.ToDecimal("20.0") - (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()))) / (((((Convert.ToDecimal("0.94") + ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) / Convert.ToDecimal("20.0")) * Convert.ToDecimal("0.12"))) * Convert.ToDecimal(ViewState["dd3Name2"].ToString())) + (Convert.ToDecimal(ViewState["dd3Name1"].ToString()) * Convert.ToDecimal("0.95"))) / Convert.ToDecimal("2.0")) * (Convert.ToDecimal("1.05")));//With 5% Competition Boost
                ViewState["ThirdTableResult4"] = Math.Round((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())), 2);
                
                //ViewState["temp2"] = ((((Convert.ToDecimal("1.182") * ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) +
                //    Convert.ToDecimal("20.00")) / Convert.ToDecimal("2"))) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * (Convert.ToDecimal(ViewState["dd3Name2"].ToString()) * (Convert.ToDecimal("1.07"))));
                //ViewState["ThirdTableResult4"] = Math.Round((((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (((Convert.ToDecimal(ViewState["dd2Name1"].ToString())) * (Convert.ToDecimal("1.05"))) * (Convert.ToDecimal("0.98"))))
                //    + ((Convert.ToDecimal("20.00") - Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (Convert.ToDecimal(ViewState["temp2"].ToString())))), 2);

                ViewState["ThirdTableResult5"] = Math.Round((Convert.ToDecimal("80.0") / (Convert.ToDecimal(ViewState["dd3Name1"].ToString()) * Convert.ToDecimal("1.02") * Convert.ToDecimal("0.98"))), 2);//2% Competition Boost, 2% decrement due to curve

                ViewState["temp1"] = (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("1.00")) / (Convert.ToDecimal(ViewState["dd3Name1"].ToString()) * Convert.ToDecimal("1.00"));//No Competition Boost due to fatigue
                ViewState["temp2"] = (Convert.ToDecimal("20.0") - (Convert.ToDecimal(DropDownList2.SelectedValue.ToString()))) / (((((Convert.ToDecimal("0.94") + ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) / Convert.ToDecimal("20.0")) * Convert.ToDecimal("0.12"))) * Convert.ToDecimal(ViewState["dd4Name2"].ToString())) + (Convert.ToDecimal(ViewState["dd4Name1"].ToString()) * Convert.ToDecimal("0.95"))) / Convert.ToDecimal("2.0")) * (Convert.ToDecimal("1.05")));//With 5% Competition Boost
                ViewState["ThirdTableResult6"] = Math.Round((Convert.ToDecimal(ViewState["temp1"].ToString()) + Convert.ToDecimal(ViewState["temp2"].ToString())), 2);

                //ViewState["temp2"] = ((((Convert.ToDecimal("1.182") * ((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) +
                //    Convert.ToDecimal("20.00")) / Convert.ToDecimal("2"))) + Convert.ToDecimal("90.373")) /
                //    Convert.ToDecimal("100")) * (Convert.ToDecimal(ViewState["dd4Name2"].ToString()) * (Convert.ToDecimal("1.05"))));
                //ViewState["ThirdTableResult6"] = Math.Round((((Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (((Convert.ToDecimal(ViewState["dd3Name1"].ToString())) * (Convert.ToDecimal("1.05"))) * (Convert.ToDecimal("0.98"))))
                //    + ((Convert.ToDecimal("20.00") - Convert.ToDecimal(DropDownList2.SelectedValue.ToString()) - Convert.ToDecimal("0.5")) / (Convert.ToDecimal(ViewState["temp2"].ToString())))), 2);

                ViewState["ThirdTableResult7"] = Math.Round((Convert.ToDecimal("90.0") / (Convert.ToDecimal(ViewState["dd4Name1"].ToString()) * Convert.ToDecimal("1.02"))), 2);//2% Competition Boost 

                //ViewState["ThirdTableResult2"] = Math.Round(((Convert.ToDecimal("9.4") / Convert.ToDecimal(ViewState["dd1Name1"].ToString())) + (Convert.ToDecimal("9.4") / ((Convert.ToDecimal(ViewState["dd2Name1"].ToString()) + Convert.ToDecimal(ViewState["dd2Name2"].ToString())) / Convert.ToDecimal("2")))), 2);
                //ViewState["ThirdTableResult3"] = Math.Round(((Convert.ToDecimal("80.0")) / Convert.ToDecimal(ViewState["dd2Name1"].ToString())) * Convert.ToDecimal("1.02"), 2);
                //ViewState["ThirdTableResult4"] = Math.Round(((Convert.ToDecimal("9.4")) / Convert.ToDecimal(ViewState["dd2Name1"].ToString())) + ((Convert.ToDecimal("9.4")) / (((Convert.ToDecimal(ViewState["dd3Name1"].ToString())) + (Convert.ToDecimal(ViewState["dd3Name2"].ToString()))) / Convert.ToDecimal("2"))), 2);
                //ViewState["ThirdTableResult5"] = Math.Round(((Convert.ToDecimal("80.0") / Convert.ToDecimal(ViewState["dd3Name1"].ToString())) * Convert.ToDecimal("1.04")), 2);
                //ViewState["ThirdTableResult6"] = Math.Round(((Convert.ToDecimal("9.4")) / Convert.ToDecimal(ViewState["dd3Name1"].ToString())) + ((Convert.ToDecimal("9.4")) / (((Convert.ToDecimal(ViewState["dd4Name1"].ToString())) + (Convert.ToDecimal(ViewState["dd4Name2"].ToString()))) / Convert.ToDecimal("2"))), 2);
                //ViewState["ThirdTableResult7"] = Math.Round(((Convert.ToDecimal("90.0") / Convert.ToDecimal(ViewState["dd4Name1"].ToString())) * Convert.ToDecimal("1.02")), 2);

                ViewState["FinalResult"] = (Convert.ToDecimal(ViewState["ThirdTableResult1"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult2"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult3"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult4"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult5"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult6"]) +
                                            Convert.ToDecimal(ViewState["ThirdTableResult7"]));


                ViewState["dd1PassComplete"] = DropDownList2.SelectedItem.Value;
                ViewState["ddlPassTime"] = DropDownList3.SelectedItem.Value;


                DropDownList2.Enabled = false;
                DropDownList3.Enabled = false;
                DropDownList4.Enabled = false;
                DropDownList5.Enabled = false;
                DropDownList6.Enabled = false;
                DropDownList7.Enabled = false;
            }
            else
            {
                ViewState["dd1Name"] = "";
                ViewState["dd2Name"] = "";
                ViewState["dd3Name"] = "";
                ViewState["dd4Name"] = "";


                ViewState["dd1Name1"] = "";
                ViewState["dd1Name2"] = "";
                ViewState["dd1Name3"] = "";
                ViewState["dd1Name4"] = "";

                ViewState["dd2Name1"] = "";
                ViewState["dd2Name2"] = "";
                ViewState["dd2Name3"] = "";
                ViewState["dd2Name4"] = "";


                ViewState["dd3Name1"] = "";
                ViewState["dd3Name2"] = "";
                ViewState["dd3Name3"] = "";
                ViewState["dd3Name4"] = "";


                ViewState["dd4Name1"] = "";
                ViewState["dd4Name2"] = "";
                ViewState["dd4Name3"] = "";
                ViewState["dd4Name4"] = "";

                ViewState["FinalResult1"] = "";

                ViewState["ThirdTableResult1"] = "";
                ViewState["ThirdTableResult2"] = "";
                ViewState["ThirdTableResult3"] = "";
                ViewState["ThirdTableResult4"] = "";
                ViewState["ThirdTableResult5"] = "";
                ViewState["ThirdTableResult6"] = "";
                ViewState["ThirdTableResult7"] = "";

                ViewState["Final1"] = "";

                ViewState["Final2"] = "";
                ViewState["Final3"] = "";
                ViewState["FinalResult"] = "";


            }
            DropDownList1.SelectedIndex = 0;
            DropDownList2.SelectedIndex = 9;
            DropDownList3.SelectedIndex = 0;
            DropDownList4.SelectedIndex = 0;
            DropDownList5.SelectedIndex = 0;
            DropDownList6.SelectedIndex = 0;
            DropDownList7.SelectedIndex = 0;
        }
        sconn.Close();
    }
    protected void btndrop1_Click(object sender, EventArgs e)
    {
        if (DropDownList4.SelectedIndex != 0)
        {
            string selecteditem = DropDownList4.SelectedItem.Text;

            DropDownList4.SelectedIndex = 0;

            DropDownList5.Items.Add(selecteditem);

            DropDownList6.Items.Add(selecteditem);

            DropDownList7.Items.Add(selecteditem);
        }
        else
        {
            DropDownList4.SelectedIndex = 0;
        }
    }
    protected void btndrop2_Click(object sender, EventArgs e)
    {
        if (DropDownList5.SelectedIndex != 0)
        {
            string selecteditem = DropDownList5.SelectedItem.Text;


            DropDownList5.SelectedIndex = 0;


            DropDownList4.Items.Add(selecteditem);

            DropDownList6.Items.Add(selecteditem);

            DropDownList7.Items.Add(selecteditem);
        }
        else
        {
            DropDownList5.SelectedIndex = 0;
        }
    }
    protected void btndrop3_Click(object sender, EventArgs e)
    {
        if (DropDownList6.SelectedIndex != 0)
        {

            string selecteditem = DropDownList6.SelectedItem.Text;

            DropDownList6.SelectedIndex = 0;


            DropDownList4.Items.Add(selecteditem);

            DropDownList5.Items.Add(selecteditem);

            DropDownList7.Items.Add(selecteditem);
        }
        else
        {
            DropDownList6.SelectedIndex = 0;
        }
    }
    protected void btndrop4_Click(object sender, EventArgs e)
    {
        if (DropDownList7.SelectedIndex != 0)
        {

            string selecteditem = DropDownList7.SelectedItem.Text;

            DropDownList7.SelectedIndex = 0;


            DropDownList4.Items.Add(selecteditem);

            DropDownList5.Items.Add(selecteditem);

            DropDownList6.Items.Add(selecteditem);
        }
        else
        {
            DropDownList7.SelectedIndex = 0;
        }
    }
}