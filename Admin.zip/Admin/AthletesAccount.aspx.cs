﻿using System;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Data.SqlClient;

public partial class Admin_AthletesAccount : System.Web.UI.Page
{
    string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();

    Customer customerid;
    public CustomerProfile customerprofile;
    public CustomerProfile customer_profile;
    TList<Customer> customer = new TList<Customer>();
    public Customer cust;
    public Customer selectedCustomer;
    bool customerexists = false;
    bool customerprofileexists = false;
    int x;
    DataTable dt = new DataTable();
    CompuSportDAL.SprintAthleteEdit _sprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            customer = DataRepository.CustomerProvider.GetAll();
            customer.Sort("FirstName");
            foreach (var item in customer)
            {
                x++;
                ddlAthlete.Items.Add(item.FirstName + " " + item.LastName);
                ddlAthlete.Items[x].Value = item.CustomerId.ToString();
                continue;
            }
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
            FillControl();
        }
    }

    private void FillControl()
    {
        try
        {
            if (DropDownList2.SelectedValue.Equals("") || DropDownList2.SelectedValue.Equals(null))
            {
                TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();

                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("Select Country");
                DropDownList2.Items[0].Value = "0";
                DropDownList2.Items[0].Selected = false;
                x = 0;
                foreach (CountryLookup country in countries)
                {
                    x++;
                    DropDownList2.Items.Add(country.CountryName);
                    DropDownList2.Items[x].Value = country.CountryId.ToString();
                }
            }
            #region[CustomerSite DropDown]
            TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
            customersites.Sort("SiteName");
            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("Select Home Location");
            DropDownList3.Items[0].Value = "0";
            DropDownList3.Items[0].Selected = false;
            int x1 = 0;
            foreach (CustomerSite cs in customersites)
            {
                x1++;
                DropDownList3.Items.Add(cs.SiteName);
                DropDownList3.Items[x1].Value = cs.CustomerSiteId.ToString();
            }
            #region[gender dropdown]
            //  ddlGender.Items[0].Value = "0";
            ddlGender.Items.Clear();
            ddlGender.Items.Add("Select");
            ddlGender.Items.Add("Male");
            ddlGender.Items.Add("Female");
            ddlGender.Items[0].Selected = false;
            #endregion[gender dropdown]

            #endregion[CustomerSite DropDown]

            #region[Teacher DropDown]
            TList<Teacher> teacher = DataRepository.TeacherProvider.GetAll();
            teacher.Sort("FirstName");
            DropDownList4.Items.Clear();
            DropDownList4.Items.Add("Select Teacher");
            DropDownList4.Items[0].Value = "0";
            DropDownList4.Items[0].Selected = false;
            int x3 = 0;
            foreach (Teacher tas in teacher)
            {
                x3++;
                DropDownList4.Items.Add(tas.FirstName + " " + tas.LastName);
                DropDownList4.Items[x3].Value = tas.TeacherId.ToString();
            }
            #endregion[Teacher DropDown]

            #region[State Province]
            ddlState.Visible = true;
            TextBox8.Visible = false;
            ddlState.Items.Clear();
            ddlState.Items.Add("Select State/Province");
            ddlState.Items[0].Value = "0";
            x = 0;
            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetAll();
            foreach (StateProvince sp in states)
            {
                x++;
                ddlState.Items.Add(sp.StateProvinceName);
                ddlState.Items[x].Value = sp.StateProvinceAbbvr;
            }
            #endregion[State Province]
        }
        catch (Exception ex)
        {
        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        //customer.Country = Convert.ToInt16(DropDownList2.SelectedValue);
        //customer.State = "";
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region[oldecode]
        //sitechanged = true;
        //TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList3.SelectedValue));
        //Teacher teacher = new Teacher();

        //DropDownList4.Items.Clear();
        //DropDownList4.Items.Add("Select Teacher");
        //DropDownList4.Items[0].Value = "0";
        //DropDownList4.Items[0].Selected = false;
        //int x = 0;
        //foreach (TeacherSite tas in teachersatsite)
        //{
        //    x++;
        //    teacher = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
        //    DropDownList4.Items.Add(teacher.FirstName + " " + teacher.LastName);
        //    DropDownList4.Items[x].Value = teacher.TeacherId.ToString();
        //}
        //Label41.Visible = true;
        #endregion[oldecode]
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            customerexists = true;

            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            selectedCustomer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            try
            {
                customer_profile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];
                customerprofileexists = true;
            }
            catch
            {
                CustomerProfile _CustomerProfile = new CustomerProfile();
                customerprofileexists = false;
            }

            selectedCustomer.FirstName = txtFirstName.Text.Trim();
            selectedCustomer.LastName = TxtLastName.Text.Trim();
            selectedCustomer.Country = Convert.ToInt16(DropDownList2.SelectedValue);
            selectedCustomer.Address1 = txtAddressFirst.Text.Trim();
            selectedCustomer.Address2 = txtAddressSecond.Text.Trim();
            selectedCustomer.City = txtCity.Text.Trim();
            selectedCustomer.State = ddlState.SelectedValue;
            selectedCustomer.Zip = txtZipPostal.Text.Trim();
            selectedCustomer.PhoneHome = txtHomePhone.Text.Trim();
            selectedCustomer.PhoneMobile = txtMobilePhone.Text.Trim();
            selectedCustomer.PhoneWork = txtWorkPhone.Text.Trim();
            selectedCustomer.Fax = txtFax.Text.Trim();

            customer_profile.CustomerId = customerid;
            customer_profile.Gender = ddlGender.SelectedValue.ToString();
            customer_profile.CustomerSite = Convert.ToInt16(DropDownList3.SelectedValue);
            customer_profile.Teacher = Convert.ToInt16(DropDownList4.SelectedValue);
            int teacherid = Convert.ToInt16(DropDownList4.SelectedValue);

            if (customerexists)
                DataRepository.CustomerProvider.Update(selectedCustomer);
            else
                DataRepository.CustomerProvider.Insert(customer);
            if (customerprofileexists)
                DataRepository.CustomerProfileProvider.Update(customer_profile);
            else
                DataRepository.CustomerProfileProvider.Insert(customer_profile);
            if (customerprofileexists)
                _sprintAthleteEdit.UpdateAssignPrimaryCoach(customerid, teacherid);
            else
                _sprintAthleteEdit.InsertIntoAssignPrimaryCoach(customerid, teacherid);
        }

        ddlAthlete.SelectedIndex = 0;
        txtFirstName.Text = "";
        TxtLastName.Text = "";
        DropDownList2.SelectedIndex = 0;
        txtAddressFirst.Text = "";
        txtAddressSecond.Text = "";
        txtCity.Text = "";
        ddlState.SelectedIndex = 0;
        txtZipPostal.Text = "";
        txtHomePhone.Text = "";
        txtMobilePhone.Text = "";
        txtWorkPhone.Text = "";
        txtFax.Text = "";
        ddlGender.SelectedIndex = 0;

    }
    protected void ddlAthlete_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtFirstName.Text = "";
        TxtLastName.Text = "";
        DropDownList2.SelectedIndex = 0;
        txtAddressFirst.Text = "";
        txtAddressSecond.Text = "";
        txtCity.Text = "";
        ddlState.SelectedIndex = 0;
        txtZipPostal.Text = "";
        txtHomePhone.Text = "";
        txtMobilePhone.Text = "";
        txtWorkPhone.Text = "";
        txtFax.Text = "";
        ddlGender.SelectedIndex = 0;


        try
        {
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            selectedCustomer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(selectedCustomer.CustomerId)[0];
            customerexists = true;
            customerprofileexists = true;
            BindControl();
        }
        catch
        {
            customerexists = false;
            customerprofileexists = false;
            txtFirstName.Text = selectedCustomer.FirstName;
            TxtLastName.Text = selectedCustomer.LastName;
            cleardata();
            FillControl();
        }
    }
    private void BindControl()
    {
        try
        {
            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            selectedCustomer = DataRepository.CustomerProvider.GetByCustomerId(customerid);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];
            txtFirstName.Text = selectedCustomer.FirstName;
            TxtLastName.Text = selectedCustomer.LastName;
            //DropDownList3.SelectedIndex = customerprofile.CustomerSite;    

            DropDownList2.SelectedValue = selectedCustomer.Country.ToString();
            txtAddressFirst.Text = selectedCustomer.Address1;
            txtAddressSecond.Text = selectedCustomer.Address2;
            txtCity.Text = selectedCustomer.City;
            if (selectedCustomer.State.Equals(""))
            {
                ddlState.SelectedIndex = 0;
            }
            else
            {
                ddlState.SelectedValue = selectedCustomer.State;
            }
            txtZipPostal.Text = selectedCustomer.Zip;
            txtHomePhone.Text = selectedCustomer.PhoneHome;
            txtMobilePhone.Text = selectedCustomer.PhoneMobile;
            txtWorkPhone.Text = selectedCustomer.PhoneWork;
            txtFax.Text = selectedCustomer.Fax;
            if (customerprofile.Gender.Equals(""))
            {
                ddlGender.SelectedIndex = 0;
            }
            else
            {
                ddlGender.SelectedValue = customerprofile.Gender;
            }
            DropDownList3.SelectedValue = customerprofile.CustomerSite.ToString();
            DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customerid);
            DropDownList4.SelectedValue = dsCoachName.Tables[0].Rows[0]["TeacherId"].ToString();
        }
        catch (Exception ex)
        {

        }
    }

    private void cleardata()
    {
        DropDownList4.Items.Clear();
        DropDownList3.Items.Clear();
        DropDownList2.Items.Clear();
        ddlGender.Items.Clear();
        txtFax.Text = "";
        txtWorkPhone.Text = "";
        txtMobilePhone.Text = "";
        txtZipPostal.Text = "";
        ddlState.Items.Clear();
        txtCity.Text = "";
        txtAddressSecond.Text = "";
        txtAddressFirst.Text = "";
        txtHomePhone.Text = "";
    }
}
