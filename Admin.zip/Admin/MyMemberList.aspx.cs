﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Teachers_MemberList : System.Web.UI.Page
public partial class Teachers_MemberList : SwingModel.UI.BasePage
{
    public Customer customer;
    public CustomerProfile customerprofile;
    public TList<TeacherSite> teachersatsite = new TList<TeacherSite>();
    public Teacher teacher;
    public CustomerSite customersite;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];

        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
        Label1.Text = customersite.SiteName;
        
        teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(customerprofile.CustomerSite);
        teachersatsite.Sort("TeacherId ASC");
        //if (DropDownList1.Items.Count.Equals(0))
        //{
        //    DropDownList1.Items.Clear();
        //    string logusrname = User.Identity.Name;
        //    DropDownList1.Items.Add(logusrname.ToString());
        //    DropDownList1.Items[0].Value = "1";
        //    DropDownList1_SelectedIndexChanged(this, null);
        //}

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            DropDownList1.Items.Add("All Teachers");
            DropDownList1.Items[1].Value = "0";
            int x = 1;
            foreach (TeacherSite ts in teachersatsite)
            {
                x++;
                teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                DropDownList1.Items.Add(teacher.FirstName + " " + teacher.LastName);
                DropDownList1.Items[x].Value = teacher.TeacherId.ToString();
            }
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int SelectedTeacherId = Convert.ToInt16(DropDownList1.SelectedValue);
        TList<CustomerProfile> customerprofiles = new TList<CustomerProfile>();
        int x = 0;
        DataTable dt = new DataTable();
        dt.Columns.Add("Count", typeof(int));
        dt.Columns.Add("First Name", typeof(string));
        dt.Columns.Add("Last Name", typeof(string));
        dt.Columns.Add("Email Address", typeof(string));
        dt.Columns.Add("Username", typeof(string));
        dt.Columns.Add("Teacher", typeof(string));
        dt.Columns.Add("Status", typeof(string));
        string StatusText = "";

        if (SelectedTeacherId.Equals(-1))
        {
            //Do Nothing
            GridView1.Visible = false;
        }
        else if (SelectedTeacherId.Equals(0))
        {
            try
            {
            GridView1.Visible = true;
            foreach (TeacherSite ts in teachersatsite)
            {
                Teacher teach = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
                customerprofiles = DataRepository.CustomerProfileProvider.GetByTeacher(teach.TeacherId);
                foreach (CustomerProfile cp in customerprofiles)
                {
                    x++;
                    Customer cus = DataRepository.CustomerProvider.GetByCustomerId(cp.CustomerId);
                    Guid MemGuid = new Guid(cus.AspnetMembershipUserId.ToString());
                    MembershipUser user = Membership.GetUser(MemGuid);

                    StatusText = "";
                    switch (cus.MembershipStatus)
                    {
                        case 0:
                            StatusText = "Expired";
                            break;

                        case 1:
                            StatusText = "Member";
                            break;

                        case 2:
                            StatusText = "FullTeach";
                            break;

                        case 3:
                            StatusText = "FullFit";
                            break;

                        case 4:
                            StatusText = "FullTeachFit";
                            break;

                        case 97:
                            StatusText = "CompTeach";
                            break;

                        case 98:
                            StatusText = "CompFit";
                            break;

                        case 99:
                            StatusText = "CompTeachFit";
                            break;

                        default:
                            StatusText = "Missing";
                            break;
                    }
                    if (cp.CustomerSite.Equals(customersite.CustomerSiteId))
                        dt.Rows.Add(x, cus.FirstName, cus.LastName, user.Email, user.UserName, teach.FirstName + " " + teach.LastName, StatusText);
                }
            }
            dt.DefaultView.Sort = "Last Name ASC, First Name ASC, Username ASC";
            x = 0;
            foreach (DataRowView row in dt.DefaultView)
            {
                x++;
                row.Row.SetField("Count", x);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();
            }
            catch { }
        }
        else
        {
            
            GridView1.Visible = true;
            Teacher teach = DataRepository.TeacherProvider.GetByTeacherId(SelectedTeacherId);
            customerprofiles = DataRepository.CustomerProfileProvider.GetByTeacher(SelectedTeacherId);
            foreach (CustomerProfile cp in customerprofiles)
            {
                x++;
                Customer cus = DataRepository.CustomerProvider.GetByCustomerId(cp.CustomerId);
                Guid MemGuid = new Guid(cus.AspnetMembershipUserId.ToString());
                MembershipUser user = Membership.GetUser(MemGuid);

                StatusText = "";
                switch (cus.MembershipStatus)
                {
                    case 0:
                        StatusText = "Expired";
                        break;

                    case 1:
                        StatusText = "Member";
                        break;

                    case 2:
                        StatusText = "FullTeach";
                        break;

                    case 3:
                        StatusText = "FullFit";
                        break;

                    case 4:
                        StatusText = "FullTeachFit";
                        break;

                    case 97:
                        StatusText = "CompTeach";
                        break;

                    case 98:
                        StatusText = "CompFit";
                        break;

                    case 99:
                        StatusText = "CompTeachFit";
                        break;

                    default:
                        StatusText = "Missing";
                        break;
                }
                if (cp.CustomerSite.Equals(customersite.CustomerSiteId))
                    dt.Rows.Add(x, cus.FirstName, cus.LastName, user.Email, user.UserName, teach.FirstName + " " + teach.LastName, StatusText);
            }
            dt.DefaultView.Sort = "Last Name ASC, First Name ASC, Username ASC";
            x = 0;
            foreach (DataRowView row in dt.DefaultView)
            {
                x++;
                row.Row.SetField("Count", x);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();       
        }
    }
}
