﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.Windows.Forms;
using MemberDownload;

public partial class Admin_DownloadMember : System.Web.UI.Page
{
    public DownloadMemberTeachFile dmtf = new DownloadMemberTeachFile();
    string MemberGuid = "";
    string CustomerId = "";

    protected override void OnPreRender(EventArgs e)
    {
        MemberGuid = Request.QueryString.Get("Guid");
        CustomerId = Request.QueryString.Get("ID");

        //MessageBox.Show("FN: " + FirstName);
        //MessageBox.Show("LN: " + LastName);
        //MessageBox.Show("EA: " + EmailAddress);

        TextBox1.Text = MemberGuid;
        TextBox2.Text = CustomerId;

        if (!TextBox1.Text.Equals("") && !TextBox1.Text.Equals(null) && !TextBox2.Equals("") && !TextBox2.Equals(null))
            Button1_Click(this, null);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = -9999;

        if (!TextBox1.Text.Equals("") && !TextBox1.Text.Equals(null) && !TextBox2.Equals("") && !TextBox2.Equals(null))
            i = dmtf.GetFile(TextBox1.Text, Convert.ToInt16(TextBox2.Text));
        else
        {
            // back to page
        }

        string DateString = DateTime.Today.Year.ToString()
                + "-"
                + DateTime.Today.Month.ToString()
                + "-"
                + DateTime.Today.Day.ToString();
        string MemberFilePath = "~/files/download/"
            + TextBox1.Text
            + "-"
            + DateString
            + ".txt";
        if (i > 0)
            Response.Redirect(MemberFilePath);
        else
        {
            //back to page
        }
        //nothing
    }
}
