﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Data.SqlClient;

public partial class Admin_My_Profile : System.Web.UI.Page
{
    string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();

    Customer customerid;
    public CustomerProfile customerprofile;
    TList<Customer> customer = new TList<Customer>();
    int x;
    public Customer cust;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            customer = DataRepository.CustomerProvider.GetAll();
            customer.Sort("FirstName");
            foreach (var item in customer)
            {
                x++;
                ddlAthlete.Items.Add(item.FirstName + " " + item.LastName);
                ddlAthlete.Items[x].Value = item.CustomerId.ToString();
                continue;
            }
        }
    }
    public void BindAthletDropDown()
    {
        
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlAge.Text = "";
        ddlHandedness.Text = "";
        ddlTierLevel.SelectedIndex = 0;
        ddlCompetitions.Text = "";
        ddlPractice.Text = "";
        ddlPracticeTime.Text = "";
        ddlAltitude.Text = "";
        ddlWind.Text = "";
        ddlTrack.Text = "";

        try
        {
            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];
            BindControl();
                      
        }
        catch
        {
            RegisterStartupScript("startupScript", "<script language=JavaScript>alert('Please Enter Account Information First.');</script>");
        }
       
    }
    private void BindControl()
    {
        try
        {
            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];

            ddlAge.SelectedValue = customerprofile.Age;
            ddlAltitude.SelectedValue = customerprofile.Altitude;
            ddlCompetitions.SelectedValue = customerprofile.Rounds;
            ddlHandedness.SelectedValue = customerprofile.Hand;
            ddlPractice.SelectedValue = customerprofile.Practice.ToString().Trim();
            ddlPracticeTime.SelectedValue = customerprofile.Lessons.ToString().Trim();
            ddlTierLevel.SelectedValue = customerprofile.InitialTeacher.ToString();    //tire level
            ddlTrack.SelectedValue = customerprofile.Roll;
            ddlWind.SelectedValue = customerprofile.Wind;           
        }
        catch (Exception ex)
        {

        }

       

    }
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];

            string Age = ddlAge.SelectedValue.ToString().Trim();
            string Altitude = ddlAltitude.SelectedValue.ToString().Trim();
            string Competitions = ddlCompetitions.SelectedValue.ToString().Trim();
            string Handedness = ddlHandedness.SelectedValue.ToString().Trim();
            string Practice = ddlPractice.SelectedValue.ToString().Trim();
            string PracticeTime = ddlPracticeTime.SelectedValue.ToString().Trim();
            int? TierLevel = Convert.ToInt16(ddlTierLevel.SelectedValue);
            string Track = ddlTrack.SelectedValue.ToString().Trim();
            string Wind = ddlWind.SelectedValue.ToString().Trim();

            customerprofile.Age = Age;
            customerprofile.Altitude = Altitude;
            customerprofile.Rounds = Competitions;
            customerprofile.Hand = Handedness;
            customerprofile.Practice = Practice;
            customerprofile.Lessons = PracticeTime;
            customerprofile.InitialTeacher = TierLevel;
            customerprofile.Roll = Track;
            customerprofile.Wind = Wind;

            DataRepository.CustomerProfileProvider.Update(customerprofile);

            ddlAthlete.SelectedIndex=0;
            ddlAge.Text = "";
            ddlHandedness.Text = "";
            ddlTierLevel.SelectedIndex=0 ;
            ddlCompetitions.Text = "";
            ddlPractice.Text = "";
            ddlPracticeTime.Text = "";
            ddlAltitude.Text = "";
            ddlWind.Text="";
            ddlTrack.Text = "";
        }
        catch
        {
        }
    }
}

