﻿using System;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Data.SqlClient;

public partial class Admin_AthletesDimesions : System.Web.UI.Page
{

    string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();

    Customer customerid;
    public CustomerProfile customerprofile;
    TList<Customer> customer = new TList<Customer>();
    public Customer cust;
    bool customerexists = false;
    bool customerprofileexists = false;
    int x;
    DataTable dt = new DataTable();    
    
    CompuSportDataAccess.AthleteBodyDimensions abd = new CompuSportDataAccess.AthleteBodyDimensions();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            customer = DataRepository.CustomerProvider.GetAll();
            customer.Sort("FirstName");
            foreach (var item in customer)
            {
                x++;
                ddlAthlete.Items.Add(item.FirstName + " " + item.LastName);
                ddlAthlete.Items[x].Value = item.CustomerId.ToString();
                continue;
            }
            FillControl();
        }
    }
    private void FillControl()
    {
        try
        {
            #region[bodyweight]
            x = 0;
            ddlBodyWeight.Items.Clear();
            ddlBodyWeight.Items.Add("select");
            ddlBodyWeight.Items[x].Value = x.ToString();
            for (int i = 50; i <= 350; i++)
            {
                x++;
                ddlBodyWeight.Items.Add(i.ToString());
                ddlBodyWeight.Items[x].Value = i.ToString();
            }
            ddlBodyWeight.SelectedValue = "0";
            #endregion[bodyweight]
            #region[ShoulderWidth]
            x = 0;
            ddlShoulderWidth.Items.Clear();
            ddlShoulderWidth.Items.Add("select");
            ddlShoulderWidth.Items[x].Value = x.ToString();
            for (Double f = 12; f <= 24; f = f + 0.5)
            {
                x++;
                ddlShoulderWidth.Items.Add(f.ToString());
                ddlShoulderWidth.Items[x].Value = f.ToString();
            }
            ddlShoulderWidth.SelectedValue = "0";
            #endregion[ShoulderWidth]
            #region[TrunkLength]
            x = 0;
            ddlTrunkLength.Items.Clear();
            ddlTrunkLength.Items.Add("select");
            ddlTrunkLength.Items[x].Value = x.ToString();
            for (Double f = 8; f <= 20.5; f = f + .5)
            {
                x++;
                ddlTrunkLength.Items.Add(f.ToString());
                ddlTrunkLength.Items[x].Value = f.ToString();
            }
            ddlTrunkLength.SelectedValue = "0";
            #endregion[TrunkLength]
            #region[Upperarmlength]
            x = 0;
            ddlUpperArmLength.Items.Clear();
            ddlUpperArmLength.Items.Add("select");
            ddlUpperArmLength.Items[x].Value = x.ToString();
            for (Double f = 8; f <= 14.5; f = f + 0.5)
            {
                x++;
                ddlUpperArmLength.Items.Add(f.ToString());
                ddlUpperArmLength.Items[x].Value = f.ToString();
            }
            ddlUpperArmLength.SelectedValue = "0";
            #endregion[Upperarmlength]
            #region[Lowerarmlength]
            x = 0;
            ddlLowerArmLength.Items.Clear();
            ddlLowerArmLength.Items.Add("select");
            ddlLowerArmLength.Items[x].Value = x.ToString();
            for (Double f = 8; f <= 14.5; f = f + 0.5)
            {
                x++;
                ddlLowerArmLength.Items.Add(f.ToString());
                ddlLowerArmLength.Items[x].Value = f.ToString();

            }
            ddlLowerArmLength.SelectedValue = "0";
            #endregion[Upperarmlength]
            #region[WaistMeasurement]
            x = 0;
            ddlWaistMeasurement.Items.Clear();
            ddlWaistMeasurement.Items.Add("select");
            ddlWaistMeasurement.Items[x].Value = x.ToString();
            for (Double f = 20.0; f <= 40; f = f + 0.5)
            {
                x++;
                ddlWaistMeasurement.Items.Add(f.ToString("#0.0"));
                ddlWaistMeasurement.Items[x].Value = f.ToString();
            }
            ddlWaistMeasurement.SelectedValue = "0";
            #endregion[WaistMeasurement]
            #region[hiplength]
            x = 0;
            ddlHipLength.Items.Clear();
            ddlHipLength.Items.Add("select");
            ddlHipLength.Items[x].Value = x.ToString();
            for (Double f = 4.0; f <= 8; f = f + 0.5)
            {
                x++;
                ddlHipLength.Items.Add(f.ToString("#0.0"));
                ddlHipLength.Items[x].Value = f.ToString();
            }
            ddlHipLength.SelectedValue = "0";
            #endregion[hiplength]
            #region[Upperleglentgh]
            x = 0;
            ddlUpperLegLength.Items.Clear();
            ddlUpperLegLength.Items.Add("select");
            ddlUpperLegLength.Items[x].Value = x.ToString();
            for (Double f = 10; f <= 24.5; f = f + 0.5)
            {
                x++;
                ddlUpperLegLength.Items.Add(f.ToString());
                ddlUpperLegLength.Items[x].Value = f.ToString();
            }
            ddlUpperLegLength.SelectedValue = "0";
            #endregion[Upperleglentgh]
            #region[Lowerleglentgh]
            x = 0;
            ddlLowerLegLength.Items.Clear();
            ddlLowerLegLength.Items.Add("select");
            ddlLowerLegLength.Items[x].Value = x.ToString();
            for (Double f = 10; f <= 24.5; f = f + 0.5)
            {
                x++;
                ddlLowerLegLength.Items.Add(f.ToString());
                ddlLowerLegLength.Items[x].Value = f.ToString();
            }
            ddlLowerLegLength.SelectedValue = "0";
            #endregion[Lowerleglentgh]
            #region[AnkleHeight]
            x = 0;
            ddlAnkleHeight.Items.Clear();
            ddlAnkleHeight.Items.Add("select");
            ddlAnkleHeight.Items[x].Value = x.ToString();
            for (Double f = 2; f <= 4.5; f = f + .5)
            {
                x++;
                ddlAnkleHeight.Items.Add(f.ToString());
                ddlAnkleHeight.Items[x].Value = f.ToString();
            }
            ddlAnkleHeight.SelectedValue = "0";
            #endregion[AnkleHeight]
            #region[ShoeSize]
            x = 0;
            ddlShoeSize.Items.Clear();
            ddlShoeSize.Items.Add("select");
            ddlShoeSize.Items[x].Value = x.ToString();
            for (Double f = 1; f <= 20; f = f + .5)
            {
                x++;
                ddlShoeSize.Items.Add(f.ToString());
                ddlShoeSize.Items[x].Value = f.ToString();
            }
            ddlShoeSize.SelectedValue = "0";
            #endregion[AnkleHeight]
        }
        catch
        { }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlBodyHeight.SelectedIndex = 0;
        ddlBodyWeight.SelectedIndex = 0;
        ddlShoulderWidth.SelectedIndex = 0;
        ddlTrunkLength.SelectedIndex = 0;
        ddlUpperArmLength.SelectedIndex = 0;
        ddlLowerArmLength.SelectedIndex = 0;
        ddlWaistMeasurement.SelectedIndex = 0;
        ddlHipLength.SelectedIndex = 0;
        ddlUpperLegLength.SelectedIndex = 0;
        ddlLowerLegLength.SelectedIndex = 0;
        ddlAnkleHeight.SelectedIndex = 0;
        ddlShoeSize.SelectedIndex = 0;

        try
        {
            int SelectedCustomerid = Convert.ToInt16(ddlAthlete.SelectedValue);
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(SelectedCustomerid)[0];
            BindControl();
        }
        catch
        {
            RegisterStartupScript("startupScript", "<script language=JavaScript>alert('Please Enter Account Information First.');</script>");
        }
    }
    private void BindControl()
    {
        int customerid = Convert.ToInt16(ddlAthlete.SelectedValue);
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];
        string value = string.Empty;
        dt = abd.GetDataFromCustomerProfile(customerid);
        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }

        #region[bodyheight]
        if (customerprofile.Height.Equals(Convert.ToDecimal(0)))
            ddlBodyHeight.SelectedValue = "0";
        else
            ddlBodyHeight.SelectedValue = customerprofile.Height.ToString();
        #endregion[bodyweight]
        #region[bodyweight]
        if (customerprofile.Weight.Equals(Convert.ToDecimal(0)))
            ddlBodyWeight.SelectedValue = "0";
        else
            ddlBodyWeight.SelectedValue = customerprofile.Weight.ToString("#0");
        #endregion[bodyweight]
        #region[shoulderwidth]
        if (customerprofile.Shoulder.Equals(Convert.ToDecimal(0)))
            ddlShoulderWidth.SelectedValue = "0";
        else
        {
            value = customerprofile.Shoulder.ToString();
            if (value.Contains(".5"))
            {
                ddlShoulderWidth.SelectedValue = customerprofile.Shoulder.ToString("#0.0");
            }
            else
            {
                ddlShoulderWidth.SelectedValue = customerprofile.Shoulder.ToString("#0");
            }
        }
        #endregion[shoulderwidth]
        #region[trunklength]
        if (dt.Rows[0]["TrunkLength"] == DBNull.Value)
        {
            ddlTrunkLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["TrunkLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlTrunkLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["TrunkLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlTrunkLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["TrunkLength"].ToString()).ToString("#0");
            }
        }
        #endregion[trunklength]
        #region[UpperArmLength]
        if (dt.Rows[0]["UpperArmLength"] == DBNull.Value)
        {
            ddlUpperArmLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["UpperArmLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlUpperArmLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["UpperArmLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlUpperArmLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["UpperArmLength"].ToString()).ToString("#0");
            }
        }

        #endregion[UpperArmLength]

        #region[LowerArmLength]
        if (dt.Rows[0]["LowerArmLength"] == DBNull.Value)
        {
            ddlLowerArmLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["LowerArmLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlLowerArmLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["LowerArmLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlLowerArmLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["LowerArmLength"].ToString()).ToString("#0");
            }
        }
        #endregion[LowerArmLength]

        #region[waistmeasurement]
        if (customerprofile.Waist.Equals(Convert.ToDecimal(0)))
            ddlWaistMeasurement.SelectedValue = "0";
        else
        {
            value = customerprofile.Waist.ToString();
            if (value.Contains(".5"))
            {
                ddlWaistMeasurement.SelectedValue = customerprofile.Waist.ToString("#0.0");
            }
            else
            {
                ddlWaistMeasurement.SelectedValue = customerprofile.Waist.ToString("#0");
            }
        }
        #endregion[waistmeasurement]

        #region[hiplength]
        if (dt.Rows[0]["HipLength"] == DBNull.Value)
        {
            ddlHipLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["HipLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlHipLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["HipLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlHipLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["HipLength"].ToString()).ToString("#0");
            }
        }
        #endregion[hiplength]

        #region[UpperLegLength]
        if (dt.Rows[0]["UpperLegLength"] == DBNull.Value)
        {
            ddlUpperLegLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["UpperLegLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlUpperLegLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["UpperLegLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlUpperLegLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["UpperLegLength"].ToString()).ToString("#0");
            }
        }
        #endregion[UpperLegLength]
        #region[LowerLegLength]
        if (dt.Rows[0]["LowerLegLength"] == DBNull.Value)
        {
            ddlLowerLegLength.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["LowerLegLength"].ToString();
            if (value.Contains(".5"))
            {
                ddlLowerLegLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["LowerLegLength"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlLowerLegLength.SelectedValue = Convert.ToDecimal(dt.Rows[0]["LowerLegLength"].ToString()).ToString("#0");
            }
        }
        #endregion[LowerLegLength]
        #region[ankleheight]
        if (dt.Rows[0]["AnkleHeight"] == DBNull.Value)
        {
            ddlAnkleHeight.SelectedValue = "0";
        }
        else
        {
            value = dt.Rows[0]["AnkleHeight"].ToString();
            if (value.Contains(".5"))
            {
                ddlAnkleHeight.SelectedValue = Convert.ToDecimal(dt.Rows[0]["AnkleHeight"].ToString()).ToString("#0.0");
            }
            else
            {
                ddlAnkleHeight.SelectedValue = Convert.ToDecimal(dt.Rows[0]["AnkleHeight"].ToString()).ToString("#0");
            }
        }
        #endregion[ankleheight]

        #region[Shoesize]
        if (customerprofile.Shoe.Equals(Convert.ToDecimal(0)))
            ddlShoeSize.SelectedValue = "0";
        else
        {
            value = customerprofile.Shoe.ToString();
            if (value.Contains(".5"))
            {
                ddlShoeSize.SelectedValue = customerprofile.Shoe.ToString("#0.0");
            }
            else
            {
                ddlShoeSize.SelectedValue = customerprofile.Shoe.ToString("#0");
            }
        }
        #endregion[Shoesize]
    }

    private void AthleteAuthenticated()
    {
        //try
        //{
        //    dt = abd.GetDataFromCustomerProfile(customers.);

        //    if (Page.User.Identity.IsAuthenticated)
        //    {
        //        try
        //        {
        //            customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        //            customerexists = true;
        //        }
        //        catch
        //        {
        //            //no entry in Customer table for current member
        //            customerexists = false;
        //        }

        //        try
        //        {
        //            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        //            customerprofileexists = true;
        //        }
        //        catch
        //        {
        //            //no entery in CustomerProfile table for current member
        //            customerprofileexists = false;
        //        }
        //    }
        //}
        //catch (Exception ex)
        //{

        //}
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int SelectedCustomerid = Convert.ToInt16(ddlAthlete.SelectedValue);
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(SelectedCustomerid)[0];
        customerprofile.CustomerId = SelectedCustomerid;
        //string Varheight = Convert.ToString(DropDownList1.SelectedValue);
        //Varheight=Varheight.Substring(0, 2);
        customerprofile.Height = Convert.ToDecimal(ddlBodyHeight.SelectedValue);
        //customerprofile.Height = Convert.ToDecimal(Varheight);
        customerprofile.Weight = Convert.ToDecimal(ddlBodyWeight.SelectedValue);
        customerprofile.Shoulder = Convert.ToDecimal(ddlShoulderWidth.SelectedValue);
        decimal VarTrunklength = Convert.ToDecimal(ddlTrunkLength.SelectedValue);
        decimal VarUpperarmlength = Convert.ToDecimal(ddlUpperArmLength.SelectedValue);
        decimal VarLowerarmlength = Convert.ToDecimal(ddlLowerArmLength.SelectedValue);
        // customerprofile.Sleeve = Convert.ToDecimal(DropDownList4.SelectedValue);
        // customerprofile.Glove = DropDownList5.SelectedValue;
        customerprofile.Waist = Convert.ToDecimal(ddlWaistMeasurement.SelectedValue);
        decimal VarHiplength = Convert.ToDecimal(ddlHipLength.SelectedValue);
        // customerprofile.Inseam = Convert.ToDecimal(DropDownList7.SelectedValue);
        decimal VarUpperleglength = Convert.ToDecimal(ddlUpperLegLength.SelectedValue);
        decimal VarLowerleglength = Convert.ToDecimal(ddlLowerLegLength.SelectedValue);
        decimal VarAnkleheight = Convert.ToDecimal(ddlAnkleHeight.SelectedValue);
        customerprofile.Shoe = Convert.ToDecimal(ddlShoeSize.SelectedValue);



        try
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmdInsert = new SqlCommand())
                {
                    cmdInsert.CommandType = CommandType.StoredProcedure;
                    cmdInsert.CommandText = "UpdateCustomerProfile";
                    cmdInsert.Parameters.AddWithValue("@Customerid", customerprofile.CustomerId);
                    cmdInsert.Parameters.AddWithValue("@Height", customerprofile.Height);
                    cmdInsert.Parameters.AddWithValue("@Weight", customerprofile.Weight);
                    cmdInsert.Parameters.AddWithValue("@Shoulder", customerprofile.Shoulder);
                    cmdInsert.Parameters.AddWithValue("@Trunklength", VarTrunklength);
                    cmdInsert.Parameters.AddWithValue("@Upperarmlength", VarUpperarmlength);
                    cmdInsert.Parameters.AddWithValue("@Lowerarmlength", VarLowerarmlength);
                    cmdInsert.Parameters.AddWithValue("@Waist", customerprofile.Waist);
                    cmdInsert.Parameters.AddWithValue("@Hiplength", VarHiplength);
                    cmdInsert.Parameters.AddWithValue("@Upperleglength", VarUpperleglength);
                    cmdInsert.Parameters.AddWithValue("@Lowerleglength", VarLowerleglength);
                    cmdInsert.Parameters.AddWithValue("@Ankleheight", VarAnkleheight);
                    cmdInsert.Parameters.AddWithValue("@Shoe", customerprofile.Shoe);
                    cmdInsert.Connection = conn;
                    cmdInsert.ExecuteNonQuery();
                }
            }

            ddlAthlete.SelectedIndex = 0;
            ddlBodyHeight.SelectedIndex = 0;
            ddlBodyWeight.SelectedIndex = 0;
            ddlShoulderWidth.SelectedIndex = 0;
            ddlTrunkLength.SelectedIndex = 0;
            ddlUpperArmLength.SelectedIndex = 0;
            ddlLowerArmLength.SelectedIndex = 0;
            ddlWaistMeasurement.SelectedIndex = 0;
            ddlHipLength.SelectedIndex = 0;
            ddlUpperLegLength.SelectedIndex = 0;
            ddlLowerLegLength.SelectedIndex = 0;
            ddlAnkleHeight.SelectedIndex = 0;
            ddlShoeSize.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

}