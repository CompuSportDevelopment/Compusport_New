﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Drawing;



public partial class Admin_BlockForceInput : System.Web.UI.Page
{
    int x;
    public Customer customerid;
    public Customer cust;
    public CustomerProfile customerprofile;
    public CustomerProfile customerprofile1;
    TList<Customer> customer = new TList<Customer>();
    TList<Lesson> lessonList = new TList<Lesson>();
    public Lesson lesson;
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();
    DataSet ds = new DataSet();
    int lessonSelected;
    int athleteSelected;
    bool isFrontBlockForceDataExist = false;
    bool isBackBlockForceDataExist = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        bool AthleteAlreadyInList = false;
        customerid = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid.CustomerId)[0];
        tblBackBlockGraphData.Style.Add("display", "block");
        tblFrontBlockGraphData.Style.Add("display", "block");
        if (!IsPostBack)
        {
            customer = DataRepository.CustomerProvider.GetAll();
            customer.Sort("FirstName");

            foreach (var item in customer)
            {
                cust = DataRepository.CustomerProvider.GetByCustomerId(item.CustomerId);
                {
                    if (DropDownList1.Items.Count > 0)
                    {
                        if (DropDownList1.Items.Contains(DropDownList1.Items.FindByValue(item.CustomerId.ToString())))
                            AthleteAlreadyInList = true;
                        else
                            AthleteAlreadyInList = false;
                    }
                    if (!AthleteAlreadyInList)
                    {
                        x++;
                        DropDownList1.Items.Add(item.FirstName + " " + item.LastName);
                        DropDownList1.Items[x].Value = item.CustomerId.ToString();
                        continue;
                    }
                }
            }
        }
    }
    private void LoadExistingLocation()
    {
        int AthleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
        lessonList = DataRepository.LessonProvider.GetByCustomerId(AthleteSelected);
        if (lessonList.Count != 0)
        {
            Label2.Visible = false;
            DropDownList2.Visible = true;
            Customer cust = DataRepository.CustomerProvider.GetByCustomerId(AthleteSelected);
            Lesson lessonid1 = DataRepository.LessonProvider.GetByCustomerId(cust.CustomerId)[0];
            string athletelessonid = lessonid1.LessonId.ToString();

            lessonList.Sort("LessonDate DESC");
            x = 0;
            DropDownList2.Items.Add("Select Analysis Date and Location");
            DropDownList2.Items[0].Value = "";

            foreach (Lesson lesson in lessonList)
            {
                string location = sae.SelectLessonlocation(lesson.LessonId.ToString());

                if (lesson.LessonTypeId.Equals(1))
                {
                    x++;
                    DropDownList2.Items.Add(lesson.LessonDate.ToString("MM/dd/yyyy") + " - " + location);
                    DropDownList2.Items[x].Value = lesson.LessonId.ToString();
                }
            }
        }
        else
        {
            Label2.Visible = true;
            DropDownList2.Visible = false;
        }
    }
    //void ClearInputs(ControlCollection ctrl)
    //{
      
    //       TextBox tb = (TextBox)UpdatePanel2.FindControl("txtActualForceAthleteHorizontal");
    //      tb.Text="";
    //   }



    
    private void ClearText(Control PanelID)
    {
        foreach (Control c in PanelID.Controls)
        {
            if (c is TextBox)
            {
                TextBox tb = c as TextBox;
               if (tb != null)
                {
                    tb.Text = "";
                }
            }
            if (c.Controls.Count > 0)
            {
               ClearText(c);
           }
        }
    }

   

//   public static IEnumerable<Control> GetChildControls(this Control control) //where TControl : Control
//{
//    var children = (control.Controls != null) ? control.Controls.OfType<Control>() : Enumerable.Empty<Control>();
//    return children.SelectMany(c => GetChildControls(c)).Concat(children);
//}
    
  

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (!DropDownList1.SelectedValue.Equals("noathlete"))
        {
            DropDownList2.Items.Clear();
            //TextBox tb = (TextBox)UpdatePanel2.FindControl("txtActualForceAthleteHorizontal");
            //MakeTextBoxClearForBackBlockData();
            //UpdatePanel upanel = new UpdatePanel();
            //IEnumerable<TextBox> textBoxes = upanel.Controls.GetChildControls().OfType<TextBox>();
            //foreach (TextBox tb in textBoxes)
            //{
            //    tb.Text = "";
            //}
            
            ClearText(this);
            //txtActualForceAthleteHorizontal.Text = "";
            
            LoadExistingLocation();
            //txtActualForceAthleteHorizontal.Text = "";
        }

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)

    {
        if (DropDownList2.SelectedValue != "")
        {

            lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);
            athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
            sae.CustomerId = athleteSelected;
            sae.LessonId = lessonSelected;
            #region[back block data]
            #region[Get Actual Force Data]
            try
            {
                DataTable dtActualForceData = new DataTable();
                dtActualForceData = sae.GetActualForceBlockForceInputData();
                if (dtActualForceData.Rows.Count > 0)
                {
                    isBackBlockForceDataExist = true;
                    txtActualForceAthleteHorizontal.Text = dtActualForceData.Rows[0]["AthleteHorizontalValue"].ToString();
                    txtActualForceModelHorizontal.Text = dtActualForceData.Rows[0]["ModelHorizontalValue"].ToString();
                    txtActualForceAthleteVertical.Text = dtActualForceData.Rows[0]["AthleteVerticalValue"].ToString();
                    txtActualForceModelVertical.Text = dtActualForceData.Rows[0]["ModelVerticalValue"].ToString();
                    txtActualForceAthleteTotal.Text = dtActualForceData.Rows[0]["AthleteTotalValue"].ToString();
                    txtActualForceModelTotal.Text = dtActualForceData.Rows[0]["ModelTotalValue"].ToString();
                }
                else
                {
                    isBackBlockForceDataExist = false;
                    txtActualForceAthleteHorizontal.Text = "";
                    //txtActualForceModelHorizontal.Text = "";
                    txtActualForceAthleteVertical.Text = "";
                    //txtActualForceModelVertical.Text = "";
                    txtActualForceAthleteTotal.Text = "";
                    //txtActualForceModelTotal.Text = "";
                }
            }
            catch
            {

            }
            #endregion[Get Actual Force Data]

            //#region[Get Relative Forces data]
            //try
            //{
            //    DataTable dtRelativeForces = new DataTable();
            //    dtRelativeForces = sae.GetRelativeForcesBlockForceInputData();
            //    if (dtRelativeForces.Rows.Count > 0)
            //    {
            //        sae.RelativeHorizontalForce = Convert.ToInt16(dtRelativeForces.Rows[0]["AthleteHorizontalValue"].ToString());
            //        txtRelativeForcesModelHorizontal.Text = dtRelativeForces.Rows[0]["ModelHorizontalValue"].ToString();
            //        txtRelativeForcesAthleteVertical.Text = dtRelativeForces.Rows[0]["AthleteVerticalValue"].ToString();
            //        txtRelativeForcesModelVertical.Text = dtRelativeForces.Rows[0]["ModelVerticalValue"].ToString();
            //        txtRelativeForcesAthleteTotal.Text = dtRelativeForces.Rows[0]["AthleteTotalValue"].ToString();
            //        txtRelativeForcesModelTotal.Text = dtRelativeForces.Rows[0]["ModelTotalValue"].ToString();
            //    }
            ////    else
            ////    {
            ////        txtRelativeForcesAthleteHorizontal.Text = "";
            ////        //txtRelativeForcesModelHorizontal.Text = "";
            ////        txtRelativeForcesAthleteVertical.Text = "";
            ////        //txtRelativeForcesModelVertical.Text = "";
            ////        txtRelativeForcesAthleteTotal.Text = "";
            ////        //txtRelativeForcesModelTotal.Text = "";
            ////    }
            ////}
            ////catch
            ////{
            ////}
            ////#endregion[Get Relative Forces data]

            #region[Get ActualPower data]
            try
            {
                DataTable dtActualPower = new DataTable();
                dtActualPower = sae.GetActualPowerBlockForceInputData();
                if (dtActualPower.Rows.Count > 0)
                {
                    txtActualPowerAthleteHorizontal.Text = dtActualPower.Rows[0]["AthleteHorizontalValue"].ToString();
                    txtActualPowerModelHorizontal.Text = dtActualPower.Rows[0]["ModelHorizontalValue"].ToString();
                    txtActualPowerAthleteVertical.Text = dtActualPower.Rows[0]["AthleteVerticalValue"].ToString();
                    txtActualPowerModelVertical.Text = dtActualPower.Rows[0]["ModelVerticalValue"].ToString();
                    txtActualPowerAthleteTotal.Text = dtActualPower.Rows[0]["AthleteTotalValue"].ToString();
                    txtActualPowerModelTotal.Text = dtActualPower.Rows[0]["ModelTotalValue"].ToString();
                }
                else
                {
                    txtActualPowerAthleteHorizontal.Text = "";
            //        //txtActualPowerModelHorizontal.Text = "";
                    txtActualPowerAthleteVertical.Text = "";
                    //txtActualPowerModelVertical.Text = "";
                    txtActualPowerAthleteTotal.Text = "";
            //        //txtActualPowerModelTotal.Text = "";
                }
            }
            catch
            {

            }
            #endregion[Get ActualPower data]

            ////#region[Get RelativePower data]
            ////try
            ////{
            ////    DataTable dtRelativePower = new DataTable();
            ////    dtRelativePower = sae.GetRelativePowerBlockForceInputData();
            ////    if (dtRelativePower.Rows.Count > 0)
            ////    {
            ////        txtRelativePowerAthleteHorizontal.Text = dtRelativePower.Rows[0]["AthleteHorizontalValue"].ToString();
            ////        txtRelativePowerModelHorizontal.Text = dtRelativePower.Rows[0]["ModelHorizontalValue"].ToString();
            ////        txtRelativePowerAthleteVertical.Text = dtRelativePower.Rows[0]["AthleteVerticalValue"].ToString();
            ////        txtRelativePowerModelVertical.Text = dtRelativePower.Rows[0]["ModelVerticalValue"].ToString();
            ////        txtRelativePowerAthleteTotal.Text = dtRelativePower.Rows[0]["AthleteTotalValue"].ToString();
            ////        txtRelativePowerModelTotal.Text = dtRelativePower.Rows[0]["ModelTotalValue"].ToString();
            ////    }
            ////    else
            ////    {
            ////        txtRelativePowerAthleteHorizontal.Text = "";
            ////        //txtRelativePowerModelHorizontal.Text = "";
            ////        txtRelativePowerAthleteVertical.Text = "";
            ////        //txtRelativePowerModelVertical.Text = "";
            ////        txtRelativePowerAthleteTotal.Text = "";
            ////        //txtRelativePowerModelTotal.Text = "";
            ////    }
            ////}
            ////catch
            ////{

            ////}
            ////#endregion[Get ActualPower data]

            #endregion[back block data]

            #region[front block data]
            #region[Get Actual Force Data]
            try
            {
                DataTable dtActualForceData = new DataTable();
                dtActualForceData = sae.GetActualForceFrontBlockForceInputData();
                if (dtActualForceData.Rows.Count > 0)
                {
                    isFrontBlockForceDataExist = true;
                    txtFrontBlockActualForceAthleteHorizontal.Text = dtActualForceData.Rows[0]["AthleteHorizontalValue"].ToString();
                    txtFrontBlockActualForceModelHorizontal.Text = dtActualForceData.Rows[0]["ModelHorizontalValue"].ToString();
                    txtFrontBlockActualForceAthleteVertical.Text = dtActualForceData.Rows[0]["AthleteVerticalValue"].ToString();
                    txtFrontBlockActualForceModelVertical.Text = dtActualForceData.Rows[0]["ModelVerticalValue"].ToString();
                    txtFrontBlockActualForceAthleteTotal.Text = dtActualForceData.Rows[0]["AthleteTotalValue"].ToString();
                    txtFrontBlockActualForceModelTotal.Text = dtActualForceData.Rows[0]["ModelTotalValue"].ToString();
                }
                else
                {
                    isFrontBlockForceDataExist = false;
                    txtFrontBlockActualForceAthleteHorizontal.Text = "";
                    //txtFrontBlockActualForceModelHorizontal.Text = "";
                    txtFrontBlockActualForceAthleteVertical.Text = "";
                    //txtFrontBlockActualForceModelVertical.Text = "";
                    txtFrontBlockActualForceAthleteTotal.Text = "";
                    //txtFrontBlockActualForceModelTotal.Text = "";
                }
            }
            catch
            {

            }
            #endregion[Get Actual Force Data]

            //#region[Get Relative Forces data]
            //try
            //{
            //    DataTable dtRelativeForces = new DataTable();
            //    dtRelativeForces = sae.GetRelativeForcesFrontBlockForceInputData();
            //    if (dtRelativeForces.Rows.Count > 0)
            //    {
            //        txtFrontBlockRelativeForcesAthleteHorizontal.Text = dtRelativeForces.Rows[0]["AthleteHorizontalValue"].ToString();
            //        txtFrontBlockRelativeForcesModelHorizontal.Text = dtRelativeForces.Rows[0]["ModelHorizontalValue"].ToString();
            //        txtFrontBlockRelativeForcesAthleteVertical.Text = dtRelativeForces.Rows[0]["AthleteVerticalValue"].ToString();
            //        txtFrontBlockRelativeForcesModelVertical.Text = dtRelativeForces.Rows[0]["ModelVerticalValue"].ToString();
            //        txtFrontBlockRelativeForcesAthleteTotal.Text = dtRelativeForces.Rows[0]["AthleteTotalValue"].ToString();
            //        txtFrontBlockRelativeForcesModelTotal.Text = dtRelativeForces.Rows[0]["ModelTotalValue"].ToString();
            //    }
            //    else
            //    {
            //        txtFrontBlockRelativeForcesAthleteHorizontal.Text = "";
            //        //txtFrontBlockRelativeForcesModelHorizontal.Text = "";
            //        txtFrontBlockRelativeForcesAthleteVertical.Text = "";
            //        //txtFrontBlockRelativeForcesModelVertical.Text = "";
            //        txtFrontBlockRelativeForcesAthleteTotal.Text = "";
            //        //txtFrontBlockRelativeForcesModelTotal.Text = "";
            //    }
            //}
            //catch
            //{
            //}
            //#endregion[Get Relative Forces data]

            #region[Get ActualPower data]
            try
            {
                DataTable dtActualPower = new DataTable();
                dtActualPower = sae.GetActualPowerFrontBlockForceInputData();
                if (dtActualPower.Rows.Count > 0)
                {
                    txtFrontBlockActualPowerAthleteHorizontal.Text = dtActualPower.Rows[0]["AthleteHorizontalValue"].ToString();
                    txtFrontBlockActualPowerModelHorizontal.Text = dtActualPower.Rows[0]["ModelHorizontalValue"].ToString();
                    txtFrontBlockActualPowerAthleteVertical.Text = dtActualPower.Rows[0]["AthleteVerticalValue"].ToString();
                    txtFrontBlockActualPowerModelVertical.Text = dtActualPower.Rows[0]["ModelVerticalValue"].ToString();
                    txtFrontBlockActualPowerAthleteTotal.Text = dtActualPower.Rows[0]["AthleteTotalValue"].ToString();
                    txtFrontBlockActualPowerModelTotal.Text = dtActualPower.Rows[0]["ModelTotalValue"].ToString();
                }
                else
                {
                    txtFrontBlockActualPowerAthleteHorizontal.Text = "";
                    //txtFrontBlockActualPowerModelHorizontal.Text = "";
                    txtFrontBlockActualPowerAthleteVertical.Text = "";
                    //txtFrontBlockActualPowerModelVertical.Text = "";
                    txtFrontBlockActualPowerAthleteTotal.Text = "";
                    //txtFrontBlockActualPowerModelTotal.Text = "";
                }
            }
            catch
            {

            }
            #endregion[Get ActualPower data]

            //#region[Get RelativePower data]
            //try
            //{
            //    DataTable dtRelativePower = new DataTable();
            //    dtRelativePower = sae.GetRelativePowerFrontBlockForceInputData();
            //    if (dtRelativePower.Rows.Count > 0)
            //    {
            //        txtFrontBlockRelativePowerAthleteHorizontal.Text = dtRelativePower.Rows[0]["AthleteHorizontalValue"].ToString();
            //        txtFrontBlockRelativePowerModelHorizontal.Text = dtRelativePower.Rows[0]["ModelHorizontalValue"].ToString();
            //        txtFrontBlockRelativePowerAthleteVertical.Text = dtRelativePower.Rows[0]["AthleteVerticalValue"].ToString();
            //        txtFrontBlockRelativePowerModelVertical.Text = dtRelativePower.Rows[0]["ModelVerticalValue"].ToString();
            //        txtFrontBlockRelativePowerAthleteTotal.Text = dtRelativePower.Rows[0]["AthleteTotalValue"].ToString();
            //        txtFrontBlockRelativePowerModelTotal.Text = dtRelativePower.Rows[0]["ModelTotalValue"].ToString();
            //    }
            //    else
            //    {
            //        txtFrontBlockRelativePowerAthleteHorizontal.Text = "";
            //        //txtFrontBlockRelativePowerModelHorizontal.Text = "";
            //        txtFrontBlockRelativePowerAthleteVertical.Text = "";
            //        //txtFrontBlockRelativePowerModelVertical.Text = "";
            //        txtFrontBlockRelativePowerAthleteTotal.Text = "";
            //        //txtFrontBlockRelativePowerModelTotal.Text = "";
            //    }
            //}
            //catch
            //{

            //}
            //#endregion[Get ActualPower data]
            #endregion[front block data]
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
            lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);
            lesson = DataRepository.LessonProvider.GetByLessonId(lessonSelected);
            DataTable dtBackActualForce = new DataTable();
            sae.CustomerId = athleteSelected;
            sae.LessonId = lessonSelected;
            sae.ForceDate = lesson.LessonDate;
            #region[insert into Actual Force]

            sae.AthleteHorizontalValue = Convert.ToInt32(txtActualForceAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtActualForceModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtActualForceAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtActualForceModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtActualForceAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtActualForceModelTotal.Text);

            dtBackActualForce = sae.GetActualForceBlockForceInputData();
            if (dtBackActualForce.Rows.Count > 0)
            {
                int backActualForceId = Convert.ToInt32(dtBackActualForce.Rows[0]["ActualForceId"]);
                sae.UpdateActualForce_BlockForceModelData();
                sae.UpdateBackBlockActualForce();
            }
            else
            {
                sae.InsertIntoActualForce();
                sae.UpdateActualForce_BlockForceModelData();
            }
            #endregion[insert into Actual Force]
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        //#region[insert into Relative Force]
        //try
        //{
        //DataTable dtBackActualForce = new DataTable();
        //if(sae.ModelHorizontalValue > 0 || sae.ModelHorizontalValue!=null)
        //{

        //    sae.RelativeHorizontalForce=(sae.AthleteHorizontalValue/sae.ModelHorizontalValue)*100;
        //}
        //if(sae.ModelVerticalValue > 0 || sae.ModelVerticalValue!=null)
        //{

        //    sae.RelativeVerticalForce=(sae.AthleteVerticalValue/sae.ModelVerticalValue)*100;
        //}
        //if(sae.ModelTotalValue > 0 || sae.ModelTotalValue!=null)
        //{

        //    sae.RelativeTotalForce=(sae.AthleteHorizontalValue/sae.ModelHorizontalValue)*100;
        //}
        //}
        //DataTable dtBackRelativeForce = new DataTable();
        //    sae.AthleteHorizontalValue = Convert.ToInt32(txtRelativeForcesAthleteHorizontal.Text);
        //    sae.ModelHorizontalValue = Convert.ToInt32(txtRelativeForcesModelHorizontal.Text);

        //    sae.AthleteVerticalValue = Convert.ToInt32(txtRelativeForcesAthleteVertical.Text);
        //    sae.ModelVerticalValue = Convert.ToInt32(txtRelativeForcesModelVertical.Text);

        //    sae.AthleteTotalValue = Convert.ToInt32(txtRelativeForcesAthleteTotal.Text);
        //    sae.ModelTotalValue = Convert.ToInt32(txtRelativeForcesModelTotal.Text);
        //    dtBackRelativeForce = sae.GetRelativeForcesBlockForceInputData();

        //    if (dtBackRelativeForce.Rows.Count > 0)
        //    {
        //        int backRelativeForceId = Convert.ToInt32(dtBackRelativeForce.Rows[0]["RelativeForcesId"]);
        //        sae.UpdateRelativeForce_BlockForceModelData();
        //        sae.UpdateBackBlockRelativeForce();
        //    }
        //    else
        //    {
        //        sae.InsertIntoRelativeForces();
        //        sae.UpdateRelativeForce_BlockForceModelData();
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ex.Message.ToString();
        //}
        //#endregion[insert into Relative Force]
        #region[insert into Actual Power]
        try
        {
            DataTable dtBackActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtActualPowerAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtActualPowerModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtActualPowerAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtActualPowerModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtActualPowerAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtActualPowerModelTotal.Text);
            dtBackActualPower = sae.GetActualPowerBlockForceInputData();
            if (dtBackActualPower.Rows.Count > 0)
            {
                int backactualPowerId = Convert.ToInt32(dtBackActualPower.Rows[0]["ActualPowerId"]);
                sae.UpdateActualPower_BlockForceModelData();
                sae.UpdateBackBlockActualPower();
            }
            else
            {
                sae.InsertIntoActualPower();
                sae.UpdateActualPower_BlockForceModelData();
            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
        #endregion[insert into Actual Power]
        //#region[insert into Relative Power]
        //try
        //{
        //    DataTable dtBackRelativePower = new DataTable();
        //    sae.AthleteHorizontalValue = Convert.ToInt32(txtRelativePowerAthleteHorizontal.Text);
        //    sae.ModelHorizontalValue = Convert.ToInt32(txtRelativePowerModelHorizontal.Text);

        //    sae.AthleteVerticalValue = Convert.ToInt32(txtRelativePowerAthleteVertical.Text);
        //    sae.ModelVerticalValue = Convert.ToInt32(txtRelativePowerModelVertical.Text);

        //    sae.AthleteTotalValue = Convert.ToInt32(txtRelativePowerAthleteTotal.Text);
        //    sae.ModelTotalValue = Convert.ToInt32(txtRelativePowerModelTotal.Text);
        //    dtBackRelativePower = sae.GetRelativePowerBlockForceInputData();
        //    if (dtBackRelativePower.Rows.Count > 0)
        //    {
        //        int backRelativePowerId = Convert.ToInt32(dtBackRelativePower.Rows[0]["RelativePowerId"]);
        //        sae.UpdateRelativePower_BlockForceModelData();
        //        sae.UpdateBackBlockRelativePower();

        //    }
        //    else
        //    {
        //        sae.InsertIntoRelativePower();
        //        sae.UpdateRelativePower_BlockForceModelData();
        //        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "DisplayAlertMessage", "ShowAlertForBack();", true);

        //    }
        //}
        //catch (Exception ex)
        //{
        //    ex.Message.ToString();
        //}
        //#endregion[insert into Relative power]

    
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
            lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);
            lesson = DataRepository.LessonProvider.GetByLessonId(lessonSelected);

            sae.CustomerId = athleteSelected;
            sae.LessonId = lessonSelected;
            sae.ForceDate = lesson.LessonDate;
            #region[insert into Actual Force]
            DataTable dtFrontActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockActualForceModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockActualForceModelVertical.Text);
            sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockActualForceModelTotal.Text);

            dtFrontActualPower = sae.GetActualForceFrontBlockForceInputData();
            if (dtFrontActualPower.Rows.Count > 0)
            {
                int frontActualForceId = Convert.ToInt32(dtFrontActualPower.Rows[0]["ActualForceId"]);
                sae.UpdateFrontActualForce_BlockForceModelData();
                sae.UpdateFrontBlockActualForce();
            }
            else
            {
                sae.InsertIntoFrontBlockActualForce();
                sae.UpdateFrontActualForce_BlockForceModelData();
            }

            #endregion[insert into Actual Force]

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        //#region[insert into Relative Force]
        //try
        //{
        //    DataTable dtFrontRelativeForce = new DataTable();
        //    sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockRelativeForcesAthleteHorizontal.Text);
        //    sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockRelativeForcesModelHorizontal.Text);

        //    sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockRelativeForcesAthleteVertical.Text);
        //    sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockRelativeForcesModelVertical.Text);

        //    sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockRelativeForcesAthleteTotal.Text);
        //    sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockRelativeForcesModelTotal.Text);
        //    dtFrontRelativeForce = sae.GetRelativeForcesFrontBlockForceInputData();
        //    if (dtFrontRelativeForce.Rows.Count > 0)
        //    {
        //        int frontRelativeForceId = Convert.ToInt32(dtFrontRelativeForce.Rows[0]["RelativeForcesId"]);
        //        sae.UpdateFrontRelativeForce_BlockForceModelData();
        //        sae.UpdateFrontBlockRelativeForce();
        //    }
        //    else
        //    {
        //        sae.InsertIntoFrontBlockRelativeForces();
        //        sae.UpdateFrontRelativeForce_BlockForceModelData();
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ex.Message.ToString();
        //}
        //#endregion[insert into Relative Force]

        #region[insert into Actual Power]
        try
        {
            DataTable dtfrontActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockActualPowerModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockActualPowerModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockActualPowerModelTotal.Text);
            dtfrontActualPower = sae.GetActualPowerFrontBlockForceInputData();
            if (dtfrontActualPower.Rows.Count > 0)
            {
                int frontActualPowerId = Convert.ToInt32(dtfrontActualPower.Rows[0]["ActualPowerId"]);
                sae.UpdateFrontActualPower_BlockForceModelData();
                sae.UpdateFrontBlockActualPower();
            }
            else
            {
                sae.InsertIntoFrontBlockActualPower();
                sae.UpdateFrontActualPower_BlockForceModelData();
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        #endregion[insert into Actual Power]

        //#region[insert into Relative Power]
        //try
        //{
        //    DataTable dtFrontRelativePower = new DataTable();
        //    sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockRelativePowerAthleteHorizontal.Text);
        //    sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockRelativePowerModelHorizontal.Text);

        //    sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockRelativePowerAthleteVertical.Text);
        //    sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockRelativePowerModelVertical.Text);

        //    sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockRelativePowerAthleteTotal.Text);
        //    sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockRelativePowerModelTotal.Text);
        //    dtFrontRelativePower = sae.GetRelativePowerFrontBlockForceInputData();
        //    if (dtFrontRelativePower.Rows.Count > 0)
        //    {
        //        int frontRelativePowerId = Convert.ToInt32(dtFrontRelativePower.Rows[0]["RelativePowerId"]);
        //        sae.UpdateFrontRelativePower_BlockForceModelData();
        //        sae.UpdateFrontBlockRelativePower();
        //    }
        //    else
        //    {
        //        sae.InsertIntoFrontBlockRelativePower();
        //        sae.UpdateFrontRelativePower_BlockForceModelData();
        //        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "DisplayAlertMessage", "ShowAlertForFront();", true);

        //    }
        //}
        //catch (Exception ex)
        //{
        //    ex.Message.ToString();
        //}
        //#endregion[insert into Relative power]
    }

    private void MakeTextBoxClearForBackBlockData()
    {
        txtActualForceAthleteHorizontal.Text = "";
        txtActualForceModelHorizontal.Text = "";
        txtActualForceAthleteVertical.Text = "";
        txtActualForceModelVertical.Text = "";
        txtActualForceAthleteTotal.Text = "";
        txtActualForceModelTotal.Text = "";
        //txtRelativeForcesAthleteHorizontal.Text = "";
        //txtRelativeForcesModelHorizontal.Text = "";
        //txtRelativeForcesAthleteVertical.Text = "";
        //txtRelativeForcesModelVertical.Text = "";
        //txtRelativeForcesAthleteTotal.Text = "";
        //txtRelativeForcesModelTotal.Text = "";
        txtActualPowerAthleteHorizontal.Text = "";
        txtActualPowerModelHorizontal.Text = "";
        txtActualPowerAthleteVertical.Text = "";
        txtActualPowerModelVertical.Text = "";
        txtActualPowerAthleteTotal.Text = "";
        txtActualPowerModelTotal.Text = "";
        //txtRelativePowerAthleteHorizontal.Text = "";
        //txtRelativePowerModelHorizontal.Text = "";
        //txtRelativePowerAthleteVertical.Text = "";
        //txtRelativePowerModelVertical.Text = "";
        //txtRelativePowerAthleteTotal.Text = "";
        //txtRelativePowerModelTotal.Text = "";
    }

    private void MakeTextBoxClearForFrontBlockData()
    {
        txtFrontBlockActualForceAthleteHorizontal.Text = "";
        txtFrontBlockActualForceModelHorizontal.Text = "";
        txtFrontBlockActualForceAthleteVertical.Text = "";
        txtFrontBlockActualForceModelVertical.Text = "";
        txtFrontBlockActualForceAthleteTotal.Text = "";
        txtFrontBlockActualForceModelTotal.Text = "";

        //txtFrontBlockRelativeForcesAthleteHorizontal.Text = "";
        //txtFrontBlockRelativeForcesModelHorizontal.Text = "";
        //txtFrontBlockRelativeForcesAthleteVertical.Text = "";
        //txtFrontBlockRelativeForcesModelVertical.Text = "";
        //txtFrontBlockRelativeForcesAthleteTotal.Text = "";
        //txtFrontBlockRelativeForcesModelTotal.Text = "";

        txtFrontBlockActualPowerAthleteHorizontal.Text = "";
        txtFrontBlockActualPowerModelHorizontal.Text = "";
        txtFrontBlockActualPowerAthleteVertical.Text = "";
        txtFrontBlockActualPowerModelVertical.Text = "";
        txtFrontBlockActualPowerAthleteTotal.Text = "";
        txtFrontBlockActualPowerModelTotal.Text = "";

        //txtFrontBlockRelativePowerAthleteHorizontal.Text = "";
        //txtFrontBlockRelativePowerModelHorizontal.Text = "";
        //txtFrontBlockRelativePowerAthleteVertical.Text = "";
        //txtFrontBlockRelativePowerModelVertical.Text = "";
        //txtFrontBlockRelativePowerAthleteTotal.Text = "";
        //txtFrontBlockRelativePowerModelTotal.Text = "";
    }
    protected void btnDeleteBackBlockForceData_Click(object sender, EventArgs e)
    {
        athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
        lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);

        sae.CustomerId = athleteSelected;
        sae.LessonId = lessonSelected;
        sae.DeleteFromBackBlockForceData();
        MakeTextBoxClearForBackBlockData();
    }
    protected void btnDeleteFrontBlockForceData_Click(object sender, EventArgs e)
    {
        athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
        lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);

        sae.CustomerId = athleteSelected;
        sae.LessonId = lessonSelected;
        sae.DeleteFromFrontBlockForceData();
        MakeTextBoxClearForFrontBlockData();
    }

    protected void BackAndFrontBlockForceData_Click(object sender, EventArgs e)
    {
        try
        {
            athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
            lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);
            lesson = DataRepository.LessonProvider.GetByLessonId(lessonSelected);
            DataTable dtBackActualForce = new DataTable();
            sae.CustomerId = athleteSelected;
            sae.LessonId = lessonSelected;
            sae.ForceDate = lesson.LessonDate;


            #region[insert into Actual Force]

            sae.AthleteHorizontalValue = Convert.ToInt32(txtActualForceAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtActualForceModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtActualForceAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtActualForceModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtActualForceAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtActualForceModelTotal.Text);

            dtBackActualForce = sae.GetActualForceBlockForceInputData();
            if (dtBackActualForce.Rows.Count > 0)
            {
                int backActualForceId = Convert.ToInt32(dtBackActualForce.Rows[0]["ActualForceId"]);
                sae.UpdateActualForce_BlockForceModelData();
                sae.UpdateBackBlockActualForce();
            }
            else
            {
                sae.InsertIntoActualForce();
                sae.UpdateActualForce_BlockForceModelData();
            }

            #endregion[insert into Actual Force]
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

        #region[insert into Actual Power]
        try
        {
            DataTable dtBackActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtActualPowerAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtActualPowerModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtActualPowerAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtActualPowerModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtActualPowerAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtActualPowerModelTotal.Text);
            dtBackActualPower = sae.GetActualPowerBlockForceInputData();
            if (dtBackActualPower.Rows.Count > 0)
            {
                int backactualPowerId = Convert.ToInt32(dtBackActualPower.Rows[0]["ActualPowerId"]);
                sae.UpdateActualPower_BlockForceModelData();
                sae.UpdateBackBlockActualPower();
            }
            else
            {
                sae.InsertIntoActualPower();
                sae.UpdateActualPower_BlockForceModelData();
            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        #endregion[insert into Actual Power]

        try
        {

            #region[insert into Actual Force]
            DataTable dtFrontActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockActualForceModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockActualForceModelVertical.Text);
            sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockActualForceAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockActualForceModelTotal.Text);

            dtFrontActualPower = sae.GetActualForceFrontBlockForceInputData();
            if (dtFrontActualPower.Rows.Count > 0)
            {
                int frontActualForceId = Convert.ToInt32(dtFrontActualPower.Rows[0]["ActualForceId"]);
                sae.UpdateFrontActualForce_BlockForceModelData();
                sae.UpdateFrontBlockActualForce();
            }
            else
            {
                sae.InsertIntoFrontBlockActualForce();
                sae.UpdateFrontActualForce_BlockForceModelData();
            }

            #endregion[insert into Actual Force]

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

        #region[insert into Actual Power]
        try
        {
            DataTable dtfrontActualPower = new DataTable();
            sae.AthleteHorizontalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteHorizontal.Text);
            sae.ModelHorizontalValue = Convert.ToInt32(txtFrontBlockActualPowerModelHorizontal.Text);

            sae.AthleteVerticalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteVertical.Text);
            sae.ModelVerticalValue = Convert.ToInt32(txtFrontBlockActualPowerModelVertical.Text);

            sae.AthleteTotalValue = Convert.ToInt32(txtFrontBlockActualPowerAthleteTotal.Text);
            sae.ModelTotalValue = Convert.ToInt32(txtFrontBlockActualPowerModelTotal.Text);
            dtfrontActualPower = sae.GetActualPowerFrontBlockForceInputData();
            if (dtfrontActualPower.Rows.Count > 0)
            {
                int frontActualPowerId = Convert.ToInt32(dtfrontActualPower.Rows[0]["ActualPowerId"]);
                sae.UpdateFrontActualPower_BlockForceModelData();
                sae.UpdateFrontBlockActualPower();
            }
            else
            {
                sae.InsertIntoFrontBlockActualPower();
                sae.UpdateFrontActualPower_BlockForceModelData();
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        #endregion[insert into Actual Power]

    }

    protected void btnDeleteBackAndFrontBlockForceData_Click(object sender, EventArgs e)
    {
        athleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
        lessonSelected = Convert.ToInt16(DropDownList2.SelectedValue);

        sae.CustomerId = athleteSelected;
        sae.LessonId = lessonSelected;
        sae.DeleteFromBackBlockForceData();
        MakeTextBoxClearForBackBlockData();
        sae.DeleteFromFrontBlockForceData();
        MakeTextBoxClearForFrontBlockData();

    }



}