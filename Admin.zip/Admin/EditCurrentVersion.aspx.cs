﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Admin_EditCurrentVersion : System.Web.UI.Page
public partial class Admin_EditCurrentVersion : SwingModel.UI.BasePage
{
    public int FacilityId;
    CustomerSite customersite = new CustomerSite();
    string TeachVersion;

    protected void Page_Load(object sender, EventArgs e)
    {
        FacilityId = Convert.ToInt16(Request.QueryString.Get("FacilityId"));
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(FacilityId);

        if (!IsPostBack)
        {
            Label1.Text = customersite.SiteName;
            TeachVersion = customersite.TeachVersion.ToString();
            TextBox1.Text = DateTime.Parse(TeachVersion).ToShortDateString();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        bool DoSubmit = false;

        if (TextBox1.Text.Equals("") || TextBox1.Text.Equals(null))
        {
            DoSubmit = false;
        }
        else
        {
            DoSubmit = true;
        }

        if (DoSubmit)
        {
            customersite.TeachVersion = DateTime.Parse(TextBox1.Text);

            DataRepository.CustomerSiteProvider.Update(customersite);

            this.Page.Response.Redirect("~/Admin/CurrentVersion.aspx");
        }
    }
}
