﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using MemberDownload;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Facility_AddTeachers : System.Web.UI.Page
public partial class Facility_AddTeachers : SwingModel.UI.BasePage
{
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    public GetMemberList gml = new GetMemberList();
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    
    int SelectedFacility;
    DataTable dt = new DataTable();
    int x;
    TList<TeacherSite> facilityteachers = new TList<TeacherSite>();
    Teacher teacher = new Teacher();

    protected void Page_Load(object sender, EventArgs e)
    {
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        SelectedFacility = customerprofile.CustomerSite;
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(SelectedFacility);
        Label1.Text = customersite.SiteName;
        facilityteachers = DataRepository.TeacherSiteProvider.GetAll();// (SelectedFacility);
        //facilityteachers = DataRepository.TeacherSiteProvider.GetBySiteId(SelectedFacility);
        dt.Columns.Add("TeacherId", typeof(int));
        dt.Columns.Add("First Name", typeof(string));
        dt.Columns.Add("Last Name", typeof(string));
        dt.Columns.Add("Work Phone", typeof(string));
        dt.Columns.Add("Mobile Phone", typeof(string));
        dt.Columns.Add("Fax", typeof(string));
        dt.Columns.Add("AspNetMembershipUserId", typeof(string));
        dt.Columns.Add("Picture Path", typeof(string));
        dt.Columns.Add("Bio Text", typeof(string));
        dt.Columns.Add("Welcome Text", typeof(string));
        dt.Columns.Add("Teaching Password", typeof(string));
        dt.Columns.Add("TeacherLocationId", typeof(int));
        dt.Columns.Add("Facility",typeof(string));
        x = 0;
        foreach (TeacherSite ts in facilityteachers)
        {
            teacher = DataRepository.TeacherProvider.GetByTeacherId(ts.TeacherId);
            customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(ts.SiteId);
            dt.Rows.Add(teacher.TeacherId, teacher.FirstName, teacher.LastName, teacher.WorkPhone, teacher.MobilePhone, teacher.Fax, teacher.AspnetMembershipUserId.ToString(), teacher.PicturePath, teacher.BioText, teacher.WelcomeText, teacher.TeachingPassword, ts.TeacherLocationId,customersite.SiteName);
            x++;
        }
        GridView1.DataSource = dt;
        GridView1.DataBind();

        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            int y = 0;
            foreach (CustomerSite cs in customersites)
            {
                y++;
                DropDownList1.Items.Add(cs.SiteName);
                DropDownList1.Items[y].Value = cs.CustomerSiteId.ToString();
            }
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int RowID = Convert.ToInt32(e.CommandArgument);
        TeacherSite tas = new TeacherSite();

        if (e.CommandName == "DeleteRow")
        {
            //MessageBox.Show("DeleteRow Clicked");
            //MessageBox.Show(RowID.ToString());
            //MessageBox.Show(dt.Rows[RowID].Field<int>("TeacherId").ToString());
            //MessageBox.Show(dt.Rows[RowID].Field<int>("TeacherLocationId").ToString());
            tas.TeacherLocationId = dt.Rows[RowID].Field<int>("TeacherLocationId");
            DataRepository.TeacherSiteProvider.Delete(tas);

            this.Page.Response.Redirect("~/Admin/AddTeachers.aspx");
        }


        if (e.CommandName == "EditRow")
        {
            this.Page.Response.Redirect("~/Admin/EditTeacher.aspx?TeacherId=" + dt.Rows[RowID].Field<int>("TeacherId").ToString());
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = -9999;

        ListBox1.Items.Clear();

        if (TextBox1.Text.Equals(null) || TextBox1.Text.Equals("") || TextBox2.Text.Equals(null) || TextBox2.Text.Equals(""))
        {
            ListBox1.Items.Add("No Matches");
        }
        else
        {
            //i = gml.GetMembers(TextBox1.Text, TextBox2.Text, TextBox3.Text);
            i = gml.GetMembers(TextBox1.Text, TextBox2.Text, "");

            if (gml.GuidMatch.Count.Equals(0))
            {
                //MessageBox.Show("No Matches");
                ListBox1.Items.Add("No Matches");
            }
            else
            {
                int x = 0;
                string ListBoxItem = "";
                foreach (string MemberGuid in gml.GuidMatch)
                {
                    ListBoxItem = gml.FirstNameMatch[x].ToString() + " " + gml.LastNameMatch[x].ToString() + ", " + gml.EmailMatch[x].ToString() + ", " + gml.UsernameMatch[x].ToString();

                    ListBox1.Items.Add(ListBoxItem);
                    ListBox1.Items[x].Value = gml.CustomerIdMatch[x].ToString() + "," + gml.UsernameMatch[x].ToString() + "|" + gml.EmailMatch[x].ToString();
                    x++;
                }
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
       
        if (!ListBox1.SelectedValue.Equals("No Matches") && !ListBox1.Items.Count.Equals(0))
        {
            Customer tc = new Customer();
            Teacher teach = new Teacher();
            TeacherSite teachersite = new TeacherSite();
            int customerid = -1;
            bool CurrentTeacher = false;
            int SelectedFacilityNew = Convert.ToInt16(DropDownList1.SelectedValue);

            if (!ListBox1.SelectedValue.Equals("No Matches") && !ListBox1.Items.Count.Equals(0))
            {
                int x = ListBox1.SelectedIndex;
                int comma = ListBox1.Items[x].Value.IndexOf(",");
                customerid = Convert.ToInt16(ListBox1.Items[x].Value.Substring(0, comma));
            }
            //MessageBox.Show("customerid: " + customerid.ToString());
            if (!customerid.Equals(-1))
            {
                tc = DataRepository.CustomerProvider.GetByCustomerId(customerid);
                try
                {
                    teach = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(tc.AspnetMembershipUserId)[0];
                    //MessageBox.Show("Teacher First Name: " + teach.FirstName);
                    CurrentTeacher = true;
                }
                catch (Exception ex)
                {
                    //Selected member is not a current Teacher in database
                    //MessageBox.Show("Not a current teacher");
                    CurrentTeacher = false;
                }

                if (CurrentTeacher)
                {
                    teachersite.SiteId = SelectedFacilityNew;
                    teachersite.TeacherId = teach.TeacherId;
                    DataRepository.TeacherSiteProvider.Insert(teachersite);
                }
                else
                {
                    teach.FirstName = tc.FirstName;
                    teach.LastName = tc.LastName;
                    teach.WorkPhone = tc.PhoneWork;
                    teach.MobilePhone = tc.PhoneMobile;
                    teach.AspnetMembershipUserId = tc.AspnetMembershipUserId;
                    teach.PicturePath = "/TeacherPics/" + tc.FirstName + tc.LastName + ".jpg";
                    teach.BioText = "Bio Text";
                    teach.WelcomeText = "<P>Welcome to the SwingModel learning program. If you haven't "
                        + "taken a look at your most recent lesson video(s), please visit the My Swing "
                        + "page. There you will be able to review the errors we discussed during the "
                        + "lesson. For further review, you may click on the My Summary button in the "
                        + "video player. Continue working the drills as discussed in the lesson. If "
                        + "you'd like to ask questions about your swing or golf game, click on the Email "
                        + "My Teacher link. Be sure to schedule a lesson with me in the near future. You "
                        + "can request a lesson appointment time by clicking on the Schedule A Lesson "
                        + "link.</P>";
                    teach.TeachingPassword = tc.FirstName;
                    DataRepository.TeacherProvider.Insert(teach);
                    //if (DropDownList1.SelectedValue!= "-1")
                    //{
                    //    teachersite.SiteId = SelectedFacilityNew;
                    //    teachersite.TeacherId = teach.TeacherId;
                    //    DataRepository.TeacherSiteProvider.Insert(teachersite);
                    //}
                    //else
                    //{
                    teachersite.SiteId = SelectedFacilityNew; ;
                    teachersite.TeacherId = teach.TeacherId;
                    DataRepository.TeacherSiteProvider.Insert(teachersite);

                    //}
                }
            }

            this.Page.Response.Redirect("~/Admin/AddTeachers.aspx");
        }
        else
        {
            Label5.Text = "Please select Teacher to Add";
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
    