﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;
using System.Collections.Generic;
using System.Data.SqlClient;
public partial class Admin_LessonData : System.Web.UI.Page
{
    TList<Lesson> lessonlist = new TList<Lesson>();
    string location;
    int lessonid;
    public string wmpfile = "";
    int x;

    public Customer customerid;
    public Customer cust;
    public CustomerProfile customerprofile;
    public CustomerProfile customerprofile1;
    TList<Customer> customer = new TList<Customer>();
    Movie movieSide;
    Movie CurrentMovieSide;
    Movie CurrentMovieBack;
    bool isMovieClipsExist = false;
    bool isSummarySessionExist = false;
    SummaryMovie summaryMovie;
    int _lessonid;
    int summarysessionlessionid = 0;
    string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();
    CompuSportDAL.SprintData _SprintData = new CompuSportDAL.SprintData();
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        bool AthleteAlreadyInList = false;
        customerid = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customerid.CustomerId)[0];
        if (!IsPostBack)
        {
            customer = DataRepository.CustomerProvider.GetAll();
            customer.Sort("FirstName");
            foreach (var item in customer)
            {
                cust = DataRepository.CustomerProvider.GetByCustomerId(item.CustomerId);
                {
                    if (DropDownList1.Items.Count > 0)
                    {
                        if (DropDownList1.Items.Contains(DropDownList1.Items.FindByValue(item.CustomerId.ToString())))
                            AthleteAlreadyInList = true;
                        else
                            AthleteAlreadyInList = false;
                    }

                    if (!AthleteAlreadyInList)
                    {
                        x++;
                        DropDownList1.Items.Add(item.FirstName + " " + item.LastName);
                        DropDownList1.Items[x].Value = item.CustomerId.ToString();

                        continue;
                    }
                }
            }
        }
    }





    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!DropDownList1.SelectedValue.Equals("noathlete"))
        {
            LoadExistingLocation();
        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label117.Text = "";
        //ClearData();    

        lblDate.Visible = true;
        lblDateEx.Visible = true;
        txtDate.Visible = true;

        lblLocation.Visible = true;
        txtLocation.Visible = true;
        lblexlocation.Visible = true;

        lblTime.Visible = true;
        txtTime.Visible = true;
        lblExTime.Visible = true;

        //txtDate.Text = "";
        //txtTime.Text = "";
        //txtLocation.Text = "";
        btnSubmit.Visible = true;

        #region[display date location and time in text box if exists]
        try
        {
            Lesson lesson = new Lesson();
            int LessonSelected = 0;
            LessonSelected = Convert.ToInt32(DropDownList2.SelectedValue);
            lesson = DataRepository.LessonProvider.GetByLessonId(LessonSelected);
            lesson.CustomerId = Convert.ToInt32(DropDownList1.SelectedValue);
            lesson.LessonTypeId = 2;
            if (DropDownList2.SelectedValue != "")
            {
                DateTime dt = lesson.LessonDate;
                //string time = dt.TimeOfDay.ToString();
                //string date = dt.Date.ToString();
                txtTime.Text = dt.TimeOfDay.ToString();
                txtDate.Text = dt.Date.ToShortDateString();
                string location = sae.SelectLessonlocation(lesson.LessonId.ToString());
                txtLocation.Text = location.ToString();
            }
        }
        catch { }
        #endregion[display date location and time in text box if exists]
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Lesson lesson = new Lesson();
        int LessonSelected = 0;
        #region[Insert or Update Lession data]
        try
        {
            Label1.Text = "";
            if (DropDownList2.SelectedValue != "")
            {
                LessonSelected = Convert.ToInt32(DropDownList2.SelectedValue);
                lesson = DataRepository.LessonProvider.GetByLessonId(LessonSelected);
                lesson.CustomerId = Convert.ToInt32(DropDownList1.SelectedValue);
                Customer custmer = DataRepository.CustomerProvider.GetByCustomerId(lesson.CustomerId);
                DateTime movieDateTime;
                try
                {
                    string time = txtTime.Text;
                    lesson.LessonDate = Convert.ToDateTime(txtDate.Text + " " + time);
                    location = txtLocation.Text;
                    lessonid = Convert.ToInt32(DropDownList2.SelectedValue);
                    movieDateTime = lesson.LessonDate;
                }
                catch
                {
                    Label1.Text = "Please enter valid [MM-dd-yyyy]";
                    return;
                }

                lesson.CustomerId = custmer.CustomerId;
                DataRepository.LessonProvider.Update(lesson);
                sae.UpdateLessonAndMovieDate(location, lessonid, movieDateTime);
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        #endregion[Insert or Update Lession data ]
        LoadExistingLocation();
        txtDate.Text = "";
        txtTime.Text = "";
        txtLocation.Text = "";

    }
    private void LoadExistingLocation()
    {
        int AthleteSelected = Convert.ToInt16(DropDownList1.SelectedValue);
        lessonlist = DataRepository.LessonProvider.GetByCustomerId(AthleteSelected);
        if (lessonlist.Count != 0)
        {
            Label2.Visible = false;
            DropDownList2.Visible = true;
            Customer cust = DataRepository.CustomerProvider.GetByCustomerId(AthleteSelected);
            Lesson lessonid1 = DataRepository.LessonProvider.GetByCustomerId(cust.CustomerId)[0];
            string athletelessonid = lessonid1.LessonId.ToString();
            lessonlist.Sort("LessonDate DESC");
            x = 0;
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("Select Analysis Date and Location");
            DropDownList2.Items[0].Value = "";

            foreach (Lesson lesson in lessonlist)
            {
                string location = sae.SelectLessonlocation(lesson.LessonId.ToString());

                if (lesson.LessonTypeId.Equals(2))
                {
                    x++;
                    // DropDownList2.Items.Add(lesson.LessonDate.ToString("MM/dd/yyyy HH:mm:ss"));
                    DropDownList2.Items.Add(lesson.LessonDate.ToString("MM/dd/yyyy") + " - " + location);
                    DropDownList2.Items[x].Value = lesson.LessonId.ToString();
                }
            }
        }
        else
        {
            Label2.Visible = true;
            DropDownList2.Visible = false;
        }
    }
}
