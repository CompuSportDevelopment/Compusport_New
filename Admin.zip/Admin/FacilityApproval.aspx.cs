﻿
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

public partial class Admin_FacilityApprovelNew : System.Web.UI.Page
{
    public TList<CustomerSite> customersite = new TList<CustomerSite>();
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        customersite = DataRepository.CustomerSiteProvider.GetAll();
        customersite.Sort("SiteName ASC");
        dt.Columns.Add("FacilityId", typeof(string));
        dt.Columns.Add("Facility", typeof(string));
        dt.Columns.Add("FacilityAdministratorId", typeof(int));      
        dt.Columns.Add("FacilityApproval", typeof(string));
            string facapprove = string.Empty;
        foreach (CustomerSite cs in customersite)
        {
            int y = Convert.ToInt16(cs.IsApproved);
            if (y==0)	{
                facapprove = "No";
	            }
            else
	            {
                facapprove= "Yes";
	            }

            dt.Rows.Add(cs.CustomerSiteId, cs.SiteName,cs.FacilityAdministratorId, facapprove);
            
        }
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int RowID = Convert.ToInt32(e.CommandArgument);

        if (e.CommandName == "EditRow")
        {
            //  this.Page.Response.Redirect("~/Admin/FacilityApproval.aspx");dt.Rows[RowID].ItemArray[0]

           //this.Page.Response.Redirect("~/Admin/FacilityApproval.aspx?FacilityId=" + dt.Rows[RowID].Field<int>("FacilityId").ToString());
            this.Page.Response.Redirect("~/Admin/EditFacilityApproval.aspx?FacilityId=" + dt.Rows[RowID].ItemArray[0].ToString());
        }

    }
}
