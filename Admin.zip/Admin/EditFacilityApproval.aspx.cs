﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using SwingModel.Data;
using SwingModel.Entities;

public partial class Admin_FacilityApproval : System.Web.UI.Page
{
    public int FacilityId;
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    public CustomerSite customersite;

    protected void Page_Load(object sender, EventArgs e)
    {
        FacilityId = Convert.ToInt16(Request.QueryString.Get("FacilityId"));
        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        if (DropDownList1.Items.Count.Equals(0))
        {
            DropDownList1.Items.Clear();
            DropDownList1.Items.Add("Make a Selection");
            DropDownList1.Items[0].Value = "-1";
            int x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList1.Items.Add(cs.SiteName);
                DropDownList1.Items[x].Value = cs.CustomerSiteId.ToString();
            }
        }
        DropDownList1.SelectedValue = FacilityId.ToString();
        DropDownList1.Visible = false;
        lblFacility.Text = DropDownList1.SelectedItem.Text.ToString();
        if (!IsPostBack)
        {
            if (!DropDownList1.SelectedValue.Equals("-1"))
            {
                customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(Convert.ToInt16(DropDownList1.SelectedValue));
                if (customersite.IsApproved.Equals(1))
                {
                    RadioButtonList1.Items[0].Selected = true;
                    RadioButtonList1.Items[1].Selected = false;
                }
                else
                {
                    RadioButtonList1.Items[1].Selected = true;
                    RadioButtonList1.Items[0].Selected = false;
                }
            }

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!DropDownList1.SelectedValue.Equals("-1"))
        {
            customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(Convert.ToInt16(DropDownList1.SelectedValue));
            if (RadioButtonList1.Items[0].Selected.Equals(true))
                customersite.IsApproved = 1;
            else
                customersite.IsApproved = 0;

            DataRepository.CustomerSiteProvider.Update(customersite);
            this.Page.Response.Redirect("~/Admin/FacilityApproval.aspx");
        }
        else
        {
            RadioButtonList1.Items[0].Selected = false;
            RadioButtonList1.Items[1].Selected = false;
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!DropDownList1.SelectedValue.Equals("-1"))
        {
            customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(Convert.ToInt16(DropDownList1.SelectedValue));
            if (customersite.IsApproved.Equals(1))
            {
                RadioButtonList1.Items[0].Selected = true;
                RadioButtonList1.Items[1].Selected = false;
            }
            else
            {
                RadioButtonList1.Items[1].Selected = true;
                RadioButtonList1.Items[0].Selected = false;
            }
        }
        else
        {
            RadioButtonList1.Items[0].Selected = false;
            RadioButtonList1.Items[1].Selected = false;
        }
    }
}
