﻿using System;
using System.Collections;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using System.Net.Mail;

//public partial class Admin_SendEmail : System.Web.UI.Page
public partial class Admin_SendEmail : SwingModel.UI.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        MailAddress from = new MailAddress("info@swingmodel.com");
        MailAddress to = new MailAddress(TextBox3.Text);
        MailMessage message = new MailMessage(from, to);

        message.IsBodyHtml = true;
        message.Subject = TextBox1.Text;
        message.Body = "<img src=\"http://www.swingmodel.com/Images/EmailHeader.jpg\"><br><br>" + FreeTextBox1.Text;

        Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        MailSettingsSectionGroup settings = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");
        SmtpClient client = new SmtpClient(settings.Smtp.Network.Host);
        try
        {
            client.Send(message);
            Response.Write("Your Email has been sent sucessfully - Thank You");
        }
        catch (Exception ex)
        {
            Response.Write("Send failure: " + ex.ToString());
        }
    }
}
