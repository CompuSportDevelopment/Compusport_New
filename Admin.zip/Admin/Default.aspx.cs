using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SwingModel.Entities;
using SwingModel.Data;

//public partial class Admin_Default : System.Web.UI.Page
public partial class Admin_Default : SwingModel.UI.BasePage
{
    Customer customer = new Customer();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Label3.Text = "";
            customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
            Label3.Text = customer.FirstName + " " + customer.LastName;
        }
        catch
        {
        }
    }
}
