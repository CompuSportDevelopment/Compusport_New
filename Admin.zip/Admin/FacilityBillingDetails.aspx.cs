﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;
using Sweeten;
using UnSweeten;

//public partial class Admin_FacilityBillingDetails : System.Web.UI.Page
public partial class Admin_FacilityBillingDetails : SwingModel.UI.BasePage
{
    int x;
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    CustomerSiteBillingDetails csbd = new CustomerSiteBillingDetails();
    public TList<CustomerSite> customersites = new TList<CustomerSite>();
    bool BillingDetailsExist;
    EN en = new EN();
    DN dn = new DN();
    string tempdn;
    string displaydn;
    string sendCCNumber;

    //protected override void OnPreLoad(EventArgs e)
    //{
    //    customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
    //    customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
    //    customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
    //    try
    //    {
    //        csbd = DataRepository.CustomerSiteBillingDetailsProvider.GetByCustomerSiteId(customerprofile.CustomerSite)[0];
    //        BillingDetailsExist = true;
    //    }
    //    catch (Exception ex)
    //    {
    //        BillingDetailsExist = false;
    //    }
    //    //MessageBox.Show("BillingDetailsExist: " + BillingDetailsExist.ToString());

    //    for (int i = (Convert.ToInt16(DateTime.Today.Year) - 2); i < Convert.ToInt16(DateTime.Today.Year) + 16; i++)
    //    {
    //        DropDownList3.Items.Add(i.ToString());
    //        DropDownList3.Items[(i - Convert.ToInt16(DateTime.Today.Year) + 2)].Value = i.ToString();
    //    }

    //    //Label2.Text = customersite.SiteName;

    //    if (!IsPostBack)
    //    {
    //        TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
    //        DropDownList4.Items.Clear();
    //        DropDownList4.Items.Add("Select Country");
    //        DropDownList4.Items[0].Value = "0";
    //        DropDownList4.Items[0].Selected = false;
    //        x = 0;
    //        foreach (CountryLookup country in countries)
    //        {
    //            x++;
    //            DropDownList4.Items.Add(country.CountryName);
    //            DropDownList4.Items[x].Value = country.CountryId.ToString();
    //        }
    //    }

    //    if (BillingDetailsExist)
    //    {
    //        TextBox1.Text = csbd.Firstname;
    //        TextBox2.Text = csbd.Lastname;
    //        DropDownList1.SelectedValue = csbd.Type;
    //        //MessageBox.Show("csbd.Number: " + csbd.Number);
    //        //MessageBox.Show("DN: " + dn.DecryptNumber(csbd.Number.ToString()));
    //        tempdn = dn.DecryptNumber(csbd.Number);
    //        if (tempdn.Length.Equals(16))
    //            displaydn = "************" + tempdn.Substring(12, 4);
    //        else
    //            displaydn = "***********" + tempdn.Substring(11, 4);
    //        TextBox3.Text = displaydn;
    //        DropDownList2.SelectedValue = csbd.Expiration.Substring(0, 2);
    //        DropDownList3.SelectedValue = "20" + csbd.Expiration.Substring(2, 2);
    //        TextBox4.Text = csbd.Cvv;
    //        if (!IsPostBack)
    //            DropDownList4.SelectedValue = csbd.Country.ToString();
    //        TextBox5.Text = csbd.Address;
    //        TextBox6.Text = csbd.City;
    //        TextBox8.Text = csbd.Zip;
    //    }

    //    if (DropDownList4.SelectedValue.Equals("248") || DropDownList4.SelectedValue.Equals("287"))
    //    {
    //        TextBox7.Visible = false;
    //        DropDownList5.Visible = true;

    //        DropDownList5.Items.Clear();
    //        DropDownList5.Items.Add("Select State/Province");
    //        DropDownList5.Items[0].Value = "0";
    //        x = 0;
    //        TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(Convert.ToInt16(DropDownList4.SelectedValue));
    //        foreach (StateProvince sp in states)
    //        {
    //            x++;
    //            DropDownList5.Items.Add(sp.StateProvinceName);
    //            DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
    //            if (BillingDetailsExist)
    //            {
    //                if (sp.StateProvinceAbbvr.Equals(csbd.State))
    //                    DropDownList5.Items[x].Selected = true;
    //            }
    //        }
    //        if (!BillingDetailsExist)
    //            DropDownList5.SelectedValue = DropDownList5.Items[0].Value;
    //    }
    //    else
    //    {
    //        TextBox7.Visible = true;
    //        DropDownList5.Visible = false;
    //        if (BillingDetailsExist)
    //            TextBox7.Text = csbd.State;
    //        else
    //            TextBox7.Text = "";
    //    }
    //}

    protected void Page_Load(object sender, EventArgs e)
    {
        customersites = DataRepository.CustomerSiteProvider.GetAll();
        customersites.Sort("SiteName ASC");

        Label14.Text = "";


        if (ddlfacility.Items.Count.Equals(0))
        {
            ddlfacility.Items.Clear();
            ddlfacility.Items.Add("Make a Selection");
            ddlfacility.Items[0].Value = "-1";
            int x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                ddlfacility.Items.Add(cs.SiteName);
                ddlfacility.Items[x].Value = cs.CustomerSiteId.ToString();
            }
        }
        if (ddlfacility.SelectedValue.Equals("-1"))
        {
            ClearData();
        }

        if (!IsPostBack)
        {
            TList<CountryLookup> countries = DataRepository.CountryLookupProvider.GetAll();
            DropDownList4.Items.Clear();
            DropDownList4.Items.Add("Select Country");
            DropDownList4.Items[0].Value = "0";
            DropDownList4.Items[0].Selected = false;
            x = 0;
            foreach (CountryLookup country in countries)
            {
                x++;
                DropDownList4.Items.Add(country.CountryName);
                DropDownList4.Items[x].Value = country.CountryId.ToString();
            }
        }
    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList4.SelectedValue.Equals("248") || DropDownList4.SelectedValue.Equals("287"))
        {
            TextBox7.Visible = false;
            DropDownList5.Visible = true;

            DropDownList5.Items.Clear();
            DropDownList5.Items.Add("Select State/Province");
            DropDownList5.Items[0].Value = "0";
            x = 0;
            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(Convert.ToInt16(DropDownList4.SelectedValue));
            foreach (StateProvince sp in states)
            {
                x++;
                DropDownList5.Items.Add(sp.StateProvinceName);
                DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
            }
        }
        else
        {
            TextBox7.Visible = true;
            DropDownList5.Visible = false;
        }
    }

    private void ClearData()
    {
        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        DropDownList3.Visible = false;
        DropDownList4.Visible = false;
        DropDownList5.Visible = false;
        TextBox1.Visible = false;
        TextBox2.Visible = false;
        TextBox3.Visible = false;
        TextBox4.Visible = false;
        TextBox5.Visible = false;
        TextBox6.Visible = false;
        TextBox7.Visible = false;
        TextBox8.Visible = false;


        Label3.Visible = false;
        Label4.Visible = false;
        // Label16.Visible = false;
        Label5.Visible = false;
        Label6.Visible = false;
        // Label17.Visible = false;
        Label7.Visible = false;
        Label8.Visible = false;
        Label9.Visible = false;
        Label10.Visible = false;
        Label11.Visible = false;
        // Label21.Visible = false;
        Label12.Visible = false;
        Label13.Visible = false;
        TextBox6.Visible = false;

        Button1.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        bool InsertData = false;
        bool BillingDetailsExist = false;
        string selval = ddlfacility.SelectedItem.Value.ToString();
        CustomerSiteBillingDetails csbd = new CustomerSiteBillingDetails();
        try
        {
            csbd = DataRepository.CustomerSiteBillingDetailsProvider.GetByCustomerSiteId(Convert.ToInt32(selval))[0];
            BillingDetailsExist = true;
            InsertData = true;

        }
        catch { }
        // customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(Convert.ToInt32(selval));
        // customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        bool BillingDetailsUpdated = false;
        string exstring = "";

        //MessageBox.Show("fn: " + TextBox1.Text);
        if (TextBox1.Text.Equals("") || TextBox1.Text.Equals(null))
        {
            InsertData = false;
            Label14.Text = "Please complete all fields, and click Submit again.";
            Label14.Visible = true;
            Label15.Text = "<< First Name is required.";
            Label15.Visible = true;
        }
        else
        {
            InsertData = true;
            Label14.Visible = false;
            Label15.Visible = false;
        }


        if (InsertData)
        {
            csbd.CustomerSiteId = customersite.CustomerSiteId;
            csbd.Firstname = TextBox1.Text;
            csbd.Lastname = TextBox2.Text;
            csbd.Type = DropDownList1.SelectedValue;
            //MessageBox.Show("CCNumber: " + TextBox3.Text.ToString());
            //MessageBox.Show("EN: " + en.EncryptNumber(TextBox3.Text).ToString());
            tempdn = dn.DecryptNumber(csbd.Number);
            if (TextBox3.Text.Contains("*"))
                sendCCNumber = tempdn;
            else
                sendCCNumber = TextBox3.Text;
            csbd.Number = en.EncryptNumber(sendCCNumber);
            csbd.Expiration = DropDownList2.SelectedValue + DropDownList3.SelectedValue.Substring(2, 2);
            //MessageBox.Show("csbd.Expiration: " + csbd.Expiration);
            csbd.Cvv = TextBox4.Text;
            csbd.Country = Convert.ToInt16(DropDownList4.SelectedValue);
            csbd.Address = TextBox5.Text;
            csbd.City = TextBox6.Text;
            if (DropDownList4.SelectedValue.Equals("248") || DropDownList4.SelectedValue.Equals("287"))
                csbd.State = DropDownList5.SelectedValue;
            else
                csbd.State = TextBox7.Text;
            csbd.Zip = TextBox8.Text;
            csbd.Amount = Convert.ToDecimal(100);

            try
            {
                if (BillingDetailsExist)
                    DataRepository.CustomerSiteBillingDetailsProvider.Update(csbd);
                else
                    DataRepository.CustomerSiteBillingDetailsProvider.Insert(csbd);
                BillingDetailsUpdated = true;
            }
            catch (Exception ex)
            {
                BillingDetailsUpdated = false;
                exstring = ex.ToString();
            }

            if (BillingDetailsUpdated)
            {
                Label14.Text = "Your details have been updated in the database.";
                Label14.Visible = true;
            }
            else
            {
                Label14.Text = "Your details were NOT updated! " + exstring;
                Label14.Visible = true;
            }
        }
        ClearData();
        ddlfacility.SelectedValue = "-1";
    }

    protected void ddlfacility_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selval = ddlfacility.SelectedItem.Value.ToString();

        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        DropDownList3.Visible = false;
        DropDownList4.Visible = false;

        TextBox1.Text = string.Empty;
        TextBox2.Text = string.Empty;
        TextBox3.Text = string.Empty;
        TextBox4.Text = string.Empty;
        TextBox5.Text = string.Empty;
        TextBox6.Text = string.Empty;
        TextBox7.Text = string.Empty;
        TextBox8.Text = string.Empty;

        // customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(Convert.ToInt32(selval));
        //customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        // customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        try
        {
            //csbd = DataRepository.CustomerSiteBillingDetailsProvider.GetByCustomerSiteId(customerprofile.CustomerSite)[0];
            csbd = DataRepository.CustomerSiteBillingDetailsProvider.GetByCustomerSiteId(customersite.CustomerSiteId)[0];
            BillingDetailsExist = true;
        }
        catch (Exception ex)
        {
            BillingDetailsExist = false;
        }
        //MessageBox.Show("BillingDetailsExist: " + BillingDetailsExist.ToString());

        for (int i = (Convert.ToInt16(DateTime.Today.Year) - 2); i < Convert.ToInt16(DateTime.Today.Year) + 16; i++)
        {
            DropDownList3.Items.Add(i.ToString());
            DropDownList3.Items[(i - Convert.ToInt16(DateTime.Today.Year) + 2)].Value = i.ToString();
        }

        // Label2.Text = customersite.SiteName;



        if (BillingDetailsExist)
        {

            TextBox1.Text = csbd.Firstname;
            TextBox2.Text = csbd.Lastname;
            DropDownList1.SelectedValue = csbd.Type;
            //MessageBox.Show("csbd.Number: " + csbd.Number);
            //MessageBox.Show("DN: " + dn.DecryptNumber(csbd.Number.ToString()));
            tempdn = dn.DecryptNumber(csbd.Number);
            if (tempdn.Length.Equals(16))
                displaydn = "************" + tempdn.Substring(12, 4);
            else
                displaydn = "***********" + tempdn.Substring(11, 4);
            TextBox3.Text = displaydn;
            DropDownList2.SelectedValue = csbd.Expiration.Substring(0, 2);//
            // DropDownList3.SelectedValue = "20" + csbd.Expiration.Substring(2, 2);
            TextBox4.Text = csbd.Cvv;
            //if (!IsPostBack)
            DropDownList4.SelectedValue = csbd.Country.ToString();
            TextBox5.Text = csbd.Address;
            TextBox6.Text = csbd.City;
            TextBox8.Text = csbd.Zip;
        }

        if (DropDownList4.SelectedValue.Equals("248") || DropDownList4.SelectedValue.Equals("287"))
        {
            TextBox7.Visible = false;
            DropDownList5.Visible = true;

            DropDownList5.Items.Clear();
            DropDownList5.Items.Add("Select State/Province");
            DropDownList5.Items[0].Value = "0";
            x = 0;
            TList<StateProvince> states = DataRepository.StateProvinceProvider.GetByCountry(Convert.ToInt16(DropDownList4.SelectedValue));
            foreach (StateProvince sp in states)
            {
                x++;
                DropDownList5.Items.Add(sp.StateProvinceName);
                DropDownList5.Items[x].Value = sp.StateProvinceAbbvr;
                if (BillingDetailsExist)
                {
                    if (sp.StateProvinceAbbvr.Equals(csbd.State))
                        DropDownList5.Items[x].Selected = true;
                }
            }
            if (!BillingDetailsExist)
                DropDownList5.SelectedValue = DropDownList5.Items[0].Value;
        }
        else
        {
            TextBox7.Visible = true;
            DropDownList5.Visible = false;
            if (BillingDetailsExist)
                TextBox7.Text = csbd.State;
            else
                TextBox7.Text = "";
        }

        if (!ddlfacility.SelectedValue.Equals("-1"))
        {
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            DropDownList3.Visible = true;
            DropDownList4.Visible = true;

            TextBox1.Visible = true;
            TextBox2.Visible = true;
            TextBox3.Visible = true;
            TextBox4.Visible = true;
            TextBox5.Visible = true;
            TextBox6.Visible = true;
            //TextBox7.Visible = true;
            TextBox8.Visible = true;

            Label3.Visible = true;
            Label4.Visible = true;
            // Label16.Visible = true;
            Label5.Visible = true;
            Label6.Visible = true;
            // Label17.Visible = true;
            Label7.Visible = true;
            Label8.Visible = true;
            Label9.Visible = true;
            Label10.Visible = true;
            Label11.Visible = true;
            // Label21.Visible = true;
            Label12.Visible = true;
            Label13.Visible = true;
            TextBox6.Visible = true;

            Button1.Visible = true;
        }

    }
}
