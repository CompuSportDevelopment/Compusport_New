﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Web.Script.Serialization;
using System.Windows.Forms;

//public partial class Users_MySwing : System.Web.UI.Page
public partial class Users_tstest : SwingModel.UI.BasePage
{
    Customer customer;
    TList<Lesson> lessons;
    bool lessonsexist = false;
    bool summaryexist = false;

    protected override void OnPreLoad(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
