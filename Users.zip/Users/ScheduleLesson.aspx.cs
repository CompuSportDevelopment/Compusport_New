﻿using System;
using System.Collections;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using System.Net.Mail;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_ScheduleLesson : System.Web.UI.Page
public partial class Users_ScheduleLesson : SwingModel.UI.BasePage
{
    int x;
    Teacher teacher = new Teacher();
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    int MemberHomeSite = 0;
    int MemberTeacher = 0;
    Teacher teachr = new Teacher();
    bool CustomerSiteChanged = false;
    string SelectedCustomerSite = "notta";
    string SelectedTeacher = "notta";
    bool EndDateEarly = false;
    string MemberEmail = Membership.GetUser().Email;

    protected override void OnPreRender(EventArgs e)
    {
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        MemberHomeSite = customerprofile.CustomerSite;
        MemberTeacher = customerprofile.Teacher;
        TextBox4.Text = MemberEmail;

        CheckProfiles myCheckProfiles = new CheckProfiles();

        //MessageBox.Show(Convert.ToString(myCheckProfiles.Personal()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Address()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Contact()));

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Golf() && myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }
        }

        if (!CustomerSiteChanged)
        {
            TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
            //if (DropDownList8.SelectedIndex <= 0)
                DropDownList8.Items.Clear();
            DropDownList8.Items.Add("Select Location");
            DropDownList8.Items[0].Value = "0";
            x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList8.Items.Add(cs.SiteName);
                DropDownList8.Items[x].Value = cs.CustomerSiteId.ToString();
                if (Convert.ToInt16(DropDownList8.Items[x].Value).Equals(Convert.ToInt16(MemberHomeSite)))
                    DropDownList8.Items[x].Selected = true;
            }
            //if (!SelectedCustomerSite.Equals("") && !SelectedCustomerSite.Equals(null))
            if (!SelectedCustomerSite.Equals("notta"))
                    DropDownList8.SelectedValue = SelectedCustomerSite;

            if (Convert.ToInt16(DropDownList8.SelectedValue).Equals(Convert.ToInt16(MemberHomeSite)))
            {
                TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList8.SelectedValue));
                DropDownList9.Items.Clear();
                DropDownList9.Items.Add("Select Teacher");
                DropDownList9.Items[0].Value = "0";
                x = 0;
                foreach (TeacherSite tas in teachersatsite)
                {
                    x++;
                    teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                    DropDownList9.Items.Add(teachr.FirstName + " " + teachr.LastName);
                    DropDownList9.Items[x].Value = teachr.TeacherId.ToString();
                    if (Convert.ToInt16(DropDownList9.Items[x].Value).Equals(Convert.ToInt16(MemberTeacher)))
                        DropDownList9.Items[x].Selected = true;
                }
            }
            else
            {
                TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList8.SelectedValue));
                DropDownList9.Items.Clear();
                DropDownList9.Items.Add("Select Teacher");
                DropDownList9.Items[0].Value = "0";
                DropDownList9.Items[0].Selected = true;
                x = 0;
                foreach (TeacherSite tas in teachersatsite)
                {
                    x++;
                    teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                    DropDownList9.Items.Add(teachr.FirstName + " " + teachr.LastName);
                    DropDownList9.Items[x].Value = teachr.TeacherId.ToString();
                }
            }
        }
        //if (!SelectedTeacher.Equals("") && !SelectedTeacher.Equals(null))
        if (!SelectedTeacher.Equals("notta"))
                DropDownList9.SelectedValue = SelectedTeacher;

        if (TextBox2.Text.Equals("") || TextBox2.Text.Equals(null))
        {
            Label9.Text = "Please Select A Beginning Date";
            Label9.Visible = true;
        }
        else
            Label9.Visible = false;

        if (!TextBox3.Text.Equals("") && !TextBox3.Text.Equals(null) && !TextBox2.Text.Equals("") && !TextBox2.Text.Equals(null))
        {
            if (DateTime.Parse(TextBox3.Text) < DateTime.Parse(TextBox2.Text))
            {
                Label10.Text = "Date Cannot Be Earlier Than Beginning Date";
                Label10.Visible = true;
                TextBox3.Text = "";
                EndDateEarly = true;
            }
        }

        if (!EndDateEarly)
        {
            if (TextBox3.Text.Equals("") || TextBox3.Text.Equals(null))
            {
                Label10.Text = "Please Select An Ending Date.";
                Label10.Visible = true;
            }
            else
                Label10.Visible = false;
        }

        if (TextBox4.Text.Equals("") || TextBox4.Text.Equals(null))
            Label13.Visible = true;
        else
            Label13.Visible = false;
        
        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void DropDownList8_SelectedIndexChanged(object sender, EventArgs e)
    {
        CustomerSiteChanged = true;
        SelectedTeacher = "notta";

        SelectedCustomerSite = DropDownList8.SelectedValue;
        //if (Convert.ToInt16(DropDownList8.Items[x].Value).Equals(MemberHomeSite))
        if (Convert.ToInt16(DropDownList8.SelectedValue).Equals(MemberHomeSite))
        {
            TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList8.SelectedValue));
            DropDownList9.Items.Clear();
            DropDownList9.Items.Add("Select Teacher");
            DropDownList9.Items[0].Value = "0";
            x = 0;
            foreach (TeacherSite tas in teachersatsite)
            {
                x++;
                teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                DropDownList9.Items.Add(teachr.FirstName + " " + teachr.LastName);
                DropDownList9.Items[x].Value = teachr.TeacherId.ToString();
                if (Convert.ToInt16(DropDownList1.Items[x].Value).Equals(MemberTeacher))
                    DropDownList9.Items[x].Selected = true;
            }
        }
        else
        {
            TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList8.SelectedValue));
            DropDownList9.Items.Clear();
            DropDownList9.Items.Add("Select Teacher");
            DropDownList9.Items[0].Value = "0";
            DropDownList9.Items[0].Selected = true;
            x = 0;
            foreach (TeacherSite tas in teachersatsite)
            {
                x++;
                teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                DropDownList9.Items.Add(teachr.FirstName + " " + teachr.LastName);
                DropDownList9.Items[x].Value = teachr.TeacherId.ToString();
            }
        }
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        string TeacherEmail = "";
        teacher = DataRepository.TeacherProvider.GetByTeacherId(Convert.ToInt16(DropDownList9.SelectedValue));
        Guid TeacherGuid = new Guid();
        TeacherGuid = teacher.AspnetMembershipUserId;
        MembershipUser TeacherUser = new MembershipUser("AspNetSqlMembershipProvider", null, null, null, null, null, true, true, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now);
        TeacherUser = Membership.GetUser(TeacherGuid);
        TeacherEmail = TeacherUser.Email;

        if (TextBox2.Text.Equals("") || TextBox2.Text.Equals(null) || TextBox3.Text.Equals("") || TextBox3.Text.Equals(null) || TextBox4.Text.Equals("") || TextBox4.Text.Equals(null))
        {
            //One of the fields is empty
        }
        else
        {
            MailAddress from = new MailAddress(TextBox4.Text);
            MailAddress to = new MailAddress(TeacherEmail);
            MailAddress ccFrom = new MailAddress(TextBox4.Text);
            MailAddress ccDev = new MailAddress("dev@swingmodel.com");
            MailMessage message = new MailMessage(from, to);
            message.IsBodyHtml = true;

            message.Subject = "SwingModel Lesson Appointment Request";
            message.Body = "The following lesson appointment request has been submitted through the SwingModel website.<br><br>"
                + "Name: " + customer.FirstName + " " + customer.LastName + "<br>"
                + "Beginning Date: " + TextBox2.Text + "<br>"
                + "Ending Date: " + TextBox3.Text + "<br>"
                + "Start Time: " + DropDownList1.SelectedValue + "<br>"
                + "Lesson Hours: " + DropDownList2.SelectedValue + "<br><br>"
                + "Special Information:" + "<br><br>"
                + FreeTextBox1.Text;
            message.CC.Add(ccFrom);
            message.CC.Add(ccDev);

            Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
            MailSettingsSectionGroup settings = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");
            SmtpClient client = new SmtpClient(settings.Smtp.Network.Host);
            try
            {
                client.Send(message);
                //Response.Write("Your Email has been sent sucessfully - Thank You");
                Label14.Visible = true;
            }
            catch (Exception ex)
            {
                //Response.Write("Send failure: " + ex.ToString());
                Label14.Text = "Send failure. Please try sending again. If the problem persists, please contact SwingModel.";
                Label14.Visible = true;
            }
        }
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        if (!TextBox2.Text.Equals("") && TextBox2.Text.Equals(null) && DateTime.Parse(TextBox2.Text) <= DateTime.Today)
        {
            Label9.Visible = true;
            TextBox2.Text = "";
        }
        else
        {
            Label9.Visible = false;
        }

        SelectedCustomerSite = DropDownList8.SelectedValue;
        SelectedTeacher = DropDownList9.SelectedValue;
    }
    
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
        if (!TextBox3.Text.Equals("") && TextBox3.Text.Equals(null) && DateTime.Parse(TextBox3.Text) <= DateTime.Today)
        {
            Label10.Visible = true;
            TextBox3.Text = "";
        }
        /*
        else
        {
            Label10.Visible = false;
            if (!TextBox2.Text.Equals("") && !TextBox2.Text.Equals(null))
            {
                if (DateTime.Parse(TextBox3.Text) < DateTime.Parse(TextBox2.Text))
                {
                    Label10.Text = "Date Cannot Be Earlier Than Beginning Date";
                    Label10.Visible = true;
                    TextBox3.Text = "";
                }
            }
            else
            {
                Label10.Visible = false;
            }
        }
        */

        SelectedCustomerSite = DropDownList8.SelectedValue;
        SelectedTeacher = DropDownList9.SelectedValue;
    }
}
