﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Web.Script.Serialization;
using System.Windows.Forms;

//public partial class Users_MyLaunchData : System.Web.UI.Page
public partial class Users_MyLaunchData : SwingModel.UI.BasePage
{
    Customer customer;
    bool customerexists;
    CurrentFitStatus currentfitstatus;
    InitialWoodFit initialwoodfit;
    InitialWoodData initialwooddata;
    InitialWoodCompData initialwoodcompdata;
    FinalWoodFit finalwoodfit;
    FinalWoodData finalwooddata;
    FinalWoodCompData finalwoodcompdata;
    InitialIronFit initialironfit;
    InitialIronData initialirondata;
    InitialIronCompData initialironcompdata;
    FinalIronFit finalironfit;
    FinalIronData finalirondata;
    FinalIronCompData finalironcompdata;

    protected override void OnPreLoad(EventArgs e)
    {
        Accordion1.FindControl("Accordion1");
        Accordion2.FindControl("Accordion2");
        Accordion3.FindControl("Accordion3");
        Accordion4.FindControl("Accordion4");

        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
                currentfitstatus = DataRepository.CurrentFitStatusProvider.GetByCustomerId(customer.CustomerId)[0];

                try
                {
                    initialwoodfit = DataRepository.InitialWoodFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    initialwooddata = DataRepository.InitialWoodDataProvider.GetByInitialWoodFitId(initialwoodfit.InitialWoodFitId)[0];
                    initialwoodcompdata = DataRepository.InitialWoodCompDataProvider.GetByInitialWoodFitId(initialwoodfit.InitialWoodFitId)[0];
                    Label1.Text = "Since you have had a CompuSport Initial Wood Fitting Session, you have a record of your launch results available. Presented below are your latest fitting results for your Woods.";
                    Label5.Text = initialwoodfit.InitialWoodFitDate.ToShortDateString();
                    iwdp.Visible = true;
                    iwsp.Visible = true;
                    iwlp.Visible = true;
                    iwsdp.Visible = true;
                }
                catch (Exception ex)
                {
                    // No Initial Wood Fit
                    Label1.Text = "Since you have not yet had a CompuSport Initial Wood Fitting Session, there are no records of your launch results available. Please ask your teaching professional how to obtain a SwingModel Initial Wood Fitting Session.";
                    Label5.Text = "Unavailable";
                    Image1.Visible = false; Image2.Visible = false; Image3.Visible = false; Image4.Visible = false; Image5.Visible = false;
                    Image6.Visible = false; Image7.Visible = false; Image8.Visible = false; Image9.Visible = false; Image10.Visible = false;
                    iwdp.Visible = false;
                    iwsp.Visible = false;
                    iwlp.Visible = false;
                    iwsdp.Visible = false;
                }
                try
                {
                    finalwoodfit = DataRepository.FinalWoodFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    finalwooddata = DataRepository.FinalWoodDataProvider.GetByFinalWoodFitId(finalwoodfit.FinalWoodFitId)[0];
                    finalwoodcompdata = DataRepository.FinalWoodCompDataProvider.GetByFinalWoodFitId(finalwoodfit.FinalWoodFitId)[0];
                    Label2.Text = "Since you have had a CompuSport Final Wood Fitting Session, you have a record of your launch results available. Presented below are your latest fitting results for your Woods.";
                    Label6.Text = finalwoodfit.FinalWoodFitDate.ToShortDateString();
                    fwdp.Visible = true;
                    fwsp.Visible = true;
                    fwlp.Visible = true;
                    fwsdp.Visible = true;
                }
                catch (Exception ex)
                {
                    // No Final Wood Fit
                    Label2.Text = "Since you have not yet had a CompuSport Final Wood Fitting Session, there are no records of your launch results available. Please ask your teaching professional how to obtain a SwingModel Final Wood Fitting Session.";
                    Label6.Text = "Unavailable";
                    Image11.Visible = false; Image12.Visible = false; Image13.Visible = false; Image14.Visible = false; Image15.Visible = false;
                    Image16.Visible = false; Image17.Visible = false; Image18.Visible = false; Image19.Visible = false; Image20.Visible = false;
                    fwdp.Visible = false;
                    fwsp.Visible = false;
                    fwlp.Visible = false;
                    fwsdp.Visible = false;
                }
                try
                {
                    initialironfit = DataRepository.InitialIronFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    initialirondata = DataRepository.InitialIronDataProvider.GetByInitialIronFitId(initialironfit.InitialIronFitId)[0];
                    initialironcompdata = DataRepository.InitialIronCompDataProvider.GetByInitialIronFitId(initialironfit.InitialIronFitId)[0];
                    Label3.Text = "Since you have had a CompuSport Initial Iron Fitting Session, you have a record of your launch results available. Presented below are your latest fitting results for your Irons.";
                    Label7.Text = initialironfit.InitialIronFitDate.ToShortDateString();
                    iidp.Visible = true;
                    iisp.Visible = true;
                    iilp.Visible = true;
                    iisdp.Visible = true;
                }
                catch (Exception ex)
                {
                    // No Initial Iron Fit
                    Label3.Text = "Since you have not yet had a CompuSport Initial Iron Fitting Session, there are no records of your launch results available. Please ask your teaching professional how to obtain a SwingModel Initial Iron Fitting Session.";
                    Label7.Text = "Unavailable";
                    Image21.Visible = false; Image22.Visible = false; Image23.Visible = false; Image24.Visible = false; Image25.Visible = false;
                    Image26.Visible = false; Image27.Visible = false; Image28.Visible = false; Image29.Visible = false; Image30.Visible = false;
                    iidp.Visible = false;
                    iisp.Visible = false;
                    iilp.Visible = false;
                    iisdp.Visible = false;
                }
                try
                {
                    finalironfit = DataRepository.FinalIronFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    finalirondata = DataRepository.FinalIronDataProvider.GetByFinalIronFitId(finalironfit.FinalIronFitId)[0];
                    finalironcompdata = DataRepository.FinalIronCompDataProvider.GetByFinalIronFitId(finalironfit.FinalIronFitId)[0];
                    Label4.Text = "Since you have had a CompuSport Final Iron Fitting Session, you have a record of your launch results available. Presented below are your latest fitting results for your Irons.";
                    Label8.Text = finalironfit.FinalIronFitDate.ToShortDateString();
                    fidp.Visible = true;
                    fisp.Visible = true;
                    filp.Visible = true;
                    fisdp.Visible = true;
                }
                catch (Exception ex)
                {
                    // No Final Iron Fit
                    Label4.Text = "Since you have not yet had a CompuSport Final Iron Fitting Session, there are no records of your launch results available. Please ask your teaching professional how to obtain a SwingModel Final Iron Fitting Session.";
                    Label8.Text = "Unavailable";
                    Image31.Visible = false; Image32.Visible = false; Image33.Visible = false; Image34.Visible = false; Image35.Visible = false;
                    Image36.Visible = false; Image37.Visible = false; Image38.Visible = false; Image39.Visible = false; Image40.Visible = false;
                    fidp.Visible = false;
                    fisp.Visible = false;
                    filp.Visible = false;
                    fisdp.Visible = false;
                }
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }

        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string strUrl;
        strUrl = "DistanceGauge.aspx?type=1&value=" + initialwoodcompdata.InitialWoodCompDistance.ToString() + "&air=" + initialwoodcompdata.CompDistanceAir.ToString() + "&ground=" + initialwoodcompdata.CompDistanceGround.ToString();
        Image1.ImageUrl = strUrl;
        strUrl = "SideDistanceGauge.aspx?type=1&value=" + initialwoodcompdata.CompSideDistance.ToString();
        Image7.ImageUrl = strUrl;
        strUrl = "SideDeviationGauge.aspx?type=1&value=" + initialwoodcompdata.CompSideDeviation.ToString();
        Image8.ImageUrl = strUrl;
        strUrl = "ClubheadSpeedGauge.aspx?type=1&value=" + initialwoodcompdata.CompClubVelocity.ToString();
        Image9.ImageUrl = strUrl;
        strUrl = "SmashFactorGauge.aspx?type=1&value=" + initialwoodcompdata.CompClubLaunchFactor.ToString();
        Image10.ImageUrl = strUrl;
        strUrl = "BallSpeedGauge.aspx?type=1&value=" + initialwoodcompdata.CompLaunchVelocity.ToString();
        Image2.ImageUrl = strUrl;
        strUrl = "LaunchAngleGauge.aspx?type=1&value=" + initialwoodcompdata.CompLaunchAngle.ToString();
        Image3.ImageUrl = strUrl;
        strUrl = "BackSpinGauge.aspx?type=1&value=" + initialwoodcompdata.CompLaunchSpin.ToString();
        Image4.ImageUrl = strUrl;
        strUrl = "SideAngleGauge.aspx?type=1&value=" + initialwoodcompdata.CompSideAngle.ToString();
        Image5.ImageUrl = strUrl;
        strUrl = "SideSpinGauge.aspx?type=1&value=" + initialwoodcompdata.CompSideSpin.ToString();
        Image6.ImageUrl = strUrl;
        //MessageBox.Show(strUrl);

        strUrl = "DistanceGauge.aspx?type=1&value=" + finalwoodcompdata.FinalWoodCompDistance.ToString() + "&air=" + finalwoodcompdata.CompDistanceAir.ToString() + "&ground=" + finalwoodcompdata.CompDistanceGround.ToString();
        Image11.ImageUrl = strUrl;
        strUrl = "SideDistanceGauge.aspx?type=1&value=" + finalwoodcompdata.CompSideDistance.ToString();
        Image17.ImageUrl = strUrl;
        strUrl = "SideDeviationGauge.aspx?type=1&value=" + finalwoodcompdata.CompSideDeviation.ToString();
        Image18.ImageUrl = strUrl;
        strUrl = "ClubheadSpeedGauge.aspx?type=1&value=" + finalwoodcompdata.CompClubVelocity.ToString();
        Image19.ImageUrl = strUrl;
        strUrl = "SmashFactorGauge.aspx?type=1&value=" + finalwoodcompdata.CompClubLaunchFactor.ToString();
        Image20.ImageUrl = strUrl;
        strUrl = "BallSpeedGauge.aspx?type=1&value=" + finalwoodcompdata.CompLaunchVelocity.ToString();
        Image12.ImageUrl = strUrl;
        strUrl = "LaunchAngleGauge.aspx?type=1&value=" + finalwoodcompdata.CompLaunchAngle.ToString();
        Image13.ImageUrl = strUrl;
        strUrl = "BackSpinGauge.aspx?type=1&value=" + finalwoodcompdata.CompLaunchSpin.ToString();
        Image14.ImageUrl = strUrl;
        strUrl = "SideAngleGauge.aspx?type=1&value=" + finalwoodcompdata.CompSideAngle.ToString();
        Image15.ImageUrl = strUrl;
        strUrl = "SideSpinGauge.aspx?type=1&value=" + finalwoodcompdata.CompSideSpin.ToString();
        Image16.ImageUrl = strUrl;

        strUrl = "DistanceGauge.aspx?type=2&value=" + initialironcompdata.InitialIronCompDistance.ToString() + "&air=" + initialironcompdata.CompDistanceAir.ToString() + "&ground=" + initialironcompdata.CompDistanceGround.ToString();
        Image21.ImageUrl = strUrl;
        strUrl = "SideDistanceGauge.aspx?type=2&value=" + initialironcompdata.CompSideDistance.ToString();
        Image22.ImageUrl = strUrl;
        strUrl = "SideDeviationGauge.aspx?type=2&value=" + initialironcompdata.CompSideDeviation.ToString();
        Image23.ImageUrl = strUrl;
        strUrl = "ClubheadSpeedGauge.aspx?type=2&value=" + initialironcompdata.CompClubVelocity.ToString();
        Image24.ImageUrl = strUrl;
        strUrl = "BallSpeedGauge.aspx?type=2&value=" + initialironcompdata.CompLaunchVelocity.ToString();
        Image25.ImageUrl = strUrl;
        strUrl = "SmashFactorGauge.aspx?type=2&value=" + initialironcompdata.CompClubLaunchFactor.ToString();
        Image26.ImageUrl = strUrl;
        strUrl = "LaunchAngleGauge.aspx?type=2&value=" + initialironcompdata.CompLaunchAngle.ToString();
        Image27.ImageUrl = strUrl;
        strUrl = "BackSpinGauge.aspx?type=2&value=" + initialironcompdata.CompLaunchSpin.ToString();
        Image28.ImageUrl = strUrl;
        strUrl = "SideAngleGauge.aspx?type=2&value=" + initialironcompdata.CompSideAngle.ToString();
        Image29.ImageUrl = strUrl;
        strUrl = "SideSpinGauge.aspx?type=2&value=" + initialironcompdata.CompSideSpin.ToString();
        Image30.ImageUrl = strUrl;

        strUrl = "DistanceGauge.aspx?type=2&value=" + finalironcompdata.FinalIronCompDistance.ToString() + "&air=" + finalironcompdata.CompDistanceAir.ToString() + "&ground=" + finalironcompdata.CompDistanceGround.ToString();
        Image31.ImageUrl = strUrl;
        strUrl = "SideDistanceGauge.aspx?type=2&value=" + finalironcompdata.CompSideDistance.ToString();
        Image32.ImageUrl = strUrl;
        strUrl = "SideDeviationGauge.aspx?type=2&value=" + finalironcompdata.CompSideDeviation.ToString();
        Image33.ImageUrl = strUrl;
        strUrl = "ClubheadSpeedGauge.aspx?type=2&value=" + finalironcompdata.CompClubVelocity.ToString();
        Image34.ImageUrl = strUrl;
        strUrl = "BallSpeedGauge.aspx?type=2&value=" + finalironcompdata.CompLaunchVelocity.ToString();
        Image35.ImageUrl = strUrl;
        strUrl = "SmashFactorGauge.aspx?type=2&value=" + finalironcompdata.CompClubLaunchFactor.ToString();
        Image36.ImageUrl = strUrl;
        strUrl = "LaunchAngleGauge.aspx?type=2&value=" + finalironcompdata.CompLaunchAngle.ToString();
        Image37.ImageUrl = strUrl;
        strUrl = "BackSpinGauge.aspx?type=2&value=" + finalironcompdata.CompLaunchSpin.ToString();
        Image38.ImageUrl = strUrl;
        strUrl = "SideAngleGauge.aspx?type=2&value=" + finalironcompdata.CompSideAngle.ToString();
        Image39.ImageUrl = strUrl;
        strUrl = "SideSpinGauge.aspx?type=2&value=" + finalironcompdata.CompSideSpin.ToString();
        Image40.ImageUrl = strUrl;
    }
}
