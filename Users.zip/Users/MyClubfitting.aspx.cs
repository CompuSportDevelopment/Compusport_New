﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Web.Script.Serialization;
using System.Windows.Forms;

//public partial class Users_MyClubfitting : System.Web.UI.Page
public partial class Users_MyClubfitting : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    Teacher teacher = new Teacher();
    TList<Lesson> lessons = new TList<Lesson>();
    TList<Movie> movies = new TList<Movie>();
    bool customerexists = false;
    bool customerprofileexists = false;
    bool lessonsexist = false;
    TimeSpan span;
    CurrentFitStatus currentfitstatus;
    InitialWoodFit initialwoodfit;
    InitialWoodFitDetails initialwoodfitdetails;
    InitialWoodSelect initialwoodselect;
    InitialWoodFitBall initialwoodfitball;
    InitialWoodFitGrip initialwoodfitgrip;
    InitialWoodFitNotes initialwoodfitnotes;
    FinalWoodFit finalwoodfit;
    FinalWoodFitDetails finalwoodfitdetails;
    FinalWoodSelect finalwoodselect;
    FinalWoodFitBall finalwoodfitball;
    FinalWoodFitGrip finalwoodfitgrip;
    FinalWoodFitNotes finalwoodfitnotes;
    InitialIronFit initialironfit;
    InitialIronFitDetails initialironfitdetails;
    InitialIronSelect initialironselect;
    InitialIronFitBall initialironfitball;
    InitialIronFitGrip initialironfitgrip;
    InitialIronFitNotes initialironfitnotes;
    FinalIronFit finalironfit;
    FinalIronFitDetails finalironfitdetails;
    FinalIronSelect finalironselect;
    FinalIronFitBall finalironfitball;
    FinalIronFitGrip finalironfitgrip;
    FinalIronFitNotes finalironfitnotes;
    bool[,] isChecked = new bool[4, 14];
    decimal subtotal1;
    decimal subtotal2;
    decimal subtotal3;
    decimal subtotal4;
    Order order = new Order();
    ClubOrder cluborder = new ClubOrder();

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].ToolTip = "Click to Purchase Club";
            e.Row.Cells[1].ToolTip = "Club: Manufacturer and Clubhead";
            e.Row.Cells[2].ToolTip = "Lie of Clubhead";
            e.Row.Cells[3].ToolTip = "Loft of Clubhead";
            e.Row.Cells[4].ToolTip = "Shaft or Shaft Series";
            e.Row.Cells[5].ToolTip = "Shaft Frequency";
            e.Row.Cells[6].ToolTip = "Club Length";
            e.Row.Cells[7].ToolTip = "Cost of Complete Club";
            e.Row.Cells[8].ToolTip = "Club was Selected as desired during Clubfitting";
        }

    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].ToolTip = "Click to Purchase Club";
            e.Row.Cells[1].ToolTip = "Club: Manufacturer and Clubhead";
            e.Row.Cells[2].ToolTip = "Lie of Clubhead";
            e.Row.Cells[3].ToolTip = "Loft of Clubhead";
            e.Row.Cells[4].ToolTip = "Shaft or Shaft Series";
            e.Row.Cells[5].ToolTip = "Shaft Frequency";
            e.Row.Cells[6].ToolTip = "Club Length";
            e.Row.Cells[7].ToolTip = "Cost of Complete Club";
            e.Row.Cells[8].ToolTip = "Club was Selected as desired during Clubfitting";
        }
    }
    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].ToolTip = "Click to Purchase Club";
            e.Row.Cells[1].ToolTip = "Club: Manufacturer and Clubhead";
            e.Row.Cells[2].ToolTip = "Lie of Clubhead";
            e.Row.Cells[3].ToolTip = "Loft of Clubhead";
            e.Row.Cells[4].ToolTip = "Shaft or Shaft Series";
            e.Row.Cells[5].ToolTip = "Shaft Frequency";
            e.Row.Cells[6].ToolTip = "Club Length";
            e.Row.Cells[7].ToolTip = "Cost of Complete Club";
            e.Row.Cells[8].ToolTip = "Club was Selected as desired during Clubfitting";
        }

    }
    protected void GridView4_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].ToolTip = "Click to Purchase Club";
            e.Row.Cells[1].ToolTip = "Club: Manufacturer and Clubhead";
            e.Row.Cells[2].ToolTip = "Lie of Clubhead";
            e.Row.Cells[3].ToolTip = "Loft of Clubhead";
            e.Row.Cells[4].ToolTip = "Shaft or Shaft Series";
            e.Row.Cells[5].ToolTip = "Shaft Frequency";
            e.Row.Cells[6].ToolTip = "Club Length";
            e.Row.Cells[7].ToolTip = "Cost of Complete Club";
            e.Row.Cells[8].ToolTip = "Club was Selected as desired during Clubfitting";
        }

    }
    
    protected override void OnPreLoad(EventArgs e)
    {
        if (!IsPostBack)
        {
            for (int z = 0; z < 4; z++)
            {
                for (int w = 0; w < 14; w++)
                {
                    isChecked[z, w] = false;
                }
            }
        }

        try
        {
            for (int w = 0; w < 14; w++)
            {
                isChecked[0, w] = ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[w].Cells[0].Controls[1]).Checked;
            }
        }
        catch (Exception ex)
        {
        }

        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }

        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }

        Label3.Text = customer.FirstName;
        Label4.Text = customer.LastName;
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
        Label6.Text = customersite.SiteName;
        teacher = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
        Label8.Text = teacher.FirstName + " " + teacher.LastName;

        try
        {
            lessons = DataRepository.LessonProvider.GetByCustomerId(customer.CustomerId);
            if (lessons.Count > 0)
                lessonsexist = true;
            else
                lessonsexist = false;
        }
        catch (Exception ex)
        {
            lessonsexist = false;
        }


        if (!lessonsexist)
        {
            Label10.Text = "No lessons taken.";
        }
        else
        {
            try
            {
                foreach (Lesson l in lessons)
                {
                    DataRepository.LessonProvider.DeepLoad(l);
                    foreach (Movie m in l.MovieCollection)
                    {

                        DataRepository.MovieProvider.DeepLoad(m);
                        movies.Add(m);
                    }
                }
                movies.Sort("DateRecorded DESC");
            }
            catch (Exception ex)
            {
                lessonsexist = false;
            }

            if (lessonsexist)
            {
                span = DateTime.Today.Subtract(movies[0].DateRecorded);
                Label10.Text = span.Days.ToString();
            }
            else
                Label10.Text = "No Lessons available.";
        }

        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        int x = 0;
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable dt3 = new DataTable();
        DataTable dt4 = new DataTable();

        try
        {
            currentfitstatus = DataRepository.CurrentFitStatusProvider.GetByCustomerId(customer.CustomerId)[0];

            if (!IsPostBack)
            {
                try
                {
                    initialwoodfit = DataRepository.InitialWoodFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    initialwoodfitdetails = DataRepository.InitialWoodFitDetailsProvider.GetByInitialWoodFitId(initialwoodfit.InitialWoodFitId)[0];
                    initialwoodselect = DataRepository.InitialWoodSelectProvider.GetByInitialWoodFitId(initialwoodfit.InitialWoodFitId)[0];
                    initialwoodfitball = DataRepository.InitialWoodFitBallProvider.GetByInitialWoodFitId(currentfitstatus.CurrentFitStatus)[0];
                    initialwoodfitgrip = DataRepository.InitialWoodFitGripProvider.GetByInitialWoodFitId(currentfitstatus.CurrentFitStatus)[0];
                    initialwoodfitnotes = DataRepository.InitialWoodFitNotesProvider.GetByInitialWoodFitId(currentfitstatus.CurrentFitStatus)[0];

                    Label1.Text = initialwoodfit.InitialWoodFitDate.ToShortDateString();
                    Label19.Text = initialwoodfitball.InitialWoodBallSelect;
                    Label35.Text = initialwoodfitgrip.InitialWoodGripType + " (" + initialwoodfitgrip.GripSize + ")";

                    dt.Columns.Add("Club", typeof(string));
                    dt.Columns.Add("Lie", typeof(string));
                    dt.Columns.Add("Loft", typeof(decimal));
                    dt.Columns.Add("Shaft", typeof(string));
                    dt.Columns.Add("Freq", typeof(int));
                    dt.Columns.Add("Length", typeof(decimal));
                    dt.Columns.Add("Cost", typeof(string));

                    if (initialwoodfitdetails.Wood1.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood1, initialwoodfitdetails.Lie1, initialwoodfitdetails.Loft1, initialwoodfitdetails.Shaft1, initialwoodfitdetails.Frequency1, initialwoodfitdetails.Length1, "$" + initialwoodfitdetails.Cost1.ToString());
                    }
                    if (initialwoodfitdetails.Wood2.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood2, initialwoodfitdetails.Lie2, initialwoodfitdetails.Loft2, initialwoodfitdetails.Shaft2, initialwoodfitdetails.Frequency2, initialwoodfitdetails.Length2, "$" + initialwoodfitdetails.Cost2.ToString());
                    }
                    if (initialwoodfitdetails.Wood3.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood3, initialwoodfitdetails.Lie3, initialwoodfitdetails.Loft3, initialwoodfitdetails.Shaft3, initialwoodfitdetails.Frequency3, initialwoodfitdetails.Length3, "$" + initialwoodfitdetails.Cost3.ToString());
                    }
                    if (initialwoodfitdetails.Wood4.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood4, initialwoodfitdetails.Lie4, initialwoodfitdetails.Loft4, initialwoodfitdetails.Shaft4, initialwoodfitdetails.Frequency4, initialwoodfitdetails.Length4, "$" + initialwoodfitdetails.Cost4.ToString());
                    }
                    if (initialwoodfitdetails.Wood5.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood5, initialwoodfitdetails.Lie5, initialwoodfitdetails.Loft5, initialwoodfitdetails.Shaft5, initialwoodfitdetails.Frequency5, initialwoodfitdetails.Length5, "$" + initialwoodfitdetails.Cost5.ToString());
                    }
                    if (initialwoodfitdetails.Wood6.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood6, initialwoodfitdetails.Lie6, initialwoodfitdetails.Loft6, initialwoodfitdetails.Shaft6, initialwoodfitdetails.Frequency6, initialwoodfitdetails.Length6, "$" + initialwoodfitdetails.Cost6.ToString());
                    }
                    if (initialwoodfitdetails.Wood7.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood7, initialwoodfitdetails.Lie7, initialwoodfitdetails.Loft7, initialwoodfitdetails.Shaft7, initialwoodfitdetails.Frequency7, initialwoodfitdetails.Length7, "$" + initialwoodfitdetails.Cost7.ToString());
                    }
                    if (initialwoodfitdetails.Wood8.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood8, initialwoodfitdetails.Lie8, initialwoodfitdetails.Loft8, initialwoodfitdetails.Shaft8, initialwoodfitdetails.Frequency8, initialwoodfitdetails.Length8, "$" + initialwoodfitdetails.Cost8.ToString());
                    }
                    if (initialwoodfitdetails.Wood9.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood9, initialwoodfitdetails.Lie9, initialwoodfitdetails.Loft9, initialwoodfitdetails.Shaft9, initialwoodfitdetails.Frequency9, initialwoodfitdetails.Length9, "$" + initialwoodfitdetails.Cost9.ToString());
                    }
                    if (initialwoodfitdetails.Wood10.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood10, initialwoodfitdetails.Lie10, initialwoodfitdetails.Loft10, initialwoodfitdetails.Shaft10, initialwoodfitdetails.Frequency10, initialwoodfitdetails.Length10, "$" + initialwoodfitdetails.Cost10.ToString());
                    }
                    if (initialwoodfitdetails.Wood11.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood11, initialwoodfitdetails.Lie11, initialwoodfitdetails.Loft11, initialwoodfitdetails.Shaft11, initialwoodfitdetails.Frequency11, initialwoodfitdetails.Length11, "$" + initialwoodfitdetails.Cost11.ToString());
                    }
                    if (initialwoodfitdetails.Wood12.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood12, initialwoodfitdetails.Lie12, initialwoodfitdetails.Loft12, initialwoodfitdetails.Shaft12, initialwoodfitdetails.Frequency12, initialwoodfitdetails.Length12, "$" + initialwoodfitdetails.Cost12.ToString());
                    }
                    if (initialwoodfitdetails.Wood13.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood13, initialwoodfitdetails.Lie13, initialwoodfitdetails.Loft13, initialwoodfitdetails.Shaft13, initialwoodfitdetails.Frequency13, initialwoodfitdetails.Length13, "$" + initialwoodfitdetails.Cost13.ToString());
                    }
                    if (initialwoodfitdetails.Wood14.ToLower() != "none")
                    {
                        dt.Rows.Add(initialwoodfitdetails.Wood14, initialwoodfitdetails.Lie14, initialwoodfitdetails.Loft14, initialwoodfitdetails.Shaft14, initialwoodfitdetails.Frequency14, initialwoodfitdetails.Length14, "$" + initialwoodfitdetails.Cost14.ToString());
                    }
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    if (!IsPostBack)
                    {
                        if (initialwoodfitdetails.Selected1 == 1)
                        {
                            if (initialwoodfitdetails.Wood1.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood1.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[0].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected2 == 1)
                        {
                            if (initialwoodfitdetails.Wood2.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood2.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[1].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected3 == 1)
                        {
                            if (initialwoodfitdetails.Wood3.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood3.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[2].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected4 == 1)
                        {
                            if (initialwoodfitdetails.Wood4.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood4.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[3].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected5 == 1)
                        {
                            if (initialwoodfitdetails.Wood5.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood5.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[4].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected6 == 1)
                        {
                            if (initialwoodfitdetails.Wood6.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood6.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[5].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected7 == 1)
                        {
                            if (initialwoodfitdetails.Wood7.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood7.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[6].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected8 == 1)
                        {
                            if (initialwoodfitdetails.Wood8.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood8.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[7].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected9 == 1)
                        {
                            if (initialwoodfitdetails.Wood9.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood9.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[8].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected10 == 1)
                        {
                            if (initialwoodfitdetails.Wood10.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood10.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[9].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected11 == 1)
                        {
                            if (initialwoodfitdetails.Wood11.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood11.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[10].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected12 == 1)
                        {
                            if (initialwoodfitdetails.Wood12.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood12.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[11].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected13 == 1)
                        {
                            if (initialwoodfitdetails.Wood13.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood13.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[12].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialwoodfitdetails.Selected14 == 1)
                        {
                            if (initialwoodfitdetails.Wood14.ToLower() != "none")
                            {
                                if (initialwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Checked = true;
                                    GridView1.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Checked = false;
                                    GridView1.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[8].Controls[1]).Checked = true;
                                GridView1.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialwoodfitdetails.Wood14.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Checked = false;
                                GridView1.Rows[13].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[8].Controls[1]).Checked = false;
                                GridView1.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                    }
                    GridView1.Visible = true;
                    Label27.Text = "Since you have had a SwingModel Initial Wood Fitting Session, your fitting results are presented below. You may hover your mouse over each Column Name for more information about the specific column.";
                    Label26.Visible = true;
                    Label19.Visible = true;
                    Label34.Visible = true;
                    Label35.Visible = true;
                }
                catch (Exception ex)
                {
                    GridView1.Visible = false;
                    Label27.Text = "Since you have not yet had a SwingModel Initial Wood Fitting Session, there are no records for your Initial Wood Fitting. Please ask your teaching professional how to obtain a SwingModel Initial Wood Fitting Session.";
                    Label26.Visible = false;
                    Label19.Visible = false;
                    Label34.Visible = false;
                    Label35.Visible = false;
                }

                try
                {
                    finalwoodfit = DataRepository.FinalWoodFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    finalwoodfitdetails = DataRepository.FinalWoodFitDetailsProvider.GetByFinalWoodFitId(finalwoodfit.FinalWoodFitId)[0];
                    finalwoodselect = DataRepository.FinalWoodSelectProvider.GetByFinalWoodFitId(finalwoodfit.FinalWoodFitId)[0];
                    finalwoodfitball = DataRepository.FinalWoodFitBallProvider.GetByFinalWoodFitId(currentfitstatus.CurrentFitStatus)[0];
                    finalwoodfitgrip = DataRepository.FinalWoodFitGripProvider.GetByFinalWoodFitId(currentfitstatus.CurrentFitStatus)[0];
                    finalwoodfitnotes = DataRepository.FinalWoodFitNotesProvider.GetByFinalWoodFitId(currentfitstatus.CurrentFitStatus)[0];

                    Label13.Text = finalwoodfit.FinalWoodFitDate.ToShortDateString();
                    Label21.Text = finalwoodfitball.FinalWoodBallSelect;
                    Label37.Text = finalwoodfitgrip.FinalWoodGripType + " (" + finalwoodfitgrip.GripSize + ")";

                    dt2.Columns.Add("Club", typeof(string));
                    dt2.Columns.Add("Lie", typeof(string));
                    dt2.Columns.Add("Loft", typeof(decimal));
                    dt2.Columns.Add("Shaft", typeof(string));
                    dt2.Columns.Add("Freq", typeof(int));
                    dt2.Columns.Add("Length", typeof(decimal));
                    dt2.Columns.Add("Cost", typeof(string));

                    if (finalwoodfitdetails.Wood1.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood1, finalwoodfitdetails.Lie1, finalwoodfitdetails.Loft1, finalwoodfitdetails.Shaft1, finalwoodfitdetails.Frequency1, finalwoodfitdetails.Length1, "$" + finalwoodfitdetails.Cost1.ToString());
                    }
                    if (finalwoodfitdetails.Wood2.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood2, finalwoodfitdetails.Lie2, finalwoodfitdetails.Loft2, finalwoodfitdetails.Shaft2, finalwoodfitdetails.Frequency2, finalwoodfitdetails.Length2, "$" + finalwoodfitdetails.Cost2.ToString());
                    }
                    if (finalwoodfitdetails.Wood3.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood3, finalwoodfitdetails.Lie3, finalwoodfitdetails.Loft3, finalwoodfitdetails.Shaft3, finalwoodfitdetails.Frequency3, finalwoodfitdetails.Length3, "$" + finalwoodfitdetails.Cost3.ToString());
                    }
                    if (finalwoodfitdetails.Wood4.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood4, finalwoodfitdetails.Lie4, finalwoodfitdetails.Loft4, finalwoodfitdetails.Shaft4, finalwoodfitdetails.Frequency4, finalwoodfitdetails.Length4, "$" + finalwoodfitdetails.Cost4.ToString());
                    }
                    if (finalwoodfitdetails.Wood5.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood5, finalwoodfitdetails.Lie5, finalwoodfitdetails.Loft5, finalwoodfitdetails.Shaft5, finalwoodfitdetails.Frequency5, finalwoodfitdetails.Length5, "$" + finalwoodfitdetails.Cost5.ToString());
                    }
                    if (finalwoodfitdetails.Wood6.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood6, finalwoodfitdetails.Lie6, finalwoodfitdetails.Loft6, finalwoodfitdetails.Shaft6, finalwoodfitdetails.Frequency6, finalwoodfitdetails.Length6, "$" + finalwoodfitdetails.Cost6.ToString());
                    }
                    if (finalwoodfitdetails.Wood7.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood7, finalwoodfitdetails.Lie7, finalwoodfitdetails.Loft7, finalwoodfitdetails.Shaft7, finalwoodfitdetails.Frequency7, finalwoodfitdetails.Length7, "$" + finalwoodfitdetails.Cost7.ToString());
                    }
                    if (finalwoodfitdetails.Wood8.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood8, finalwoodfitdetails.Lie8, finalwoodfitdetails.Loft8, finalwoodfitdetails.Shaft8, finalwoodfitdetails.Frequency8, finalwoodfitdetails.Length8, "$" + finalwoodfitdetails.Cost8.ToString());
                    }
                    if (finalwoodfitdetails.Wood9.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood9, finalwoodfitdetails.Lie9, finalwoodfitdetails.Loft9, finalwoodfitdetails.Shaft9, finalwoodfitdetails.Frequency9, finalwoodfitdetails.Length9, "$" + finalwoodfitdetails.Cost9.ToString());
                    }
                    if (finalwoodfitdetails.Wood10.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood10, finalwoodfitdetails.Lie10, finalwoodfitdetails.Loft10, finalwoodfitdetails.Shaft10, finalwoodfitdetails.Frequency10, finalwoodfitdetails.Length10, "$" + finalwoodfitdetails.Cost10.ToString());
                    }
                    if (finalwoodfitdetails.Wood11.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood11, finalwoodfitdetails.Lie11, finalwoodfitdetails.Loft11, finalwoodfitdetails.Shaft11, finalwoodfitdetails.Frequency11, finalwoodfitdetails.Length11, "$" + finalwoodfitdetails.Cost11.ToString());
                    }
                    if (finalwoodfitdetails.Wood12.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood12, finalwoodfitdetails.Lie12, finalwoodfitdetails.Loft12, finalwoodfitdetails.Shaft12, finalwoodfitdetails.Frequency12, finalwoodfitdetails.Length12, "$" + finalwoodfitdetails.Cost12.ToString());
                    }
                    if (finalwoodfitdetails.Wood13.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood13, finalwoodfitdetails.Lie13, finalwoodfitdetails.Loft13, finalwoodfitdetails.Shaft13, finalwoodfitdetails.Frequency13, finalwoodfitdetails.Length13, "$" + finalwoodfitdetails.Cost13.ToString());
                    }
                    if (finalwoodfitdetails.Wood14.ToLower() != "none")
                    {
                        dt2.Rows.Add(finalwoodfitdetails.Wood14, finalwoodfitdetails.Lie14, finalwoodfitdetails.Loft14, finalwoodfitdetails.Shaft14, finalwoodfitdetails.Frequency14, finalwoodfitdetails.Length14, "$" + finalwoodfitdetails.Cost14.ToString());
                    }
                    GridView2.DataSource = dt2;
                    GridView2.DataBind();
                    if (!IsPostBack)
                    {
                        if (finalwoodfitdetails.Selected1 == 1)
                        {
                            if (finalwoodfitdetails.Wood1.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood1.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[0].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected2 == 1)
                        {
                            if (finalwoodfitdetails.Wood2.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood2.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[1].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected3 == 1)
                        {
                            if (finalwoodfitdetails.Wood3.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood3.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[2].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected4 == 1)
                        {
                            if (finalwoodfitdetails.Wood4.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood4.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[3].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected5 == 1)
                        {
                            if (finalwoodfitdetails.Wood5.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood5.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[4].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected6 == 1)
                        {
                            if (finalwoodfitdetails.Wood6.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood6.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[5].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected7 == 1)
                        {
                            if (finalwoodfitdetails.Wood7.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood7.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[6].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected8 == 1)
                        {
                            if (finalwoodfitdetails.Wood8.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood8.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[7].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected9 == 1)
                        {
                            if (finalwoodfitdetails.Wood9.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood9.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[8].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected10 == 1)
                        {
                            if (finalwoodfitdetails.Wood10.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood10.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[9].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected11 == 1)
                        {
                            if (finalwoodfitdetails.Wood11.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood11.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[10].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected12 == 1)
                        {
                            if (finalwoodfitdetails.Wood12.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood12.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[11].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected13 == 1)
                        {
                            if (finalwoodfitdetails.Wood13.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood13.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[12].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalwoodfitdetails.Selected14 == 1)
                        {
                            if (finalwoodfitdetails.Wood14.ToLower() != "none")
                            {
                                if (finalwoodselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Checked = true;
                                    GridView2.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Checked = false;
                                    GridView2.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[8].Controls[1]).Checked = true;
                                GridView2.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalwoodfitdetails.Wood14.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Checked = false;
                                GridView2.Rows[13].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[8].Controls[1]).Checked = false;
                                GridView2.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                    }
                    else
                    {
                    }
                    GridView2.Visible = true;
                    Label28.Text = "Since you have had a SwingModel Final Wood Fitting Session, your fitting results are presented below. You may hover your mouse over each Column Name for more information about the specific column.";
                    Label31.Visible = true;
                    Label21.Visible = true;
                    Label36.Visible = true;
                    Label37.Visible = true;
                }
                catch (Exception ex)
                {
                    GridView2.Visible = false;
                    Label28.Text = "Since you have not yet had a SwingModel Final Wood Fitting Session, there are no records for your Final Wood Fitting. Please ask your teaching professional how to obtain a SwingModel Final Wood Fitting Session.";
                    Label31.Visible = false;
                    Label21.Visible = false;
                    Label36.Visible = false;
                    Label37.Visible = false;
                }

                try
                {
                    initialironfit = DataRepository.InitialIronFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    initialironfitdetails = DataRepository.InitialIronFitDetailsProvider.GetByInitialIronFitId(initialironfit.InitialIronFitId)[0];
                    initialironselect = DataRepository.InitialIronSelectProvider.GetByInitialIronFitId(initialironfit.InitialIronFitId)[0];
                    initialironfitball = DataRepository.InitialIronFitBallProvider.GetByInitialIronFitId(currentfitstatus.CurrentFitStatus)[0];
                    initialironfitgrip = DataRepository.InitialIronFitGripProvider.GetByInitialIronFitId(currentfitstatus.CurrentFitStatus)[0];
                    initialironfitnotes = DataRepository.InitialIronFitNotesProvider.GetByInitialIronFitId(currentfitstatus.CurrentFitStatus)[0];

                    Label15.Text = initialironfit.InitialIronFitDate.ToShortDateString();
                    Label23.Text = initialironfitball.InitialIronBallSelect;
                    Label39.Text = initialironfitgrip.InitialIronGripType + " (" + initialironfitgrip.GripSize + ")";

                    dt3.Columns.Add("Club", typeof(string));
                    dt3.Columns.Add("Lie", typeof(string));
                    dt3.Columns.Add("Loft", typeof(decimal));
                    dt3.Columns.Add("Shaft", typeof(string));
                    dt3.Columns.Add("Freq", typeof(int));
                    dt3.Columns.Add("Length", typeof(decimal));
                    dt3.Columns.Add("Cost", typeof(string));

                    if (initialironfitdetails.Iron1.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron1, initialironfitdetails.Lie1, initialironfitdetails.Loft1, initialironfitdetails.Shaft1, initialironfitdetails.Frequency1, initialironfitdetails.Length1, "$" + initialironfitdetails.Cost1.ToString());
                    }
                    if (initialironfitdetails.Iron2.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron2, initialironfitdetails.Lie2, initialironfitdetails.Loft2, initialironfitdetails.Shaft2, initialironfitdetails.Frequency2, initialironfitdetails.Length2, "$" + initialironfitdetails.Cost2.ToString());
                    }
                    if (initialironfitdetails.Iron3.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron3, initialironfitdetails.Lie3, initialironfitdetails.Loft3, initialironfitdetails.Shaft3, initialironfitdetails.Frequency3, initialironfitdetails.Length3, "$" + initialironfitdetails.Cost3.ToString());
                    }
                    if (initialironfitdetails.Iron4.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron4, initialironfitdetails.Lie4, initialironfitdetails.Loft4, initialironfitdetails.Shaft4, initialironfitdetails.Frequency4, initialironfitdetails.Length4, "$" + initialironfitdetails.Cost4.ToString());
                    }
                    if (initialironfitdetails.Iron5.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron5, initialironfitdetails.Lie5, initialironfitdetails.Loft5, initialironfitdetails.Shaft5, initialironfitdetails.Frequency5, initialironfitdetails.Length5, "$" + initialironfitdetails.Cost5.ToString());
                    }
                    if (initialironfitdetails.Iron6.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron6, initialironfitdetails.Lie6, initialironfitdetails.Loft6, initialironfitdetails.Shaft6, initialironfitdetails.Frequency6, initialironfitdetails.Length6, "$" + initialironfitdetails.Cost6.ToString());
                    }
                    if (initialironfitdetails.Iron7.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron7, initialironfitdetails.Lie7, initialironfitdetails.Loft7, initialironfitdetails.Shaft7, initialironfitdetails.Frequency7, initialironfitdetails.Length7, "$" + initialironfitdetails.Cost7.ToString());
                    }
                    if (initialironfitdetails.Iron8.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron8, initialironfitdetails.Lie8, initialironfitdetails.Loft8, initialironfitdetails.Shaft8, initialironfitdetails.Frequency8, initialironfitdetails.Length8, "$" + initialironfitdetails.Cost8.ToString());
                    }
                    if (initialironfitdetails.Iron9.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron9, initialironfitdetails.Lie9, initialironfitdetails.Loft9, initialironfitdetails.Shaft9, initialironfitdetails.Frequency9, initialironfitdetails.Length9, "$" + initialironfitdetails.Cost9.ToString());
                    }
                    if (initialironfitdetails.Iron10.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron10, initialironfitdetails.Lie10, initialironfitdetails.Loft10, initialironfitdetails.Shaft10, initialironfitdetails.Frequency10, initialironfitdetails.Length10, "$" + initialironfitdetails.Cost10.ToString());
                    }
                    if (initialironfitdetails.Iron11.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron11, initialironfitdetails.Lie11, initialironfitdetails.Loft11, initialironfitdetails.Shaft11, initialironfitdetails.Frequency11, initialironfitdetails.Length11, "$" + initialironfitdetails.Cost11.ToString());
                    }
                    if (initialironfitdetails.Iron12.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron12, initialironfitdetails.Lie12, initialironfitdetails.Loft12, initialironfitdetails.Shaft12, initialironfitdetails.Frequency12, initialironfitdetails.Length12, "$" + initialironfitdetails.Cost12.ToString());
                    }
                    if (initialironfitdetails.Iron13.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron13, initialironfitdetails.Lie13, initialironfitdetails.Loft13, initialironfitdetails.Shaft13, initialironfitdetails.Frequency13, initialironfitdetails.Length13, "$" + initialironfitdetails.Cost13.ToString());
                    }
                    if (initialironfitdetails.Iron14.ToLower() != "none")
                    {
                        dt3.Rows.Add(initialironfitdetails.Iron14, initialironfitdetails.Lie14, initialironfitdetails.Loft14, initialironfitdetails.Shaft14, initialironfitdetails.Frequency14, initialironfitdetails.Length14, "$" + initialironfitdetails.Cost14.ToString());
                    }
                    GridView3.DataSource = dt3;
                    GridView3.DataBind();
                    if (!IsPostBack)
                    {
                        if (initialironfitdetails.Selected1 == 1)
                        {
                            if (initialironfitdetails.Iron1.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron1.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[0].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected2 == 1)
                        {
                            if (initialironfitdetails.Iron2.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron2.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[1].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected3 == 1)
                        {
                            if (initialironfitdetails.Iron3.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron3.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[2].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected4 == 1)
                        {
                            if (initialironfitdetails.Iron4.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron4.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[3].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected5 == 1)
                        {
                            if (initialironfitdetails.Iron5.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron5.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[4].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected6 == 1)
                        {
                            if (initialironfitdetails.Iron6.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron6.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[5].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected7 == 1)
                        {
                            if (initialironfitdetails.Iron7.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron7.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[6].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected8 == 1)
                        {
                            if (initialironfitdetails.Iron8.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron8.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[7].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected9 == 1)
                        {
                            if (initialironfitdetails.Iron9.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron9.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[8].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected10 == 1)
                        {
                            if (initialironfitdetails.Iron10.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron10.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[9].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected11 == 1)
                        {
                            if (initialironfitdetails.Iron11.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron11.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[10].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected12 == 1)
                        {
                            if (initialironfitdetails.Iron12.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron12.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[11].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected13 == 1)
                        {
                            if (initialironfitdetails.Iron13.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron13.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[12].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (initialironfitdetails.Selected14 == 1)
                        {
                            if (initialironfitdetails.Iron14.ToLower() != "none")
                            {
                                if (initialironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Checked = true;
                                    GridView3.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Checked = false;
                                    GridView3.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[8].Controls[1]).Checked = true;
                                GridView3.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (initialironfitdetails.Iron14.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Checked = false;
                                GridView3.Rows[13].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[8].Controls[1]).Checked = false;
                                GridView3.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                    }
                    else
                    {
                    }
                    GridView3.Visible = true;
                    Label29.Text = "Since you have had a SwingModel Initial Iron Fitting Session, your fitting results are presented below. You may hover your mouse over each Column Name for more information about the specific column.";
                    Label32.Visible = true;
                    Label23.Visible = true;
                    Label38.Visible = true;
                    Label39.Visible = true;
                }
                catch (Exception ex)
                {
                    GridView3.Visible = false;
                    Label29.Text = "Since you have not yet had a SwingModel Initial Iron Fitting Session, there are no records for your Initial Iron Fitting. Please ask your teaching professional how to obtain a SwingModel Initial Iron Fitting Session.";
                    Label32.Visible = false;
                    Label23.Visible = false;
                    Label38.Visible = false;
                    Label39.Visible = false;
                }

                try
                {
                    finalironfit = DataRepository.FinalIronFitProvider.GetByCurrentFitStatusId(currentfitstatus.CurrentFitStatusId)[0];
                    finalironfitdetails = DataRepository.FinalIronFitDetailsProvider.GetByFinalIronFitId(finalironfit.FinalIronFitId)[0];
                    finalironselect = DataRepository.FinalIronSelectProvider.GetByFinalIronFitId(finalironfit.FinalIronFitId)[0];
                    finalironfitball = DataRepository.FinalIronFitBallProvider.GetByFinalIronFitId(currentfitstatus.CurrentFitStatus)[0];
                    finalironfitgrip = DataRepository.FinalIronFitGripProvider.GetByFinalIronFitId(currentfitstatus.CurrentFitStatus)[0];
                    finalironfitnotes = DataRepository.FinalIronFitNotesProvider.GetByFinalIronFitId(currentfitstatus.CurrentFitStatus)[0];

                    Label17.Text = finalironfit.FinalIronFitDate.ToShortDateString();
                    Label25.Text = finalironfitball.FinalIronBallSelect;
                    Label41.Text = finalironfitgrip.FinalIronGripType + " (" + finalironfitgrip.GripSize + ")";

                    dt4.Columns.Add("Club", typeof(string));
                    dt4.Columns.Add("Lie", typeof(string));
                    dt4.Columns.Add("Loft", typeof(decimal));
                    dt4.Columns.Add("Shaft", typeof(string));
                    dt4.Columns.Add("Freq", typeof(int));
                    dt4.Columns.Add("Length", typeof(decimal));
                    dt4.Columns.Add("Cost", typeof(string));

                    if (finalironfitdetails.Iron1.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron1, finalironfitdetails.Lie1, finalironfitdetails.Loft1, finalironfitdetails.Shaft1, finalironfitdetails.Frequency1, finalironfitdetails.Length1, "$" + finalironfitdetails.Cost1.ToString());
                    }
                    if (finalironfitdetails.Iron2.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron2, finalironfitdetails.Lie2, finalironfitdetails.Loft2, finalironfitdetails.Shaft2, finalironfitdetails.Frequency2, finalironfitdetails.Length2, "$" + finalironfitdetails.Cost2.ToString());
                    }
                    if (finalironfitdetails.Iron3.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron3, finalironfitdetails.Lie3, finalironfitdetails.Loft3, finalironfitdetails.Shaft3, finalironfitdetails.Frequency3, finalironfitdetails.Length3, "$" + finalironfitdetails.Cost3.ToString());
                    }
                    if (finalironfitdetails.Iron4.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron4, finalironfitdetails.Lie4, finalironfitdetails.Loft4, finalironfitdetails.Shaft4, finalironfitdetails.Frequency4, finalironfitdetails.Length4, "$" + finalironfitdetails.Cost4.ToString());
                    }
                    if (finalironfitdetails.Iron5.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron5, finalironfitdetails.Lie5, finalironfitdetails.Loft5, finalironfitdetails.Shaft5, finalironfitdetails.Frequency5, finalironfitdetails.Length5, "$" + finalironfitdetails.Cost5.ToString());
                    }
                    if (finalironfitdetails.Iron6.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron6, finalironfitdetails.Lie6, finalironfitdetails.Loft6, finalironfitdetails.Shaft6, finalironfitdetails.Frequency6, finalironfitdetails.Length6, "$" + finalironfitdetails.Cost6.ToString());
                    }
                    if (finalironfitdetails.Iron7.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron7, finalironfitdetails.Lie7, finalironfitdetails.Loft7, finalironfitdetails.Shaft7, finalironfitdetails.Frequency7, finalironfitdetails.Length7, "$" + finalironfitdetails.Cost7.ToString());
                    }
                    if (finalironfitdetails.Iron8.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron8, finalironfitdetails.Lie8, finalironfitdetails.Loft8, finalironfitdetails.Shaft8, finalironfitdetails.Frequency8, finalironfitdetails.Length8, "$" + finalironfitdetails.Cost8.ToString());
                    }
                    if (finalironfitdetails.Iron9.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron9, finalironfitdetails.Lie9, finalironfitdetails.Loft9, finalironfitdetails.Shaft9, finalironfitdetails.Frequency9, finalironfitdetails.Length9, "$" + finalironfitdetails.Cost9.ToString());
                    }
                    if (finalironfitdetails.Iron10.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron10, finalironfitdetails.Lie10, finalironfitdetails.Loft10, finalironfitdetails.Shaft10, finalironfitdetails.Frequency10, finalironfitdetails.Length10, "$" + finalironfitdetails.Cost10.ToString());
                    }
                    if (finalironfitdetails.Iron11.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron11, finalironfitdetails.Lie11, finalironfitdetails.Loft11, finalironfitdetails.Shaft11, finalironfitdetails.Frequency11, finalironfitdetails.Length11, "$" + finalironfitdetails.Cost11.ToString());
                    }
                    if (finalironfitdetails.Iron12.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron12, finalironfitdetails.Lie12, finalironfitdetails.Loft12, finalironfitdetails.Shaft12, finalironfitdetails.Frequency12, finalironfitdetails.Length12, "$" + finalironfitdetails.Cost12.ToString());
                    }
                    if (finalironfitdetails.Iron13.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron13, finalironfitdetails.Lie13, finalironfitdetails.Loft13, finalironfitdetails.Shaft13, finalironfitdetails.Frequency13, finalironfitdetails.Length13, "$" + finalironfitdetails.Cost13.ToString());
                    }
                    if (finalironfitdetails.Iron14.ToLower() != "none")
                    {
                        dt4.Rows.Add(finalironfitdetails.Iron14, finalironfitdetails.Lie14, finalironfitdetails.Loft14, finalironfitdetails.Shaft14, finalironfitdetails.Frequency14, finalironfitdetails.Length14, "$" + finalironfitdetails.Cost14.ToString());
                    }
                    GridView4.DataSource = dt4;
                    GridView4.DataBind();
                    if (!IsPostBack)
                    {
                        if (finalironfitdetails.Selected1 == 1)
                        {
                            if (finalironfitdetails.Iron1.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[0].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron1.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[0].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[0].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[0].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected2 == 1)
                        {
                            if (finalironfitdetails.Iron2.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[1].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron2.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[1].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[1].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[1].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected3 == 1)
                        {
                            if (finalironfitdetails.Iron3.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[2].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron3.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[2].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[2].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[2].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected4 == 1)
                        {
                            if (finalironfitdetails.Iron4.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[3].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron4.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[3].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[3].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[3].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected5 == 1)
                        {
                            if (finalironfitdetails.Iron5.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[4].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron5.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[4].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[4].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[4].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected6 == 1)
                        {
                            if (finalironfitdetails.Iron6.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[5].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron6.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[5].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[5].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[5].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected7 == 1)
                        {
                            if (finalironfitdetails.Iron7.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[6].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron7.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[6].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[6].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[6].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected8 == 1)
                        {
                            if (finalironfitdetails.Iron8.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[7].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron8.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[7].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[7].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[7].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected9 == 1)
                        {
                            if (finalironfitdetails.Iron9.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[8].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron9.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[8].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[8].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[8].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected10 == 1)
                        {
                            if (finalironfitdetails.Iron10.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[9].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron10.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[9].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[9].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[9].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected11 == 1)
                        {
                            if (finalironfitdetails.Iron11.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[10].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron11.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[10].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[10].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[10].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected12 == 1)
                        {
                            if (finalironfitdetails.Iron12.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[11].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron12.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[11].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[11].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[11].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected13 == 1)
                        {
                            if (finalironfitdetails.Iron13.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[12].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron13.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[12].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[12].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[12].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        if (finalironfitdetails.Selected14 == 1)
                        {
                            if (finalironfitdetails.Iron14.ToLower() != "none")
                            {
                                if (finalironselect.Purchase == 1)
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Checked = true;
                                    GridView4.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Enabled = false;
                                }
                                else
                                {
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Checked = false;
                                    GridView4.Rows[13].Cells[0].Controls[1].Visible = true;
                                    ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                }
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[8].Controls[1]).Checked = true;
                                GridView4.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                        else
                        {
                            if (finalironfitdetails.Iron14.ToLower() != "none")
                            {
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Checked = false;
                                GridView4.Rows[13].Cells[0].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[0].Controls[1]).Enabled = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[8].Controls[1]).Checked = false;
                                GridView4.Rows[13].Cells[8].Controls[1].Visible = true;
                                ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[13].Cells[8].Controls[1]).Enabled = false;
                            }
                        }
                    }
                    else
                    {
                    }
                    GridView4.Visible = true;
                    Label30.Text = "Since you have had a SwingModel Final Iron Fitting Session, your fitting results are presented below. You may hover your mouse over each Column Name for more information about the specific column.";
                    Label33.Visible = true;
                    Label25.Visible = true;
                    Label40.Visible = true;
                    Label41.Visible = true;
                }
                catch (Exception ex)
                {
                    GridView4.Visible = false;
                    Label30.Text = "Since you have not yet had a SwingModel Final Iron Fitting Session, there are no records for your Final Iron Fitting. Please ask your teaching professional how to obtain a SwingModel Final Iron Fitting Session.";
                    Label33.Visible = false;
                    Label25.Visible = false;
                    Label40.Visible = false;
                    Label41.Visible = false;
                }
            }
            else
            {
                /*
                if (initialwoodfitdetails.Wood1.ToLower() != "none")
                {
                    GridView1.Rows[0].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 0])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[0].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[0].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood2.ToLower() != "none")
                {
                    GridView1.Rows[1].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 1])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[1].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[1].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood3.ToLower() != "none")
                {
                    GridView1.Rows[2].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 2])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[2].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[2].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood4.ToLower() != "none")
                {
                    GridView1.Rows[3].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 3])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[3].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[3].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood5.ToLower() != "none")
                {
                    GridView1.Rows[4].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 4])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[4].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[4].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood6.ToLower() != "none")
                {
                    GridView1.Rows[5].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 5])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[5].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[5].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood7.ToLower() != "none")
                {
                    GridView1.Rows[6].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 6])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[6].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[6].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood8.ToLower() != "none")
                {
                    GridView1.Rows[7].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 7])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[7].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[7].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood9.ToLower() != "none")
                {
                    GridView1.Rows[8].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 8])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[8].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[8].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood10.ToLower() != "none")
                {
                    GridView1.Rows[9].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 9])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[9].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[9].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood11.ToLower() != "none")
                {
                    GridView1.Rows[10].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 10])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[10].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[10].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood12.ToLower() != "none")
                {
                    GridView1.Rows[11].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 11])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[11].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[11].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood13.ToLower() != "none")
                {
                    GridView1.Rows[12].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 12])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[12].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[12].Cells[8].Controls[1].Visible = true;
                }
                if (initialwoodfitdetails.Wood14.ToLower() != "none")
                {
                    GridView1.Rows[13].Cells[0].Controls[1].Visible = true;
                    if (isChecked[0, 13])
                    {
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Checked = true;
                        ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[13].Cells[0].Controls[1]).Enabled = false;
                    }
                    GridView1.Rows[13].Cells[8].Controls[1].Visible = true;
                }
                */
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        /*
        System.Web.UI.WebControls.CheckBox chkStatus = (System.Web.UI.WebControls.CheckBox)sender;
        GridViewRow row = (GridViewRow)chkStatus.NamingContainer;

        string cid = row.Cells[0].Controls[1].ToString();
        bool status = chkStatus.Checked;
        string rowcost = row.Cells[7].Text;
        rowcost = rowcost.Substring(1, rowcost.Length - 1);
        */

        subtotal1 = Convert.ToDecimal(0);
        for (int y = 0; y < GridView1.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Enabled)
                subtotal1 = subtotal1 + Convert.ToDecimal(GridView1.Rows[y].Cells[7].Text.Substring(1, GridView1.Rows[y].Cells[7].Text.ToString().Length - 1));
        }

        if (subtotal1.Equals(Convert.ToDecimal(0)))
            Label12.Text = "$0.00";
        else
            Label12.Text = "$" + subtotal1.ToString();
        Tabs.ActiveTabIndex = 0;
    }

    public void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        subtotal2 = Convert.ToDecimal(0);
        for (int y = 0; y < GridView2.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Enabled)
                subtotal2 = subtotal2 + Convert.ToDecimal(GridView2.Rows[y].Cells[7].Text.Substring(1, GridView2.Rows[y].Cells[7].Text.ToString().Length - 1));
        }

        if (subtotal2.Equals(Convert.ToDecimal(0)))
            Label16.Text = "$0.00";
        else
            Label16.Text = "$" + subtotal2.ToString();
        Tabs.ActiveTabIndex = 1;
    }

    public void CheckBox3_CheckedChanged(object sender, EventArgs e)
    {
        subtotal3 = Convert.ToDecimal(0);
        for (int y = 0; y < GridView3.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Enabled)
                subtotal3 = subtotal3 + Convert.ToDecimal(GridView3.Rows[y].Cells[7].Text.Substring(1, GridView3.Rows[y].Cells[7].Text.ToString().Length - 1));
        }

        if (subtotal3.Equals(Convert.ToDecimal(0)))
            Label20.Text = "$0.00";
        else
            Label20.Text = "$" + subtotal3.ToString();
        Tabs.ActiveTabIndex = 2;
    }

    public void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {
        subtotal4 = Convert.ToDecimal(0);
        for (int y = 0; y < GridView4.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Enabled)
                subtotal4 = subtotal4 + Convert.ToDecimal(GridView4.Rows[y].Cells[7].Text.Substring(1, GridView4.Rows[y].Cells[7].Text.ToString().Length - 1));
        }

        if (subtotal4.Equals(Convert.ToDecimal(0)))
            Label24.Text = "$0.00";
        else
            Label24.Text = "$" + subtotal4.ToString();
        Tabs.ActiveTabIndex = 3;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        order.CustomerId = customer.CustomerId;
        order.OrderDate = DateTime.Now;
        order.OrderType = 1;
        order.TransactionComplete = 0;
        DataRepository.OrderProvider.Insert(order);

        for (int y = 0; y < GridView1.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView1.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView1.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView1.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView1.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView1.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView1.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView1.Rows[y].Cells[7].Text.Substring(1, GridView1.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialwoodfitgrip.InitialWoodGripType;
                cluborder.GripSize = initialwoodfitgrip.GripSize;
                cluborder.Notes = initialwoodfitnotes.InitialWoodClubFittingNotes;
                cluborder.FitType = 1;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView2.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView2.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView2.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView2.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView2.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView2.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView2.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView2.Rows[y].Cells[7].Text.Substring(1, GridView2.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalwoodfitgrip.FinalWoodGripType;
                cluborder.GripSize = finalwoodfitgrip.GripSize;
                cluborder.Notes = finalwoodfitnotes.FinalWoodClubFittingNotes;
                cluborder.FitType = 2;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView3.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView3.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView3.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView3.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView3.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView3.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView3.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView3.Rows[y].Cells[7].Text.Substring(1, GridView3.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialironfitgrip.InitialIronGripType;
                cluborder.GripSize = initialironfitgrip.GripSize;
                cluborder.Notes = initialironfitnotes.InitialIronClubFittingNotes;
                cluborder.FitType = 3;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView4.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView4.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView4.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView4.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView4.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView4.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView4.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView4.Rows[y].Cells[7].Text.Substring(1, GridView4.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalironfitgrip.FinalIronGripType;
                cluborder.GripSize = finalironfitgrip.GripSize;
                cluborder.Notes = finalironfitnotes.FinalIronClubFittingNotes;
                cluborder.FitType = 4;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }

        //Response.Redirect("https://www.swingmodel.com/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
        Response.Redirect("~/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        order.CustomerId = customer.CustomerId;
        order.OrderDate = DateTime.Now;
        order.OrderType = 1;
        order.TransactionComplete = 0;
        DataRepository.OrderProvider.Insert(order);

        for (int y = 0; y < GridView1.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView1.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView1.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView1.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView1.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView1.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView1.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView1.Rows[y].Cells[7].Text.Substring(1, GridView1.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialwoodfitgrip.InitialWoodGripType;
                cluborder.GripSize = initialwoodfitgrip.GripSize;
                cluborder.Notes = initialwoodfitnotes.InitialWoodClubFittingNotes;
                cluborder.FitType = 1;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView2.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView2.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView2.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView2.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView2.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView2.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView2.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView2.Rows[y].Cells[7].Text.Substring(1, GridView2.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalwoodfitgrip.FinalWoodGripType;
                cluborder.GripSize = finalwoodfitgrip.GripSize;
                cluborder.Notes = finalwoodfitnotes.FinalWoodClubFittingNotes;
                cluborder.FitType = 2;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView3.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView3.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView3.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView3.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView3.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView3.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView3.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView3.Rows[y].Cells[7].Text.Substring(1, GridView3.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialironfitgrip.InitialIronGripType;
                cluborder.GripSize = initialironfitgrip.GripSize;
                cluborder.Notes = initialironfitnotes.InitialIronClubFittingNotes;
                cluborder.FitType = 3;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView4.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView4.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView4.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView4.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView4.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView4.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView4.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView4.Rows[y].Cells[7].Text.Substring(1, GridView4.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalironfitgrip.FinalIronGripType;
                cluborder.GripSize = finalironfitgrip.GripSize;
                cluborder.Notes = finalironfitnotes.FinalIronClubFittingNotes;
                cluborder.FitType = 4;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }

        //Response.Redirect("https://www.swingmodel.com/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
        Response.Redirect("~/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        order.CustomerId = customer.CustomerId;
        order.OrderDate = DateTime.Now;
        order.OrderType = 1;
        order.TransactionComplete = 0;
        DataRepository.OrderProvider.Insert(order);

        for (int y = 0; y < GridView1.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView1.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView1.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView1.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView1.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView1.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView1.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView1.Rows[y].Cells[7].Text.Substring(1, GridView1.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialwoodfitgrip.InitialWoodGripType;
                cluborder.GripSize = initialwoodfitgrip.GripSize;
                cluborder.Notes = initialwoodfitnotes.InitialWoodClubFittingNotes;
                cluborder.FitType = 1;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView2.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView2.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView2.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView2.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView2.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView2.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView2.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView2.Rows[y].Cells[7].Text.Substring(1, GridView2.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalwoodfitgrip.FinalWoodGripType;
                cluborder.GripSize = finalwoodfitgrip.GripSize;
                cluborder.Notes = finalwoodfitnotes.FinalWoodClubFittingNotes;
                cluborder.FitType = 2;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView3.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView3.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView3.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView3.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView3.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView3.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView3.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView3.Rows[y].Cells[7].Text.Substring(1, GridView3.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialironfitgrip.InitialIronGripType;
                cluborder.GripSize = initialironfitgrip.GripSize;
                cluborder.Notes = initialironfitnotes.InitialIronClubFittingNotes;
                cluborder.FitType = 3;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView4.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView4.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView4.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView4.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView4.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView4.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView4.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView4.Rows[y].Cells[7].Text.Substring(1, GridView4.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalironfitgrip.FinalIronGripType;
                cluborder.GripSize = finalironfitgrip.GripSize;
                cluborder.Notes = finalironfitnotes.FinalIronClubFittingNotes;
                cluborder.FitType = 4;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }

        //Response.Redirect("https://www.swingmodel.com/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
        Response.Redirect("~/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        order.CustomerId = customer.CustomerId;
        order.OrderDate = DateTime.Now;
        order.OrderType = 1;
        order.TransactionComplete = 0;
        DataRepository.OrderProvider.Insert(order);

        for (int y = 0; y < GridView1.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView1.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView1.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView1.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView1.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView1.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView1.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView1.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView1.Rows[y].Cells[7].Text.Substring(1, GridView1.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialwoodfitgrip.InitialWoodGripType;
                cluborder.GripSize = initialwoodfitgrip.GripSize;
                cluborder.Notes = initialwoodfitnotes.InitialWoodClubFittingNotes;
                cluborder.FitType = 1;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView2.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView2.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView2.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView2.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView2.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView2.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView2.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView2.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView2.Rows[y].Cells[7].Text.Substring(1, GridView2.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalwoodfitgrip.FinalWoodGripType;
                cluborder.GripSize = finalwoodfitgrip.GripSize;
                cluborder.Notes = finalwoodfitnotes.FinalWoodClubFittingNotes;
                cluborder.FitType = 2;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView3.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView3.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView3.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView3.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView3.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView3.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView3.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView3.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView3.Rows[y].Cells[7].Text.Substring(1, GridView3.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = initialironfitgrip.InitialIronGripType;
                cluborder.GripSize = initialironfitgrip.GripSize;
                cluborder.Notes = initialironfitnotes.InitialIronClubFittingNotes;
                cluborder.FitType = 3;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }
        for (int y = 0; y < GridView4.Rows.Count; y++)
        {
            if (((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Checked && ((System.Web.UI.WebControls.CheckBox)GridView4.Rows[y].Cells[0].Controls[1]).Enabled)
            {
                cluborder.OrderId = order.OrderId;
                cluborder.Club = GridView4.Rows[y].Cells[1].Text;
                cluborder.Lie = GridView4.Rows[y].Cells[2].Text;
                cluborder.Loft = Convert.ToDecimal(GridView4.Rows[y].Cells[3].Text);
                cluborder.Shaft = GridView4.Rows[y].Cells[4].Text;
                cluborder.Frequency = Convert.ToInt16(GridView4.Rows[y].Cells[5].Text);
                cluborder.Length = Convert.ToDecimal(GridView4.Rows[y].Cells[6].Text);
                cluborder.Cost = Convert.ToDecimal(GridView4.Rows[y].Cells[7].Text.Substring(1, GridView4.Rows[y].Cells[7].Text.ToString().Length - 1));
                cluborder.Grip = finalironfitgrip.FinalIronGripType;
                cluborder.GripSize = finalironfitgrip.GripSize;
                cluborder.Notes = finalironfitnotes.FinalIronClubFittingNotes;
                cluborder.FitType = 4;
                DataRepository.ClubOrderProvider.Insert(cluborder);
            }
        }

        //Response.Redirect("https://www.swingmodel.com/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
        Response.Redirect("~/Shop/ClubOrder.aspx?orderid=" + order.OrderId.ToString());
    }
}
