﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_MyTeacher : System.Web.UI.Page
public partial class Users_MyTeacher : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    Teacher teacher = new Teacher();
    TList<Lesson> lessons = new TList<Lesson>();
    TList<Movie> movies = new TList<Movie>();
    bool customerexists = false;
    bool customerprofileexists = false;
    bool lessonsexist = false;
    TimeSpan span;
    DataTable dtCoachname = new DataTable();
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();
    protected override void OnPreLoad(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }

        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        Label3.Text = customer.FirstName;
        Label4.Text = customer.LastName;
        customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
        Label6.Text = customersite.SiteName;
        teacher = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
        int custid = customer.CustomerId;
        dtCoachname = sae.Get_PrimaryCoach(custid);
        Label8.Text = dtCoachname.Rows[0]["CoachName"].ToString();
        //Label8.Text = teacher.FirstName + " " + teacher.LastName;
        try
        {
            lessons = DataRepository.LessonProvider.GetByCustomerId(customer.CustomerId);
            if (lessons.Count > 0)
                lessonsexist = true;
            else
                lessonsexist = false;
        }
        catch (Exception ex)
        {
            lessonsexist = false;
        }
        
        if (!lessonsexist)
        {
            //Label10.Text = "No lessons taken.";
        }
        else
        {
            try
            {
                foreach (Lesson l in lessons)
                {
                    DataRepository.LessonProvider.DeepLoad(l);
                    foreach (Movie m in l.MovieCollection)
                    {

                        DataRepository.MovieProvider.DeepLoad(m);
                        movies.Add(m);
                    }
                }
                movies.Sort("DateRecorded DESC");
            }
            catch (Exception ex)
            {
                lessonsexist = false;
            }
            //if (lessonsexist)
            //{
            //    span = DateTime.Today.Subtract(movies[0].DateRecorded);
            //    Label10.Text = span.Days.ToString();
            //}
            //else
            //    Label10.Text = "No Lessons available.";
        }

        Image1.ImageUrl = "~" + teacher.PicturePath;
        Label1.Text = teacher.WelcomeText;
        Label11.Text = teacher.BioText;

        //MessageBox.Show(Convert.ToString(myCheckProfiles.Personal()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Address()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Contact()));

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Golf() && myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }
        }

        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
