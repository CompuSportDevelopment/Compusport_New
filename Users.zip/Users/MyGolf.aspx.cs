﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Windows.Forms;

//public partial class Users_MyGolf : System.Web.UI.Page
public partial class Users_MyGolf : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    bool customerexists = false;
    bool customerprofileexists = false;
    int x;
    CompuSportDAL.SprintAthleteEdit _sprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();
    protected override void OnPreLoad(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    //this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }

        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
                Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
                Guid rollid = _sprintAthleteEdit.GetRollIdByUserId(MemGuid);
                if (rollid.ToString().Trim().ToUpper() != "3C195D36-1032-4CF9-A383-757A2EC5BEA2")//Administrators
                {
                    DropDownList3.Enabled = false;
                }
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }

            try
            {
                customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                customerprofileexists = true;
            }
            catch
            {
                //no entery in CustomerProfile table for current member
                customerprofileexists = false;
            }
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            if (customerprofileexists)
            {
                DropDownList1.SelectedValue = customerprofile.Age;
                DropDownList2.SelectedValue = customerprofile.Hand;
                //DropDownList3.SelectedValue = Convert.ToInt16(customerprofile.Hcp).ToString();
                if (customerprofile.InitialTeacher.Equals(-1))
                {
                    DropDownList3.SelectedValue = "4";
                }
                else
                {
                    DropDownList3.SelectedValue = customerprofile.InitialTeacher.ToString();
                }
                
                DropDownList4.SelectedValue = customerprofile.Rounds;
                DropDownList5.SelectedValue = customerprofile.Practice;
                DropDownList6.SelectedValue = customerprofile.Lessons;
                DropDownList7.SelectedValue = customerprofile.Altitude;
                DropDownList8.SelectedValue = customerprofile.Wind;
                DropDownList9.SelectedValue = customerprofile.Roll;
            }

        }
        else
        {
            //MessageBox.Show("You must be logged in to submit your information.");
        }

        //if (customerprofile.Age.Equals("") || customerprofile.Age.Equals(null))
        //{
        //    //TextBox1.Focus();
        //    Label18.Visible = true;
        //}
        //else
        //{
        //    Label18.Visible = false;
        //}
        //if (customerprofile.Hand.Equals("") || customerprofile.Hand.Equals(null))
        //{
        //    Label19.Visible = true;
        //}
        //else
        //{
        //    Label19.Visible = false;
        //}
        //if (customerprofile.Hcp.Equals("") || customerprofile.Hcp.Equals(null) || customerprofile.Hcp.Equals(Convert.ToDecimal(-1)))
        //{
        //    Label20.Visible = true;
        //}
        //else
        //{
        //    Label20.Visible = false;
        //}
        //if (customerprofile.Rounds.Equals("") || customerprofile.Rounds.Equals(null))
        //{
        //    Label21.Visible = true;
        //}
        //else
        //{
        //    Label21.Visible = false;
        //}
        //if (customerprofile.Practice.Equals("") || customerprofile.Practice.Equals(null))
        //{
        //    Label22.Visible = true;
        //}
        //else
        //{
        //    Label22.Visible = false;
        //}
        //if (customerprofile.Lessons.Equals("") || customerprofile.Lessons.Equals(null))
        //{
        //    Label23.Visible = true;
        //}
        //else
        //{
        //    Label23.Visible = false;
        //}
        //if (customerprofile.Altitude.Equals("") || customerprofile.Altitude.Equals(null))
        //{
        //    Label24.Visible = true;
        //}
        //else
        //{
        //    Label24.Visible = false;
        //}
        //if (customerprofile.Wind.Equals("") || customerprofile.Wind.Equals(null))
        //{
        //    Label26.Visible = true;
        //}
        //else
        //{
        //    Label26.Visible = false;
        //}
        //if (customerprofile.Roll.Equals("") || customerprofile.Roll.Equals(null))
        //{
        //    Label27.Visible = true;
        //}
        //else
        //{
        //    Label27.Visible = false;
        //}
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            customerprofile.CustomerId = customer.CustomerId;
            customerprofile.Age = DropDownList1.SelectedValue;
            customerprofile.Hand = DropDownList2.SelectedValue;
            customerprofile.InitialTeacher = Convert.ToInt16(DropDownList3.SelectedValue);
            customerprofile.Rounds = DropDownList4.SelectedValue;
            customerprofile.Practice = DropDownList5.SelectedValue;
            customerprofile.Lessons = DropDownList6.SelectedValue;
            customerprofile.Altitude = DropDownList7.SelectedValue;
            customerprofile.Wind = DropDownList8.SelectedValue;
            customerprofile.Roll = DropDownList9.SelectedValue;

            if (customerprofileexists)
                DataRepository.CustomerProfileProvider.Update(customerprofile);
            else
                DataRepository.CustomerProfileProvider.Insert(customerprofile);
        }
        else
        {
            //MessageBox.Show("You must be logged in to submit your information.");
        }
        Response.Redirect("~/Users/Default.aspx");
    }
}
