﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Windows.Forms;
using System.Data.SqlClient;


//public partial class Users_MyDimensions : System.Web.UI.Page
public partial class Users_MyDimensions : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    bool customerexists = false;
    bool customerprofileexists = false;
    int x;

    string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    CompuSportDataAccess.AthleteBodyDimensions abd = new CompuSportDataAccess.AthleteBodyDimensions();

    //string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    //int CustomerID;
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable dt1 = new DataTable();
        // dt1 = SelectHeight(CustomerID);
        // DropDownList1.DataSource = dt1;
        //// DropDownList1.DataTextField = "Firstname";
        // DropDownList1.DataValueField = "Customerid";
        // DropDownList1.DataBind();     

    }

    //public DataTable SelectHeight(int Customerid)
    //{

    //    DataTable dt = new DataTable();
    //    try
    //    {
    //        using (SqlConnection connection = new SqlConnection(ConnectionString))
    //        {
    //            connection.Open();
    //            using (SqlCommand cmdSelectTire = connection.CreateCommand())
    //            {
    //                cmdSelectTire.CommandType = CommandType.StoredProcedure;
    //                cmdSelectTire.CommandText = "Select_Height";
    //                cmdSelectTire.Parameters.AddWithValue("@CustomerID", Customerid);
    //                cmdSelectTire.Connection = connection;
    //                SqlDataAdapter da = new SqlDataAdapter(cmdSelectTire);
    //                da.Fill(dt);
    //                return dt;
    //            }
    //        }
    //    }
    //    catch
    //    {
    //        return dt = null;
    //    }
    //}


    protected override void OnPreLoad(EventArgs e)
    {
        dt = abd.GetDataFromCustomerProfile(customer.CustomerId);

        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }

            try
            {
                customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
                customerprofileexists = true;
            }
            catch
            {
                //no entery in CustomerProfile table for current member
                customerprofileexists = false;
            }
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
       
            dt = abd.GetDataFromCustomerProfile(customer.CustomerId);
            CheckProfiles myCheckProfiles = new CheckProfiles();

            if (this.User.Identity.IsAuthenticated)
            {
                if (!myCheckProfiles.Personal())
                {
                    //MessageBox.Show("1a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }

                if (!myCheckProfiles.Address())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                    {
                        //MessageBox.Show("2a");
                        this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                    }
                }

                if (!myCheckProfiles.Facility())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                    {
                        //MessageBox.Show("3a");
                        this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                    }
                }

                if (!myCheckProfiles.Dimensions())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                    {
                        //MessageBox.Show("4a");
                        //this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                    }
                }

                if (!myCheckProfiles.Golf())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                    {
                        //MessageBox.Show("5a");
                        this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                    }
                }
            }



            x = 0;
            for (int i = 50; i <= 350; i++)
            {
                x++;
                DropDownList2.Items.Add(i.ToString());
                if (Page.User.Identity.IsAuthenticated)
                {
                    if (customerprofileexists)
                    {
                        if (customerprofile.Weight.Equals(Convert.ToDecimal(i)))
                            DropDownList2.Items[x].Selected = true;
                    }
                }
            }
            if (customerprofileexists)
            {
                if (customerprofile.Weight.Equals(Convert.ToDecimal(0)))
                    DropDownList2.SelectedIndex = 0;
            }

            x = 0;
            for (Double f = 12; f <= 24; f = f + 0.5)
            {
                x++;
                DropDownList3.Items.Add(f.ToString());
                if (Page.User.Identity.IsAuthenticated)
                {
                    if (customerprofileexists)
                    {
                        if (customerprofile.Shoulder.Equals(Convert.ToDecimal(f)))
                        {
                            DropDownList3.Items[x].Selected = true;
                        }
                    }
                }
            }
            if (customerprofileexists)
            {
                if (customerprofile.Shoulder.Equals(Convert.ToDecimal(0)))
                    DropDownList3.SelectedIndex = 0;
            }

            x = 0;
            #region[upperaremlength]
            if (dt.Rows[0]["UpperArmLength"] == DBNull.Value)
            {
                decimal Upperarmlength = Convert.ToDecimal(null);
                Label19.Visible = true;
                for (Double f = 8; f <= 14.5; f = f + 0.5)
                {
                    x++;
                    DropDownList4.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Upperarmlength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList4.Items[x].Selected = true;
                        }
                    }
                }

                if (customerprofileexists)
                {
                    if (Upperarmlength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList4.SelectedIndex = 0;
                }
            }
            else
            {
                decimal Upperarmlength = Convert.ToDecimal(dt.Rows[0]["UpperArmLength"]);
                Label19.Visible = false;
                for (Double f = 8; f <= 14.5; f = f + 0.5)
                {
                    x++;
                    DropDownList4.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Upperarmlength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList4.Items[x].Selected = true;
                        }
                    }
                }

                if (customerprofileexists)
                {
                    if (Upperarmlength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList4.SelectedIndex = 0;
                }
            }
            #endregion[upperaremlength]

            #region[Lowerarnlength]
            x = 0;
            if (dt.Rows[0]["LowerArmLength"] == DBNull.Value)
            {
                decimal Lowerarmlength = Convert.ToDecimal(null);
                Label20.Visible = true;
                for (Double f = 8; f <= 14.5; f = f + 0.5)
                {
                    x++;
                    DropDownList5.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Lowerarmlength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList5.Items[x].Selected = true;
                        }
                    }
                }
            }
            else
            {
                decimal Lowerarmlength = Convert.ToDecimal(dt.Rows[0]["LowerArmLength"]);
                Label20.Visible = false;
                for (Double f = 8; f <= 14.5; f = f + 0.5)
                {
                    x++;
                    DropDownList5.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Lowerarmlength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList5.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Lowerarmlength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList5.SelectedIndex = 0;
                }
            }
            #endregion[Lowerarnlength]


            x = 0;
            for (Double f = 20.0; f <= 40; f = f + 0.5)
            {
                x++;
                DropDownList6.Items.Add(f.ToString("#0.0"));
                if (Page.User.Identity.IsAuthenticated)
                {
                    if (customerprofileexists)
                    {
                        if (customerprofile.Waist.Equals(Convert.ToDecimal(f)))
                            DropDownList6.Items[x].Selected = true;
                    }
                }
            }
            if (customerprofileexists)
            {
                if (customerprofile.Waist.Equals(Convert.ToDecimal(0)))
                    DropDownList6.SelectedIndex = 0;
            }

            #region[upperleglength]
            x = 0;
            if (dt.Rows[0]["UpperLegLength"] == DBNull.Value)
            {
                decimal Upperleglength = Convert.ToDecimal(null);
                Label22.Visible = true;
                for (Double f = 10; f <= 24.5; f = f + 0.5)
                {
                    x++;
                    DropDownList7.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Upperleglength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList7.Items[x - 1].Selected = true;
                        }
                    }
                }
            }
            else
            {
                decimal Upperleglength = Convert.ToDecimal(dt.Rows[0]["UpperLegLength"]);
                Label22.Visible = false;
                for (Double f = 10; f <= 24.5; f = f + 0.5)
                {
                    x++;
                    DropDownList7.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Upperleglength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList7.Items[x - 1].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Upperleglength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList7.SelectedIndex = 0;
                }
            }
            #endregion[upperleglength]
            x = 0;
            for (Double f = 1; f <= 20; f = f + .5)
            {
                x++;
                DropDownList8.Items.Add(f.ToString());
                if (Page.User.Identity.IsAuthenticated)
                {
                    if (customerprofileexists)
                    {
                        if (customerprofile.Shoe.Equals(Convert.ToDecimal(f)))
                            DropDownList8.Items[x].Selected = true;
                    }
                }
            }
            if (customerprofileexists)
            {
                if (customerprofile.Shoe.Equals(Convert.ToDecimal(0)))
                    DropDownList8.SelectedIndex = 0;
            }

            #region[lowerleglegth]
            x = 0;
            if (dt.Rows[0]["LowerLegLength"] == DBNull.Value)
            {
                decimal Lowerleglength = Convert.ToDecimal(null);
                Label41.Visible = true;
                for (Double f = 10; f <= 24.5; f = f + 0.5)
                {
                    x++;
                    DropDownList9.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Lowerleglength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList9.Items[x].Selected = true;
                        }
                    }
                }
            }
            else
            {
                decimal Lowerleglength = Convert.ToDecimal(dt.Rows[0]["LowerLegLength"]);
                Label41.Visible = false;
                for (Double f = 10; f <= 24.5; f = f + 0.5)
                {
                    x++;
                    DropDownList9.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Lowerleglength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList9.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Lowerleglength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList9.SelectedIndex = 0;
                }
            }
            #endregion[lowerleglegth]

            #region[hiplength]
            x = 0;
            if (dt.Rows[0]["HipLength"] == DBNull.Value)
            {
                decimal Hiplength = Convert.ToDecimal(null);
                Label37.Visible = true;
                for (Double f = 4.0; f <= 8; f = f + 0.5)
                {
                    x++;
                    DropDownList10.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Hiplength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList10.Items[x].Selected = true;
                        }
                    }
                }
            }
            else
            {
                decimal Hiplength = Convert.ToDecimal(dt.Rows[0]["HipLength"]);
                Label37.Visible = false;
                for (Double f = 4; f <= 8; f = f + 0.5)
                {
                    x++;
                    DropDownList10.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Hiplength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Sleeve.Equals(Convert.ToDecimal(f)))
                                DropDownList10.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Hiplength.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Sleeve.Equals(Convert.ToDecimal(0)))
                        DropDownList10.SelectedIndex = 0;
                }
            }
            #endregion[hiplength]

            #region[trunklength]
            x = 0;
            if (dt.Rows[0]["TrunkLength"] == DBNull.Value)
            {
                decimal Trunklength = Convert.ToDecimal(null);
                Label45.Visible = true;
                for (Double f = 8; f <= 20.5; f = f + .5)
                {
                    x++;
                    DropDownList11.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Trunklength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Inseam.Equals(Convert.ToDecimal(f)))
                                DropDownList11.Items[x].Selected = true;
                        }
                    }
                }
            }
            else
            {
                decimal Trunklength = Convert.ToDecimal(dt.Rows[0]["TrunkLength"].ToString());
                Label45.Visible = false;
                for (Double f = 8; f <= 20.5; f = f + .5)
                {
                    x++;
                    DropDownList11.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Trunklength.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Inseam.Equals(Convert.ToDecimal(f)))
                                DropDownList11.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Trunklength.Equals(Convert.ToDecimal(0)))
                        // if (customerprofile.Inseam.Equals(Convert.ToDecimal(0)))
                        DropDownList11.SelectedIndex = 0;
                }
            }
            #endregion[]trunklength
            #region[ankleheight]
            x = 0;
            if (dt.Rows[0]["AnkleHeight"] == DBNull.Value)
            {
                decimal Ankleheight = Convert.ToDecimal(null);
                Label49.Visible = true;
                for (Double f = 2; f <= 4.5; f = f + .5)
                {
                    x++;
                    DropDownList12.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Ankleheight.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Waist.Equals(Convert.ToDecimal(f)))
                                DropDownList12.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Ankleheight.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Waist.Equals(Convert.ToDecimal(0)))
                        DropDownList12.SelectedIndex = 0;
                }
            }
            else
            {
                decimal Ankleheight = Convert.ToDecimal(dt.Rows[0]["AnkleHeight"]);
                Label49.Visible = false;
                for (Double f = 2; f <= 4.5; f = f + .5)
                {
                    x++;
                    DropDownList12.Items.Add(f.ToString());
                    if (Page.User.Identity.IsAuthenticated)
                    {
                        if (customerprofileexists)
                        {
                            if (Ankleheight.Equals(Convert.ToDecimal(f)))
                                // if (customerprofile.Waist.Equals(Convert.ToDecimal(f)))
                                DropDownList12.Items[x].Selected = true;
                        }
                    }
                }
                if (customerprofileexists)
                {
                    if (Ankleheight.Equals(Convert.ToDecimal(0)))
                        //if (customerprofile.Waist.Equals(Convert.ToDecimal(0)))
                        DropDownList12.SelectedIndex = 0;
                }
            }

            #endregion[ankleheight]

            if (Page.User.Identity.IsAuthenticated)
            {
                if (customerprofileexists)
                {
                    if (customerprofile.Height.Equals(Convert.ToDecimal(0)))
                        DropDownList1.SelectedIndex = 0;
                    else
                        DropDownList1.SelectedValue = Math.Round(customerprofile.Height, 0).ToString();

                    //if (customerprofile.Glove.Equals("") || customerprofile.Glove.Equals(null))
                    //    DropDownList5.SelectedIndex = 0;
                    //else
                    //    DropDownList5.SelectedValue = customerprofile.Glove;
                }
            }
            else
            {
                //MessageBox.Show("You must be logged in to submit your information.");
            }
            //if (customerprofile.Height.Equals("") || customerprofile.Height.Equals(null) || customerprofile.Height.Equals(Convert.ToDecimal(0)))
            //{
            //    //TextBox1.Focus();
            //    Label16.Visible = true;
            //}
            //else
            //{
            //    Label16.Visible = false;
            //}
            //if (customerprofile.Weight.Equals("") || customerprofile.Weight.Equals(null) || customerprofile.Weight.Equals(Convert.ToDecimal(0)))
            //{
            //    //MessageBox.Show(Profile.Weight.ToString());
            //    Label17.Visible = true;
            //}
            //else
            //{
            //    //MessageBox.Show(Profile.Weight.ToString());
            //    Label17.Visible = false;
            //}

            //if (customerprofile.Waist.Equals("") || customerprofile.Waist.Equals(null) || customerprofile.Waist.Equals(Convert.ToDecimal(0)))
            //{
            //    Label21.Visible = true;
            //}
            //else
            //{
            //    Label21.Visible = false;
            //}

            //if (customerprofile.Shoe.Equals("") || customerprofile.Shoe.Equals(null) || customerprofile.Shoe.Equals(Convert.ToDecimal(0)))
            //{
            //    Label23.Visible = true;
            //}
            //else
            //{
            //    Label23.Visible = false;
            //}
            //if (customerprofile.Shoulder.Equals("") || customerprofile.Shoulder.Equals(null) || customerprofile.Shoulder.Equals(Convert.ToDecimal(0)))
            //{
            //    Label18.Visible = true;
            //}
            //else
            //{
            //    Label18.Visible = false;
            //}

            //if (dt.Rows[0]["TrunkLength"] == DBNull.Value)

            //// decimal _Trunklength = Convert.ToDecimal(dt.Rows[0]["TrunkLength"].ToString());
            ////  if (_Trunklength.Equals(Convert.ToDecimal(0)))
            //{
            //    Label45.Visible = true;
            //}
            //else
            //{
            //    Label45.Visible = false;
            //}

            //// decimal _Upperleglength = Convert.ToDecimal(dt.Rows[0]["UpperLegLength"].ToString());
            //// if (_Upperleglength.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["UpperLegLength"] == DBNull.Value)
            //{
            //    Label22.Visible = true;
            //}
            //else
            //{
            //    Label22.Visible = false;
            //}

            ////decimal _Lowerleglength = Convert.ToDecimal(dt.Rows[0]["LowerLegLength"].ToString());
            ////if (_Lowerleglength.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["LowerLegLength"] == DBNull.Value)
            //{
            //    Label41.Visible = true;
            //}
            //else
            //{
            //    Label41.Visible = false;
            //}
            ////decimal _Hiplength = Convert.ToDecimal(dt.Rows[0]["HipLength"].ToString());
            ////if (_Hiplength.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["HipLength"] == DBNull.Value)
            //{
            //    Label37.Visible = true;
            //}
            //else
            //{
            //    Label37.Visible = false;
            //}

            ////decimal _Ankleheight = Convert.ToDecimal(dt.Rows[0]["AnkleHeight"].ToString());
            ////if (_Ankleheight.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["AnkleHeight"] == DBNull.Value)
            //{
            //    Label49.Visible = true;
            //}
            //else
            //{
            //    Label49.Visible = false;
            //}
            ////decimal _Lowerarmlength = Convert.ToDecimal(dt.Rows[0]["LowerArmLength"].ToString());
            ////if (_Lowerarmlength.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["LowerArmLength"] == DBNull.Value)
            //{
            //    Label20.Visible = true;
            //}
            //else
            //{
            //    Label20.Visible = false;
            //}

            ////decimal _Upperarmlength = Convert.ToDecimal(dt.Rows[0]["UpperArmLength"].ToString());
            ////if (_Upperarmlength.Equals(Convert.ToDecimal(0)))
            //if (dt.Rows[0]["UpperArmLength"] == DBNull.Value)
            //{
            //    Label19.Visible = true;
            //}
            //else
            //{
            //    Label19.Visible = false;
            //}

            base.OnPreRender(e);
       
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
       
        if (Page.User.Identity.IsAuthenticated)
        {
           
            customerprofile.CustomerId = customer.CustomerId;
            //string Varheight = Convert.ToString(DropDownList1.SelectedValue);
            //Varheight=Varheight.Substring(0, 2);
            customerprofile.Height = Convert.ToDecimal(DropDownList1.SelectedValue);
            //customerprofile.Height = Convert.ToDecimal(Varheight);
            customerprofile.Weight = Convert.ToDecimal(DropDownList2.SelectedValue);
            customerprofile.Shoulder = Convert.ToDecimal(DropDownList3.SelectedValue);
            decimal VarTrunklength = Convert.ToDecimal(DropDownList11.SelectedValue);
            decimal VarUpperarmlength = Convert.ToDecimal(DropDownList4.SelectedValue);
            decimal VarLowerarmlength = Convert.ToDecimal(DropDownList5.SelectedValue);
            // customerprofile.Sleeve = Convert.ToDecimal(DropDownList4.SelectedValue);
            // customerprofile.Glove = DropDownList5.SelectedValue;
            customerprofile.Waist = Convert.ToDecimal(DropDownList6.SelectedValue);
            decimal VarHiplength = Convert.ToDecimal(DropDownList10.SelectedValue);
            // customerprofile.Inseam = Convert.ToDecimal(DropDownList7.SelectedValue);
            decimal VarUpperleglength = Convert.ToDecimal(DropDownList7.SelectedValue);
            decimal VarLowerleglength = Convert.ToDecimal(DropDownList9.SelectedValue);
            decimal VarAnkleheight = Convert.ToDecimal(DropDownList12.SelectedValue);
            customerprofile.Shoe = Convert.ToDecimal(DropDownList8.SelectedValue);

            if (customerprofileexists)
            {
                //DataRepository.CustomerProfileProvider.Update(customerprofile);
                //update query

                try
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString))
                    {
                        conn.Open();
                        using (SqlCommand cmdInsert = new SqlCommand())
                        {
                            cmdInsert.CommandType = CommandType.StoredProcedure;
                            cmdInsert.CommandText = "UpdateCustomerProfile";
                            cmdInsert.Parameters.AddWithValue("@Customerid", customerprofile.CustomerId);
                            cmdInsert.Parameters.AddWithValue("@Height", customerprofile.Height);
                            cmdInsert.Parameters.AddWithValue("@Weight", customerprofile.Weight);
                            cmdInsert.Parameters.AddWithValue("@Shoulder", customerprofile.Shoulder);
                            cmdInsert.Parameters.AddWithValue("@Trunklength", VarTrunklength);
                            cmdInsert.Parameters.AddWithValue("@Upperarmlength", VarUpperarmlength);
                            cmdInsert.Parameters.AddWithValue("@Lowerarmlength", VarLowerarmlength);
                            cmdInsert.Parameters.AddWithValue("@Waist", customerprofile.Waist);
                            cmdInsert.Parameters.AddWithValue("@Hiplength", VarHiplength);
                            cmdInsert.Parameters.AddWithValue("@Upperleglength", VarUpperleglength);
                            cmdInsert.Parameters.AddWithValue("@Lowerleglength", VarLowerleglength);
                            cmdInsert.Parameters.AddWithValue("@Ankleheight", VarAnkleheight);
                            cmdInsert.Parameters.AddWithValue("@Shoe", customerprofile.Shoe);
                            cmdInsert.Connection = conn;
                            cmdInsert.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    ex.Message.ToString();
                }
            }
            else
            {
                //DataRepository.CustomerProfileProvider.Insert(customerprofile);
                //insert query
                try
                {
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.Open();
                        using (SqlCommand cmdInsert = new SqlCommand(ConnectionString))
                        {
                            cmdInsert.CommandType = CommandType.StoredProcedure;
                            cmdInsert.CommandText = "InsertIntoCustomerProfile";
                            cmdInsert.Parameters.AddWithValue("@Height", customerprofile.Height);
                            cmdInsert.Parameters.AddWithValue("@Weight", customerprofile.Weight);
                            cmdInsert.Parameters.AddWithValue("@Shoulder", customerprofile.Shoulder);
                            cmdInsert.Parameters.AddWithValue("@Trunklength", VarTrunklength);
                            cmdInsert.Parameters.AddWithValue("@Upperarmlength", VarUpperarmlength);
                            cmdInsert.Parameters.AddWithValue("@Lowerarmlength", VarLowerarmlength);
                            cmdInsert.Parameters.AddWithValue("@Waist", customerprofile.Waist);
                            cmdInsert.Parameters.AddWithValue("@Hiplength", VarHiplength);
                            cmdInsert.Parameters.AddWithValue("@Upperleglength", VarUpperleglength);
                            cmdInsert.Parameters.AddWithValue("@Lowerleglength", VarLowerleglength);
                            cmdInsert.Parameters.AddWithValue("@Ankleheight", VarAnkleheight);
                            cmdInsert.Parameters.AddWithValue("@Shoe", customerprofile.Shoe);
                            cmdInsert.Connection = conn;
                            cmdInsert.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    ex.Message.ToString();
                }
            }
        }
        else
        {
            //MessageBox.Show("You must be logged in to submit your information.");
        }

        Response.Redirect("~/Users/Default.aspx");
        
        
    }
       
}
