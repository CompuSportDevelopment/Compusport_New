﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_ChangePasswordEmail : System.Web.UI.Page
public partial class Users_ChangePasswordEmail : SwingModel.UI.BasePage
{
    string MemberEmail = "";
    MembershipUser member = Membership.GetUser();
    Customer customer;
    CompuSportDAL.SprintAthleteEdit _sprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();
    Guid rollid = new Guid();

    protected override void OnPreRender(EventArgs e)
    {
        MemberEmail = member.Email;
        Label5.Text = MemberEmail;
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(member.ProviderUserKey.ToString()))[0];
        Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
        rollid = _sprintAthleteEdit.GetRollIdByUserId(MemGuid);
        
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (!TextBox4.Text.Equals("") && !TextBox4.Text.Equals(null))
        {
            try
            {
                member.Email = TextBox4.Text;
                Membership.UpdateUser(member);
                Label8.Text = "Your email address has been changed successfully.";
                Label8.Visible = true;
            }
            catch (Exception ex)
            {
                Label8.Text = "Your email address was not changed!";
                Label8.Visible = true;
            }
        }
    }
}
