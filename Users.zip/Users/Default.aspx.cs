using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_Default : System.Web.UI.Page
public partial class Users_Default : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    CustomerSite customersite = new CustomerSite();
    Teacher teacher = new Teacher();
    TList<Lesson> lessons = new TList<Lesson>();
    TList<Movie> movies = new TList<Movie>();
    bool customerexists = false;
    bool customerprofileexists = false;
    bool lessonsexist = false;
    TimeSpan span;
    CompuSportDAL.SprintAthleteEdit sae = new CompuSportDAL.SprintAthleteEdit();
    DataTable dtCoachname = new DataTable();
    Teacher _teacher = new Teacher();
    TeacherSite _teachersite = new TeacherSite();
    CustomerSite _customersite = new CustomerSite();
    protected override void OnPreLoad(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }

        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        Guid MemGuid;
        //Customer customer;
        //Teacher teacher;
        Guid rollid = new Guid();
        MembershipUser member = Membership.GetUser();

        //MembershipUser member = Membership.GetUser(Login1.UserName);
        try
        {
            customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(member.ProviderUserKey.ToString()))[0];
            MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
        }
        catch
        {
            teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(member.ProviderUserKey.ToString()))[0];
            MemGuid = new Guid(teacher.AspnetMembershipUserId.ToString());
        }




        //customer = SwingModel.Data.DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(member.ProviderUserKey.ToString()))[0];
        //Guid MemGuid = new Guid(customer.AspnetMembershipUserId.ToString());
       
        rollid = sae.GetRollIdByUserId(MemGuid);
        if (rollid.ToString().Trim().ToUpper() == "D27F6DE3-A8D4-492E-B154-CF1BC5B44129")
        {
            CheckProfiles myCheckProfiles = new CheckProfiles();

            //MessageBox.Show(Convert.ToString(myCheckProfiles.Personal()));
            //MessageBox.Show(Convert.ToString(myCheckProfiles.Address()));
            //MessageBox.Show(Convert.ToString(myCheckProfiles.Contact()));

            if (this.User.Identity.IsAuthenticated)
            {
                if (!myCheckProfiles.Personal())
                {
                    //MessageBox.Show("1a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                    Response.Redirect("~/Users/MyAccount.aspx");
                }

                if (!myCheckProfiles.Address())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                    {
                        //MessageBox.Show("2a");
                        this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                    }
                }

                if (!myCheckProfiles.Facility())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                    {
                        //MessageBox.Show("3a");
                        this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                    }
                }

                if (!myCheckProfiles.Dimensions())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                    {
                        //MessageBox.Show("4a");
                        this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                    }
                }

                if (!myCheckProfiles.Golf())
                {
                    if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                    {
                        //MessageBox.Show("5a");
                        this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                    }
                }
            }

            Label3.Text = customer.FirstName;
            Label4.Text = customer.LastName;
            customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(customerprofile.CustomerSite);
            Label6.Text = customersite.SiteName;
            teacher = DataRepository.TeacherProvider.GetByTeacherId(customerprofile.Teacher);
            int custid = customer.CustomerId;
            dtCoachname = sae.Get_PrimaryCoach(custid);
            if (dtCoachname != null)
            {
                if (dtCoachname.Rows.Count > 0)
                {
                    Label8.Text = dtCoachname.Rows[0]["CoachName"].ToString();
                }
                else
                {
                    Label8.Text = "";
                }
            }
            //   Label8.Text = teacher.FirstName + " " + teacher.LastName;

            try
            {
                lessons = DataRepository.LessonProvider.GetByCustomerId(customer.CustomerId);
                if (lessons.Count > 0)
                    lessonsexist = true;
                else
                    lessonsexist = false;
            }
            catch (Exception ex)
            {
                lessonsexist = false;
            }

            lessonsexist = false; //temporary added (on:2-4-13)
            if (!lessonsexist)
            {
            //    Label10.Text = "No lessons taken.";
            }
            else
            {
                try
                {
                    foreach (Lesson l in lessons)
                    {
                        DataRepository.LessonProvider.DeepLoad(l);
                        foreach (Movie m in l.MovieCollection)
                        {

                            DataRepository.MovieProvider.DeepLoad(m);
                            movies.Add(m);
                        }
                    }
                    movies.Sort("DateRecorded DESC");
                }
                catch (Exception ex)
                {
                    lessonsexist = false;
                }

                //if (lessonsexist)
                //{
                //    span = DateTime.Today.Subtract(movies[0].DateRecorded);
                //    Label10.Text = span.Days.ToString();
                //}
                //else
                //    Label10.Text = "No Lessons available.";
            }

            base.OnPreRender(e);

            AboutMeSection.Visible = true;
            MemberNotices.Visible = true;
            Div1.Visible = false;
            FacilityMembers.Visible = false;
            Div2.Visible = false;
            CoachMembers.Visible = false;
            Div3.Visible = false;
            AdminMembers.Visible = false;

        }
        else if (rollid.ToString().Trim().ToUpper() == "3C195D36-1032-4CF9-A383-757A2EC5BEA2")//Administrators
        {
            Label21.Text = "";
            customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
            Label21.Text = customer.FirstName + " " + customer.LastName;

            AboutMeSection.Visible = false;
            MemberNotices.Visible = false;
            Div1.Visible = false;
            FacilityMembers.Visible = false;
            Div2.Visible = false;
            CoachMembers.Visible = false;
            Div3.Visible = true;
            AdminMembers.Visible = true;
        }
        else if (rollid.ToString().Trim().ToUpper() == "6B5A6229-1751-436C-A419-8196D6E8170B")//Facility Administrators
        {
            try
            {
                _teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                int teacherid = _teacher.TeacherId;
                _teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teacherid)[0];
                int techersiteid = _teachersite.SiteId;
                _customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(techersiteid);
            }
            catch
            {
            }

            Label11.Text = _teacher.FirstName;
            Label12.Text = _teacher.LastName;
            Label14.Text = _customersite.SiteName;

            AboutMeSection.Visible = false;
            MemberNotices.Visible = false;
            Div1.Visible = true;
            FacilityMembers.Visible = true;
            Div2.Visible = false;
            CoachMembers.Visible = false;
            Div3.Visible = false;
            AdminMembers.Visible = false;

        }
        else if (rollid.ToString().Trim().ToUpper() == "A7DF4248-034A-4900-8D69-F914BCE9396D")//Teacher(Coach)
        {
            try
            {
                _teacher = DataRepository.TeacherProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                int teacherid = _teacher.TeacherId;
                _teachersite = DataRepository.TeacherSiteProvider.GetByTeacherId(teacherid)[0];
                int techersiteid = _teachersite.SiteId;
                _customersite = DataRepository.CustomerSiteProvider.GetByCustomerSiteId(techersiteid);
            }
            catch
            {
            }

            Label16.Text = _teacher.FirstName;
            Label17.Text = _teacher.LastName;

            Label19.Text = _customersite.SiteName;
   
            AboutMeSection.Visible = false;
            MemberNotices.Visible = false;
            Div1.Visible = false;
            FacilityMembers.Visible = false;
            Div2.Visible = true;
            CoachMembers.Visible = true;
            Div3.Visible = false;
            AdminMembers.Visible = false;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {



    }
}
