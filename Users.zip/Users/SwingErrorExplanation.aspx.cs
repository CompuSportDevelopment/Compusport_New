﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using System.IO;
using System.Net;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_SwingErrorExplanation : System.Web.UI.Page
public partial class Users_SwingErrorExplanation : SwingModel.UI.BasePage
{
    public int ErrorId;
    Customer customer;
    CustomerProfile customerprofile = new CustomerProfile();
    bool customerexists = false;
    bool customerprofileexists = false;
    SwingErrorLookup swingerrorlookup = new SwingErrorLookup();
    DirectionLookup dl = new DirectionLookup();
    CurvatureLookup cl = new CurvatureLookup();
    HeightLookup hl = new HeightLookup();
    SwingErrorIntro ErrorIntro = new SwingErrorIntro();
    TList<SwingErrorDirection> ErrorDirection = new TList<SwingErrorDirection>();
    TList<SwingErrorCurvature> ErrorCurvature = new TList<SwingErrorCurvature>();
    TList<SwingErrorHeight> ErrorHeight = new TList<SwingErrorHeight>();
    TList<SwingErrorDistance> ErrorDistance = new TList<SwingErrorDistance>();
    SwingErrorConclusion ErrorConclusion = new SwingErrorConclusion();

    protected override void OnPreLoad(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }

        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }
    }
    
    protected override void OnPreRender(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        int position;

        ErrorId = Convert.ToInt16(Request.QueryString.Get("ErrorId"));
        //MessageBox.Show("ErrorId: " + ErrorId.ToString());

        swingerrorlookup = DataRepository.SwingErrorLookupProvider.GetBySwingErrorId(ErrorId);
        Label8.Text = swingerrorlookup.TextDescription;
        position = swingerrorlookup.Code1 + 1;

        Uri myUri = new Uri("http://www.swingmodel.com/Users/PositionJpgs/" + customer.AspnetMembershipUserId.ToString() + "-Side-P" + position.ToString() + ".jpg");
        WebRequest myWebRequest = WebRequest.Create(myUri);
        WebResponse myWebResponse;
        try
        {
            myWebResponse = myWebRequest.GetResponse();
            Image3.ImageUrl = "~/Users/PositionJpgs/" + customer.AspnetMembershipUserId.ToString() + "-Side-P" + position.ToString() + ".jpg";
        }
        catch (Exception ex)
        {
            Image3.ImageUrl = "~/Users/PositionJpgs/Model-Side-P" + position.ToString() + ".jpg";
        }
        myUri = new Uri("http://www.swingmodel.com/Users/PositionJpgs/" + customer.AspnetMembershipUserId.ToString() + "-Side-P" + position.ToString() + ".jpg");
        myWebRequest = WebRequest.Create(myUri);
        try
        {
            myWebResponse = myWebRequest.GetResponse();
            Image4.ImageUrl = "~/Users/PositionJpgs/" + customer.AspnetMembershipUserId.ToString() + "-Back-P" + position.ToString() + ".jpg";
        }
        catch (Exception ex)
        {
            Image4.ImageUrl = "~/Users/PositionJpgs/Model-Back-P" + position.ToString() + ".jpg";
        }
        
        dl = DataRepository.DirectionLookupProvider.GetByDirectionId(Convert.ToInt16(customerprofile.BallDirection));
        cl = DataRepository.CurvatureLookupProvider.GetByCurvatureId(Convert.ToInt16(customerprofile.BallCurvature));
        hl = DataRepository.HeightLookupProvider.GetByHeightId(Convert.ToInt16(customerprofile.BallHeight));

        Label2.Text = dl.DirectionName;
        Label4.Text = cl.CurvatureName;
        Label6.Text = hl.HeightName;

        try
        {
            ErrorIntro = DataRepository.SwingErrorIntroProvider.GetBySwingErrorId(ErrorId)[0];
            Label7.Text = ErrorIntro.IntroText;
        }
        catch (Exception ex)
        {
        }
        
        try
        {
            ErrorDirection = DataRepository.SwingErrorDirectionProvider.GetBySwingErrorId(ErrorId);
            ListItem ListItem1 = new ListItem();

            foreach (SwingErrorDirection sed in ErrorDirection)
            {
                if (customerprofile.BallDirection.Equals(sed.Direction))
                {
                    if (sed.Priority.Equals(1))
                    {
                        if (customerprofile.BallCurvature.Equals(1))
                        {
                            if (!sed.DirectionDrawText.Equals("") && !sed.DirectionDrawText.Equals(null))
                            {
                                Panel1.Visible = true;
                                ListItem1.Text = sed.DirectionDrawText;
                                BulletedList1.Items.Add(ListItem1);
                            }
                        }
                        else if (customerprofile.BallCurvature.Equals(3))
                        {
                            if (!sed.DirectionFadeText.Equals("") && !sed.DirectionFadeText.Equals(null))
                            {
                                Panel1.Visible = true;
                                ListItem1.Text = sed.DirectionFadeText;
                                BulletedList1.Items.Add(ListItem1);
                            }
                        }
                    }
                    else if (sed.Priority.Equals(2))
                    {
                        if (customerprofile.BallHeight.Equals(1))
                        {
                            if (!sed.DirectionLowText.Equals("") && !sed.DirectionLowText.Equals(null))
                            {
                                Panel1.Visible = true;
                                ListItem1.Text = sed.DirectionLowText;
                                BulletedList1.Items.Add(ListItem1);
                            }
                        }
                        else if (customerprofile.BallHeight.Equals(3))
                        {
                            if (!sed.DirectionHighText.Equals("") && !sed.DirectionHighText.Equals(null))
                            {
                                Panel1.Visible = true;
                                ListItem1.Text = sed.DirectionHighText;
                                BulletedList1.Items.Add(ListItem1);
                            }
                        }
                    }
                    else if (sed.Priority.Equals(3))
                    {
                        if (!sed.DirectionOnlyText.Equals("") && !sed.DirectionOnlyText.Equals(null))
                        {
                            Panel1.Visible = true;
                            ListItem1.Text = sed.DirectionOnlyText;
                            BulletedList1.Items.Add(ListItem1);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }
        
        try
        {
            ErrorCurvature = DataRepository.SwingErrorCurvatureProvider.GetBySwingErrorId(ErrorId);
            ListItem ListItem2 = new ListItem();

            foreach (SwingErrorCurvature sec in ErrorCurvature)
            {
                if (customerprofile.BallCurvature.Equals(sec.Curvature))
                {
                    if (sec.Priority.Equals(1))
                    {
                        if (customerprofile.BallDirection.Equals(1))
                        {
                            if (!sec.CurvatureLeftText.Equals("") && !sec.CurvatureLeftText.Equals(null))
                            {
                                Panel2.Visible = true;
                                ListItem2.Text = sec.CurvatureLeftText;
                                BulletedList2.Items.Add(ListItem2);
                            }
                        }
                        else if (customerprofile.BallDirection.Equals(3))
                        {
                            if (!sec.CurvatureRightText.Equals("") && !sec.CurvatureRightText.Equals(null))
                            {
                                Panel2.Visible = true;
                                ListItem2.Text = sec.CurvatureRightText;
                                BulletedList2.Items.Add(ListItem2);
                            }
                        }
                    }
                    else if (sec.Priority.Equals(2))
                    {
                        if (customerprofile.BallHeight.Equals(1))
                        {
                            if (!sec.CurvatureLowText.Equals("") && !sec.CurvatureLowText.Equals(null))
                            {
                                Panel2.Visible = true;
                                ListItem2.Text = sec.CurvatureLowText;
                                BulletedList2.Items.Add(ListItem2);
                            }
                        }
                        else if (customerprofile.BallHeight.Equals(3))
                        {
                            if (!sec.CurvatureHighText.Equals("") && !sec.CurvatureHighText.Equals(null))
                            {
                                Panel2.Visible = true;
                                ListItem2.Text = sec.CurvatureHighText;
                                BulletedList2.Items.Add(ListItem2);
                            }
                        }
                    }
                    else if (sec.Priority.Equals(3))
                    {
                        if (!sec.CurvatureOnlyText.Equals("") && !sec.CurvatureOnlyText.Equals(null))
                        {
                            Panel2.Visible = true;
                            ListItem2.Text = sec.CurvatureOnlyText;
                            BulletedList2.Items.Add(ListItem2);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }
        
        try
        {
            ErrorHeight = DataRepository.SwingErrorHeightProvider.GetBySwingErrorId(ErrorId);
            ListItem ListItem3 = new ListItem();

            foreach (SwingErrorHeight seh in ErrorHeight)
            {
                if (customerprofile.BallHeight.Equals(seh.Height))
                {
                    if (seh.Priority.Equals(1))
                    {
                        if (customerprofile.BallDirection.Equals(1))
                        {
                            if (!seh.HeightLeftText.Equals("") && !seh.HeightLeftText.Equals(null))
                            {
                                Panel3.Visible = true;
                                ListItem3.Text = seh.HeightLeftText;
                                BulletedList3.Items.Add(ListItem3);
                            }
                        }
                        else if (customerprofile.BallDirection.Equals(3))
                        {
                            if (!seh.HeightRightText.Equals("") && !seh.HeightRightText.Equals(null))
                            {
                                Panel3.Visible = true;
                                ListItem3.Text = seh.HeightRightText;
                                BulletedList3.Items.Add(ListItem3);
                            }
                        }
                    }
                    else if (seh.Priority.Equals(2))
                    {
                        if (customerprofile.BallCurvature.Equals(1))
                        {
                            if (!seh.HeightDrawText.Equals("") && !seh.HeightDrawText.Equals(null))
                            {
                                Panel3.Visible = true;
                                ListItem3.Text = seh.HeightDrawText;
                                BulletedList3.Items.Add(ListItem3);
                            }
                        }
                        else if (customerprofile.BallCurvature.Equals(3))
                        {
                            if (!seh.HeightFadeText.Equals("") && !seh.HeightFadeText.Equals(null))
                            {
                                Panel3.Visible = true;
                                ListItem3.Text = seh.HeightFadeText;
                                BulletedList3.Items.Add(ListItem3);
                            }
                        }
                    }
                    else if (seh.Priority.Equals(3))
                    {
                        if (!seh.HeightOnlyText.Equals("") && !seh.HeightOnlyText.Equals(null))
                        {
                            Panel3.Visible = true;
                            ListItem3.Text = seh.HeightOnlyText;
                            BulletedList3.Items.Add(ListItem3);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        if (customerprofile.BallDirection.Equals(2) && customerprofile.BallCurvature.Equals(2) && customerprofile.BallHeight.Equals(2))
        {
            Panel4.Visible = true;
            try
            {
                ErrorDistance = DataRepository.SwingErrorDistanceProvider.GetBySwingErrorId(ErrorId);
                ListItem ListItem4 = new ListItem();

                foreach (SwingErrorDistance sedis in ErrorDistance)
                {
                    if (customerprofile.BallDistance.Equals(sedis.Distance))
                    {
                        ListItem4.Text = sedis.DistanceText;
                        BulletedList4.Items.Add(ListItem4);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
        else
            Panel4.Visible = false;
        
        try
        {
            ErrorConclusion = DataRepository.SwingErrorConclusionProvider.GetBySwingErrorId(ErrorId)[0];
            Label12.Text = ErrorConclusion.ConclusionText;
        }
        catch (Exception ex)
        {
        }
    }
}
