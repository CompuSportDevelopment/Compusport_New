﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SwingModel.Data;
using SwingModel.Entities;
using System.Windows.Forms;

//public partial class Users_SwingErrors : System.Web.UI.Page
public partial class Users_SwingErrors : SwingModel.UI.BasePage
{
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    bool customerexists = false;
    bool customerprofileexists = false;
    DirectionLookup dl = new DirectionLookup();
    CurvatureLookup cl = new CurvatureLookup();
    HeightLookup hl = new HeightLookup();
    TList<Lesson> lessons = new TList<Lesson>();
    Movie movie = new Movie();
    TList<MovieClip> movieclips = new TList<MovieClip>();
    TList<MovieError> movieerrors = new TList<MovieError>();
    SwingErrorLookup swingerror = new SwingErrorLookup();
    
    protected override void OnPreLoad(EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            try
            {
                customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
                customerexists = true;
            }
            catch
            {
                //no entry in Customer table for current member
                customerexists = false;
            }
        }

        try
        {
            customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
            customerprofileexists = true;
        }
        catch
        {
            //no entery in CustomerProfile table for current member
            customerprofileexists = false;
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        CheckProfiles myCheckProfiles = new CheckProfiles();

        //MessageBox.Show(Convert.ToString(myCheckProfiles.Personal()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Address()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Contact()));

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("3a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address() && myCheckProfiles.Facility() && myCheckProfiles.Dimensions())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }
        }
        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        dl = DataRepository.DirectionLookupProvider.GetByDirectionId(Convert.ToInt16(customerprofile.BallDirection));
        cl = DataRepository.CurvatureLookupProvider.GetByCurvatureId(Convert.ToInt16(customerprofile.BallCurvature));
        hl = DataRepository.HeightLookupProvider.GetByHeightId(Convert.ToInt16(customerprofile.BallHeight));

        Label2.Text = dl.DirectionName;
        Label4.Text = cl.CurvatureName;
        Label6.Text = hl.HeightName;

        lessons = DataRepository.LessonProvider.GetByCustomerId(customer.CustomerId);
        lessons.Sort("LessonDate DESC");
        
        movie = DataRepository.MovieProvider.GetByLessonId(lessons[0].LessonId)[0];
        movieclips = DataRepository.MovieClipProvider.GetByMovieId(movie.MovieId);
        foreach (MovieClip mc in movieclips)
        {
            movieerrors = DataRepository.MovieErrorProvider.GetByMovieClipId(mc.MovieClipId);
            foreach (MovieError me in movieerrors)
            {
                swingerror = DataRepository.SwingErrorLookupProvider.GetBySwingErrorId(me.SwingErrorId);

                switch (swingerror.Code1)
                {
                    case 0:
                        Label7.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane1 = AccordionPane1;
                        System.Web.UI.WebControls.HyperLink ap1hl3 = new HyperLink();
                        ap1hl3.Width = 500;
                        ap1hl3.Text = swingerror.TextDescription;
                        ap1hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap1spacer1 = new System.Web.UI.WebControls.Label();
                        ap1spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap1hl1 = new HyperLink();
                        ap1hl1.Width = 200;
                        ap1hl1.Text = swingerror.InstructionLinkName;
                        ap1hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap1spacer2 = new System.Web.UI.WebControls.Label();
                        ap1spacer2.Width = 50;
                        AccPane1.ContentContainer.Controls.Add(ap1hl3);
                        AccPane1.ContentContainer.Controls.Add(ap1spacer1);
                        AccPane1.ContentContainer.Controls.Add(ap1hl1);
                        AccPane1.ContentContainer.Controls.Add(ap1spacer2);
                        AccPane1.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane1.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 1:
                        Label8.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane2 = AccordionPane2;
                        System.Web.UI.WebControls.HyperLink ap2hl3 = new HyperLink();
                        ap2hl3.Width = 500;
                        ap2hl3.Text = swingerror.TextDescription;
                        ap2hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap2spacer1 = new System.Web.UI.WebControls.Label();
                        ap2spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap2hl1 = new HyperLink();
                        ap2hl1.Width = 200;
                        ap2hl1.Text = swingerror.InstructionLinkName;
                        ap2hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap2spacer2 = new System.Web.UI.WebControls.Label();
                        ap2spacer2.Width = 50;
                        AccPane2.ContentContainer.Controls.Add(ap2hl3);
                        AccPane2.ContentContainer.Controls.Add(ap2spacer1);
                        AccPane2.ContentContainer.Controls.Add(ap2hl1);
                        AccPane2.ContentContainer.Controls.Add(ap2spacer2);
                        AccPane2.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane2.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 2:
                        Label9.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane3 = AccordionPane3;
                        System.Web.UI.WebControls.HyperLink ap3hl3 = new HyperLink();
                        ap3hl3.Width = 500;
                        ap3hl3.Text = swingerror.TextDescription;
                        ap3hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap3spacer1 = new System.Web.UI.WebControls.Label();
                        ap3spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap3hl1 = new HyperLink();
                        ap3hl1.Width = 200;
                        ap3hl1.Text = swingerror.InstructionLinkName;
                        ap3hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap3spacer2 = new System.Web.UI.WebControls.Label();
                        ap3spacer2.Width = 50;
                        AccPane3.ContentContainer.Controls.Add(ap3hl3);
                        AccPane3.ContentContainer.Controls.Add(ap3spacer1);
                        AccPane3.ContentContainer.Controls.Add(ap3hl1);
                        AccPane3.ContentContainer.Controls.Add(ap3spacer2);
                        AccPane3.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane3.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 3:
                        Label10.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane4 = AccordionPane4;
                        System.Web.UI.WebControls.HyperLink ap4hl3 = new HyperLink();
                        ap4hl3.Width = 500;
                        ap4hl3.Text = swingerror.TextDescription;
                        ap4hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap4spacer1 = new System.Web.UI.WebControls.Label();
                        ap4spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap4hl1 = new HyperLink();
                        ap4hl1.Width = 200;
                        ap4hl1.Text = swingerror.InstructionLinkName;
                        ap4hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap4spacer2 = new System.Web.UI.WebControls.Label();
                        ap4spacer2.Width = 50;
                        AccPane4.ContentContainer.Controls.Add(ap4hl3);
                        AccPane4.ContentContainer.Controls.Add(ap4spacer1);
                        AccPane4.ContentContainer.Controls.Add(ap4hl1);
                        AccPane4.ContentContainer.Controls.Add(ap4spacer2);
                        AccPane4.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane4.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 4:
                        Label11.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane5 = AccordionPane5;
                        System.Web.UI.WebControls.HyperLink ap5hl3 = new HyperLink();
                        ap5hl3.Width = 500;
                        ap5hl3.Text = swingerror.TextDescription;
                        ap5hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap5spacer1 = new System.Web.UI.WebControls.Label();
                        ap5spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap5hl1 = new HyperLink();
                        ap5hl1.Width = 200;
                        ap5hl1.Text = swingerror.InstructionLinkName;
                        ap5hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap5spacer2 = new System.Web.UI.WebControls.Label();
                        ap5spacer2.Width = 50;
                        AccPane5.ContentContainer.Controls.Add(ap5hl3);
                        AccPane5.ContentContainer.Controls.Add(ap5spacer1);
                        AccPane5.ContentContainer.Controls.Add(ap5hl1);
                        AccPane5.ContentContainer.Controls.Add(ap5spacer2);
                        AccPane5.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane5.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 5:
                        Label12.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane6 = AccordionPane6;
                        System.Web.UI.WebControls.HyperLink ap6hl3 = new HyperLink();
                        ap6hl3.Width = 500;
                        ap6hl3.Text = swingerror.TextDescription;
                        ap6hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap6spacer1 = new System.Web.UI.WebControls.Label();
                        ap6spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap6hl1 = new HyperLink();
                        ap6hl1.Width = 200;
                        ap6hl1.Text = swingerror.InstructionLinkName;
                        ap6hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap6spacer2 = new System.Web.UI.WebControls.Label();
                        ap6spacer2.Width = 50;
                        AccPane6.ContentContainer.Controls.Add(ap6hl3);
                        AccPane6.ContentContainer.Controls.Add(ap6spacer1);
                        AccPane6.ContentContainer.Controls.Add(ap6hl1);
                        AccPane6.ContentContainer.Controls.Add(ap6spacer2);
                        AccPane6.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane6.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 6:
                        Label13.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane7 = AccordionPane7;
                        System.Web.UI.WebControls.HyperLink ap7hl3 = new HyperLink();
                        ap7hl3.Width = 500;
                        ap7hl3.Text = swingerror.TextDescription;
                        ap7hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap7spacer1 = new System.Web.UI.WebControls.Label();
                        ap7spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap7hl1 = new HyperLink();
                        ap7hl1.Width = 200;
                        ap7hl1.Text = swingerror.InstructionLinkName;
                        ap7hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap7spacer2 = new System.Web.UI.WebControls.Label();
                        ap7spacer2.Width = 50;
                        AccPane7.ContentContainer.Controls.Add(ap7hl3);
                        AccPane7.ContentContainer.Controls.Add(ap7spacer1);
                        AccPane7.ContentContainer.Controls.Add(ap7hl1);
                        AccPane7.ContentContainer.Controls.Add(ap7spacer2);
                        AccPane7.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane7.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 7:
                        Label14.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane8 = AccordionPane8;
                        System.Web.UI.WebControls.HyperLink ap8hl3 = new HyperLink();
                        ap8hl3.Width = 500;
                        ap8hl3.Text = swingerror.TextDescription;
                        ap8hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap8spacer1 = new System.Web.UI.WebControls.Label();
                        ap8spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap8hl1 = new HyperLink();
                        ap8hl1.Width = 200;
                        ap8hl1.Text = swingerror.InstructionLinkName;
                        ap8hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap8spacer2 = new System.Web.UI.WebControls.Label();
                        ap8spacer2.Width = 50;
                        AccPane8.ContentContainer.Controls.Add(ap8hl3);
                        AccPane8.ContentContainer.Controls.Add(ap8spacer1);
                        AccPane8.ContentContainer.Controls.Add(ap8hl1);
                        AccPane8.ContentContainer.Controls.Add(ap8spacer2);
                        AccPane8.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane8.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 8:
                        Label15.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane9 = AccordionPane9;
                        System.Web.UI.WebControls.HyperLink ap9hl3 = new HyperLink();
                        ap9hl3.Width = 500;
                        ap9hl3.Text = swingerror.TextDescription;
                        ap9hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap9spacer1 = new System.Web.UI.WebControls.Label();
                        ap9spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap9hl1 = new HyperLink();
                        ap9hl1.Width = 200;
                        ap9hl1.Text = swingerror.InstructionLinkName;
                        ap9hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap9spacer2 = new System.Web.UI.WebControls.Label();
                        ap9spacer2.Width = 50;
                        AccPane9.ContentContainer.Controls.Add(ap9hl3);
                        AccPane9.ContentContainer.Controls.Add(ap9spacer1);
                        AccPane9.ContentContainer.Controls.Add(ap9hl1);
                        AccPane9.ContentContainer.Controls.Add(ap9spacer2);
                        AccPane9.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane9.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;

                    case 9:
                        Label16.Visible = false;
                        AjaxControlToolkit.AccordionPane AccPane10 = AccordionPane10;
                        System.Web.UI.WebControls.HyperLink ap10hl3 = new HyperLink();
                        ap10hl3.Width = 500;
                        ap10hl3.Text = swingerror.TextDescription;
                        ap10hl3.NavigateUrl = "SwingErrorExplanation.aspx?ErrorId=" + swingerror.SwingErrorId;
                        System.Web.UI.WebControls.Label ap10spacer1 = new System.Web.UI.WebControls.Label();
                        ap10spacer1.Width = 50;
                        System.Web.UI.WebControls.HyperLink ap10hl1 = new HyperLink();
                        ap10hl1.Width = 200;
                        ap10hl1.Text = swingerror.InstructionLinkName;
                        ap10hl1.NavigateUrl = "~/Users" + swingerror.InstructionLink;
                        System.Web.UI.WebControls.Label ap10spacer2 = new System.Web.UI.WebControls.Label();
                        ap10spacer2.Width = 50;
                        AccPane10.ContentContainer.Controls.Add(ap10hl3);
                        AccPane10.ContentContainer.Controls.Add(ap10spacer1);
                        AccPane10.ContentContainer.Controls.Add(ap10hl1);
                        AccPane10.ContentContainer.Controls.Add(ap10spacer2);
                        AccPane10.ContentContainer.Controls.Add(new LiteralControl("<a href=javascript:OpenWindow('MyDrills.aspx?ErrorId=" + swingerror.SwingErrorId + "')>View Drills</a>"));
                        AccPane10.ContentContainer.Controls.Add(new LiteralControl("<br/>"));
                        break;
                }
            }
        }
    }
}
