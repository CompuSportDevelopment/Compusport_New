﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Users_LaunchAngleGauge : System.Web.UI.Page
{
    int athleteTotalValue;
    int modelTotalValue;
    int scaleInterval;

    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "image/jpg";

        athleteTotalValue = Convert.ToInt16(Request.QueryString.Get("athleteTotalValue"));
        modelTotalValue = Convert.ToInt16(Request.QueryString.Get("modelTotalValue"));

        SMSoftCharts.Gauge ga = new SMSoftCharts.Gauge();
        ga.ImageWidth = 287;
        ga.ImageHeight = 280;

        ga.CaptionIndex = 0;
        ga.CaptionColor = System.Drawing.Color.Black;
        ga.CaptionText = "Total";
        ga.CaptionPosition = new System.Drawing.Point(120, 265);
        ga.Fonts = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold);
        ga.StartPoints = new System.Drawing.Point(144, 160);

        ga.BaseArcColor = System.Drawing.Color.Gray;
        ga.BaseArcRadius = 100;
        ga.BaseArcWidth = 2;
        ga.BaseArcStart = 135;
        ga.BaseArcSweep = 270;
        if (athleteTotalValue > modelTotalValue)
        {
            scaleInterval = 5 * (((athleteTotalValue / 10) + 5) / 5);
        }
        else
        {
            scaleInterval = 5 * (((modelTotalValue / 10) + 5) / 5);
        }
        #region[Total Range]
        //int totalRange = (modelTotalValue * 120) / 100;
       int  totalRange = scaleInterval * 10; ;
        ga.MaximumValue = totalRange;
        ga.MinimumValue = 0;
        #endregion[Total Range]
        #region[Green Range]
        ga.RangesIndex = 3;
        ga.RangeEnabled = true;
        ga.RangeColor = System.Drawing.Color.LimeGreen;
        ga.RangeStartRadius = 85;
        ga.RangeEndRadius = 100;

        int greenRange = (modelTotalValue * 90) / 100;
        ga.RangeStartValue = greenRange;
        ga.RangeEndValue = totalRange;
        #endregion[Green Range]

        #region[Yellow Region]
        ga.RangesIndex = 1;
        ga.RangeEnabled = true;
        ga.RangeColor = System.Drawing.Color.Yellow;
        ga.RangeStartRadius = 85;
        ga.RangeEndRadius = 100;

        int yellowRange = (modelTotalValue * 80) / 100;
        ga.RangeStartValue = yellowRange;
        ga.RangeEndValue = greenRange;
        #endregion[Yellow Range]

        #region[Orange Range ]
        ga.RangesIndex = 0;
        ga.RangeEnabled = true;
        ga.RangeColor = System.Drawing.Color.OrangeRed;
        ga.RangeStartRadius = 85;
        ga.RangeEndRadius = 100;

        int orangeRange = (modelTotalValue * 80) / 100;
        ga.RangeStartValue = 0;
        ga.RangeEndValue = yellowRange;
        #endregion[Orange Range]

        ga.NeedleType = 0;
        ga.NeedlePrimaryColor = SMSoftCharts.Gauge.NeedleColors.Gray;
        ga.NeedleSecondaryColor = System.Drawing.Color.Blue;
        ga.NeedleSize = 112;
        ga.NeedleWidth = 2;

        ga.ScaleNumbersRadius = 130;
        ga.ScaleNumbersRotation = 0;

        ga.MajorScaleColor = System.Drawing.Color.Black;
        ga.MajorScaleStartRadius = 100;
        ga.MajorScaleEndRadius = 115;
        ga.MajorScaleStepValue = scaleInterval;
        ga.MajorScaleWidth = 2;

        ga.MinorScaleColor = System.Drawing.Color.Gray;
        ga.MinorScaleStartRadius = 100;
        ga.MinorScaleEndRadius = 110;
        ga.MinorScaleNumOfLines = 4;
        ga.MinorScaleWidth = 1;

        #region[Start Athletes value Indicator]
        ga.Value = (float)athleteTotalValue;
        #endregion[Start Athletes value Indicator]

        System.Drawing.Image img; // = new System.Drawing.Bitmap(Response.OutputStream);
        img = ga.DrawGauge();
        img.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);
        img.Dispose();
        img = null;
        ga = null;
    }
}
