﻿using System;
using System.Collections;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Text;
using System.Net.Mail;
using SwingModel.Data;
using SwingModel.Entities;

//public partial class Users_EmailTeacher : System.Web.UI.Page
public partial class Users_EmailTeacher : SwingModel.UI.BasePage
{
    int x;
    Teacher teacher = new Teacher();
    Customer customer = new Customer();
    CustomerProfile customerprofile = new CustomerProfile();
    int MemberHomeSite = 0;
    int MemberTeacher = 0;
    Teacher teachr = new Teacher();
    bool CustomerSiteChanged = false;
    string MemberEmail = Membership.GetUser().Email;
    CompuSportDAL.SprintAthleteEdit _sprintAthleteEdit = new CompuSportDAL.SprintAthleteEdit();

    protected override void OnPreRender(EventArgs e)
    {
        customer = DataRepository.CustomerProvider.GetByAspnetMembershipUserId(new Guid(Membership.GetUser().ProviderUserKey.ToString()))[0];
        customerprofile = DataRepository.CustomerProfileProvider.GetByCustomerId(customer.CustomerId)[0];
        MemberHomeSite = customerprofile.CustomerSite;
        MemberTeacher = customerprofile.Teacher;
        TextBox3.Text = MemberEmail;

        CheckProfiles myCheckProfiles = new CheckProfiles();

        //MessageBox.Show(Convert.ToString(myCheckProfiles.Personal()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Address()));
        //MessageBox.Show(Convert.ToString(myCheckProfiles.Contact()));

        if (this.User.Identity.IsAuthenticated)
        {
            if (!myCheckProfiles.Personal())
            {
                //MessageBox.Show("1a");
                this.Page.Response.Redirect("~/Users/MyAccount.aspx");
            }

            if (!myCheckProfiles.Address())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Facility())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Facility())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("2a");
                    this.Page.Response.Redirect("~/Users/MyAccount.aspx");
                }
            }

            if (!myCheckProfiles.Golf())
            {
                if (myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("4a");
                    this.Page.Response.Redirect("~/Users/MyGolf.aspx");
                }
            }

            if (!myCheckProfiles.Dimensions())
            {
                if (myCheckProfiles.Golf() && myCheckProfiles.Personal() && myCheckProfiles.Address())
                {
                    //MessageBox.Show("5a");
                    this.Page.Response.Redirect("~/Users/MyDimensions.aspx");
                }
            }
        }

        if (!CustomerSiteChanged)
        {
            TList<CustomerSite> customersites = DataRepository.CustomerSiteProvider.GetAll();
            //if (DropDownList2.SelectedIndex <= 0)
                DropDownList2.Items.Clear();
            DropDownList2.Items.Add("Select Location");
            DropDownList2.Items[0].Value = "0";
            x = 0;
            foreach (CustomerSite cs in customersites)
            {
                x++;
                DropDownList2.Items.Add(cs.SiteName);
                DropDownList2.Items[x].Value = cs.CustomerSiteId.ToString();
                if (Convert.ToInt16(DropDownList2.Items[x].Value).Equals(Convert.ToInt16(MemberHomeSite)))
                    DropDownList2.Items[x].Selected = true;
            }

            if (Convert.ToInt16(DropDownList2.SelectedValue).Equals(Convert.ToInt16(MemberHomeSite)))
            {
                #region[Old Code For Primary Coach]
                //TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList2.SelectedValue));
                //DropDownList1.Items.Clear();
                //DropDownList1.Items.Add("Select Teacher");
                //DropDownList1.Items[0].Value = "0";
                //x = 0;
                //foreach (TeacherSite tas in teachersatsite)
                //{
                //    x++;
                //    teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                //    DropDownList1.Items.Add(teachr.FirstName + " " + teachr.LastName);
                //    DropDownList1.Items[x].Value = teachr.TeacherId.ToString();
                //    if (Convert.ToInt16(DropDownList1.Items[x].Value).Equals(Convert.ToInt16(MemberTeacher)))
                //        DropDownList1.Items[x].Selected = true;
                //}
                #endregion[Old Code For Primary Coach]
                DropDownList1.Items.Clear();
                DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customer.CustomerId);
                DropDownList1.DataSource = dsCoachName.Tables[0];
                DropDownList1.DataTextField = "CoachName";
                DropDownList1.DataValueField = "TeacherId";
                DropDownList1.DataBind();
                DropDownList1.SelectedIndex = 0;
            }
            else
            {
                #region[Old Code For Primary Coach]
                //TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList2.SelectedValue));
                //DropDownList1.Items.Clear();
                //DropDownList1.Items.Add("Select Teacher");
                //DropDownList1.Items[0].Value = "0";
                //DropDownList1.Items[0].Selected = true;
                //x = 0;
                //foreach (TeacherSite tas in teachersatsite)
                //{
                //    x++;
                //    teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
                //    DropDownList1.Items.Add(teachr.FirstName + " " + teachr.LastName);
                //    DropDownList1.Items[x].Value = teachr.TeacherId.ToString();
                //}
                #endregion[Old Code For Primary Coach]
                DropDownList1.Items.Clear();
                DataSet dsCoachName = _sprintAthleteEdit.GetPrimaryCoach(customer.CustomerId);
                DropDownList1.DataSource = dsCoachName.Tables[0];
                DropDownList1.DataTextField = "CoachName";
                DropDownList1.DataValueField = "TeacherId";
                DropDownList1.DataBind();
                DropDownList1.SelectedIndex = 0;
            }
        }

        base.OnPreRender(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        CustomerSiteChanged = true;
        #region[Old Code For Primary Coach]
        //if (Convert.ToInt16(DropDownList2.Items[x].Value).Equals(MemberHomeSite))
        //{
        //    TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList2.SelectedValue));
        //    DropDownList1.Items.Clear();
        //    DropDownList1.Items.Add("Select Teacher");
        //    DropDownList1.Items[0].Value = "0";
        //    x = 0;
        //    foreach (TeacherSite tas in teachersatsite)
        //    {
        //        x++;
        //        teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
        //        DropDownList1.Items.Add(teachr.FirstName + " " + teachr.LastName);
        //        DropDownList1.Items[x].Value = teachr.TeacherId.ToString();
        //        if (Convert.ToInt16(DropDownList1.Items[x].Value).Equals(MemberTeacher))
        //            DropDownList1.Items[x].Selected = true;
        //    }
        //}
        //else
        //{
        //    TList<TeacherSite> teachersatsite = DataRepository.TeacherSiteProvider.GetBySiteId(Convert.ToInt16(DropDownList2.SelectedValue));
        //    DropDownList1.Items.Clear();
        //    DropDownList1.Items.Add("Select Teacher");
        //    DropDownList1.Items[0].Value = "0";
        //    DropDownList1.Items[0].Selected = true;
        //    x = 0;
        //    foreach (TeacherSite tas in teachersatsite)
        //    {
        //        x++;
        //        teachr = DataRepository.TeacherProvider.GetByTeacherId(tas.TeacherId);
        //        DropDownList1.Items.Add(teachr.FirstName + " " + teachr.LastName);
        //        DropDownList1.Items[x].Value = teachr.TeacherId.ToString();
        //    }
        //}
        #endregion[Old Code For Primary Coach]
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string TeacherEmail = "";
        teacher = DataRepository.TeacherProvider.GetByTeacherId(Convert.ToInt16(DropDownList1.SelectedValue));
        Guid TeacherGuid = new Guid();
        TeacherGuid = teacher.AspnetMembershipUserId;
        MembershipUser TeacherUser = new MembershipUser("AspNetSqlMembershipProvider", null, null, null, null, null, true, true, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now, System.DateTime.Now);
        TeacherUser = Membership.GetUser(TeacherGuid);
        TeacherEmail = TeacherUser.Email;

        MailAddress from = new MailAddress(TextBox3.Text);
        MailAddress to = new MailAddress(TeacherEmail);
        MailAddress ccFrom = new MailAddress(TextBox3.Text);
        MailAddress ccDev = new MailAddress("dev@swingmodel.com");
        MailMessage message = new MailMessage(from, to);
        message.IsBodyHtml = true;

        message.Subject = TextBox1.Text;
        message.Body = FreeTextBox1.Text;
        message.CC.Add(ccFrom);
        message.CC.Add(ccDev);

        Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        MailSettingsSectionGroup settings = (MailSettingsSectionGroup)config.GetSectionGroup("system.net/mailSettings");
        SmtpClient client = new SmtpClient(settings.Smtp.Network.Host);
        try
        {
            client.Send(message);
            //Response.Write("Your Email has been sent sucessfully - Thank You");
            Label2.Visible = true;
        }
        catch (Exception ex)
        {
            //Response.Write("Send failure: " + ex.ToString());
            Label2.Text = "Send failure. Please try sending again. If the problem persists, please contact SwingModel.";
            Label2.Visible = true;
        }

    }
}
